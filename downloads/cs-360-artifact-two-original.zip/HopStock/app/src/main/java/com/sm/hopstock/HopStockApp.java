package com.sm.hopstock;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

public class HopStockApp extends Application {
    public static final String CHANNEL_ID_NO_STOCK = "hopstock_oos";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    /** Create notification channel for out-of-stock alerts. */
    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID_NO_STOCK,
                getString(R.string.notification_channel_out_of_stock_name),
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription(getString(R.string.notification_channel_out_of_stock_description));
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }
}

