package com.sm.hopstock.ui;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.sm.hopstock.R;
import com.sm.hopstock.data.InventoryItem;

import java.util.Objects;

public class InventoryAdapter extends ListAdapter<InventoryItem, InventoryAdapter.VH> {
    private final ItemClickListener listener;

    /** Constructor. */
    public InventoryAdapter(ItemClickListener listener) {
        super(DIFF);
        this.listener = listener;
    }

    /** Create ViewHolder. */
    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new VH(v);
    }

    /** Bind data to ViewHolder. */
    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        InventoryItem item = getItem(position);
        final View itemView = holder.itemView;
        final android.content.Context ctx = itemView.getContext();

        holder.tvName.setText(item.name);
        holder.tvQty.setText(ctx.getString(R.string.qty_format_string, item.quantity));

        String skuText = item.sku == null ? "" : ctx.getString(R.string.sku_format_string, item.sku);
        holder.tvSku.setText(skuText);

        if (item.quantity <= 0) {
            holder.tvQty.setBackgroundResource(R.drawable.badge_red);
            holder.tvQty.setTextColor(ContextCompat.getColor(ctx, R.color.badge_red_text));
        } else {
            holder.tvQty.setBackgroundResource(R.drawable.badge_green);
            holder.tvQty.setTextColor(ContextCompat.getColor(ctx, R.color.badge_green_text));
        }

        // Load image: Priority is user-selected URI > static resource > fallback to launcher icon.
        if (item.imageUri != null && !item.imageUri.isEmpty()) {
            try {
                holder.ivImage.setImageURI(Uri.parse(item.imageUri));
            } catch (Exception e) {
                // If URI parsing/loading fails, use fallback.
                holder.ivImage.setImageResource(R.mipmap.ic_launcher);
            }
        } else if (item.imageResId != 0) {
            holder.ivImage.setImageResource(item.imageResId);
        } else {
            holder.ivImage.setImageResource(R.mipmap.ic_launcher);
        }

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
        holder.btnDelete.setOnClickListener(v -> listener.onItemDelete(item));
    }

    /** ViewHolder class. */
    public static class VH extends RecyclerView.ViewHolder {
        final TextView tvName;
        final TextView tvSku;
        final TextView tvQty;
        final ImageView ivImage;
        final ImageView btnDelete;
        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.itemName);
            tvSku = itemView.findViewById(R.id.itemSku);
            tvQty = itemView.findViewById(R.id.itemQty);
            ivImage = itemView.findViewById(R.id.itemImage);
            btnDelete = itemView.findViewById(R.id.btnDeleteItem);
        }
    }

    /** Click listener interface. */
    public interface ItemClickListener {
        void onItemClick(InventoryItem item);
        void onItemDelete(InventoryItem item);
    }

    /** DiffUtil callback for efficient list updates. */
    private static final DiffUtil.ItemCallback<InventoryItem> DIFF = new DiffUtil.ItemCallback<>() {
        /** Check if two items represent the same inventory entry based on their IDs. */
        @Override
        public boolean areItemsTheSame(@NonNull InventoryItem oldItem, @NonNull InventoryItem newItem) {
            return oldItem.itemId == newItem.itemId;
        }

        /** Check if the contents of two items are the same by comparing all relevant fields. */
        @Override
        public boolean areContentsTheSame(@NonNull InventoryItem oldItem, @NonNull InventoryItem newItem) {
            // Use Objects.equals to simplify null-safe comparisons
            boolean skuEq = Objects.equals(oldItem.sku, newItem.sku);
            boolean descEq = Objects.equals(oldItem.description, newItem.description);
            boolean locEq = Objects.equals(oldItem.location, newItem.location);
            boolean imgResEq = oldItem.imageResId == newItem.imageResId;
            boolean imgUriEq = Objects.equals(oldItem.imageUri, newItem.imageUri);
            boolean nameEq = Objects.equals(oldItem.name, newItem.name);
            return nameEq && oldItem.quantity == newItem.quantity && skuEq && descEq && locEq && imgResEq && imgUriEq;
        }
    };
}
