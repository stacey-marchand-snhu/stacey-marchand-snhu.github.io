package com.sm.hopstock.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.sm.hopstock.R;

import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SeedUtil {
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final String PREFS_NAME = "com.sm.hopstock.SEED_PREFS";
    private static final String KEY_SEEDED = "inventory_seeded";

    /** Seed the inventory database with initial data (only runs once per app installation). */
    public static void seedInventory(final Context context) {
        // Check if we've already seeded the database.
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_SEEDED, false)) {
            // Already seeded, so just return.
            return;
        }

        executor.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(context);
            InventoryDao dao = db.inventoryDao();

            // Delete everything first so seed replaces current inventory.
            dao.deleteAll();

            long now = new Date().getTime();
            dao.insert(new InventoryItem("Commuter Hoodie","Soft hoodie with reflective stripe for evening commutes.","1000001","Apparel A1", 25, R.drawable.commuter_hoodie, null, now));
            dao.insert(new InventoryItem("Sunset Tee","Lightweight tee in gradient sunset colors, breathable for long shifts.","1000002","Apparel A1", 40, R.drawable.sunset_tee, null, now));
            dao.insert(new InventoryItem("Trail Cap","Durable cap with moisture-wicking sweatband.","1000003","Headwear B2", 15, R.drawable.trail_cap, null, now));
            dao.insert(new InventoryItem("Cozy Socks (3-pack)","Plush three-pack socks with reinforced heels for comfort.","1000004","Accessories C3", 60, R.drawable.cozy_socks, null, now));
            dao.insert(new InventoryItem("RainShield Windbreaker","Compact windbreaker that packs into its pocket — water resistant.","1000005","Outerwear D4", 8, R.drawable.rainshield_windbreaker, null, now));
            dao.insert(new InventoryItem("Infinity Scarf","Versatile scarf that can be styled multiple ways (limited edition).","1000006","Accessories C3", 0, R.drawable.infinity_scarf, null, now));
            dao.insert(new InventoryItem("Dream Pajama Set","Ultra-soft pajama set with breathable fabric for cozy nights.","1000007","Apparel A2", 12, R.drawable.dream_pajama_set, null, now));
            dao.insert(new InventoryItem("Pixel Beanie","Retro knit beanie with pixel-pattern cuff.","1000008","Headwear B2", 30, R.drawable.pixel_beanie, null, now));
            dao.insert(new InventoryItem("Worksmith Apron","Heavy-duty apron with reinforced pockets for tools and pens.","1000009","Workwear D5", 5, R.drawable.worksmith_apron, null, now));
            dao.insert(new InventoryItem("Retro Trainer Jacket","Vintage-inspired trainer jacket with contrasting stripes.","1000010","Outerwear D4", 7, R.drawable.retro_trainer_jacket, null, now));
            dao.insert(new InventoryItem("Flex Pants","Stretchy, durable pants with articulated knees for movement.","1000011","Workwear D5", 20, R.drawable.flex_pants, null, now));
            dao.insert(new InventoryItem("Storm Guard Raincoat","Long raincoat with taped seams and storm hood.","1000012","Outerwear E6", 3, R.drawable.storm_guard_raincoat, null, now));

            // Mark as seeded so we don't delete and re-seed on subsequent launches.
            prefs.edit().putBoolean(KEY_SEEDED, true).apply();
        });
    }
}
