package com.sm.hopstock.auth;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.sm.hopstock.data.UserAccount;
import com.sm.hopstock.data.UserDao;
import com.sm.hopstock.data.AppDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Manages user authentication, registration, preferences, and profile updates. */
public class AuthManager {
    private static final String PREFS = "hopstock_prefs";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_SMS_ENABLED = "sms_enabled";
    private static final String KEY_IS_NEW_ACCOUNT = "is_new_account";

    private final UserDao userDao;
    private final SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    /** Constructor. */
    public AuthManager(Context context) {
        AppDatabase db = AppDatabase.getInstance(context);
        userDao = db.userDao();
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Register a new user. */
    public void registerUserAsync(String username, char[] password, String firstName, String lastName, String phone, AuthCallback callback) {
        executor.execute(() -> {
            boolean created = false;
            if (userDao.getByUsername(username) == null) {
                String salt = AuthUtils.generateSalt();
                String hash = AuthUtils.hashPassword(password, salt);
                UserAccount user = new UserAccount(username, hash, salt, firstName, lastName, phone, System.currentTimeMillis());
                long id = userDao.insert(user);
                created = id > 0;
                if (created) {
                    // Store user ID, cache SMS preference, and mark as new account
                    prefs.edit()
                        .putLong(KEY_USER_ID, id)
                        .putBoolean(KEY_SMS_ENABLED, user.smsEnabled)
                        .putBoolean(KEY_IS_NEW_ACCOUNT, true)
                        .apply();
                }
            }
            final boolean result = created;
            mainHandler.post(() -> { if (callback != null) callback.onComplete(result); });
        });
    }

    /** Asynchronously authenticate a user on a background thread. Callback runs on the main thread. */
    public void authenticateAsync(String username, char[] password, AuthCallback callback) {
        executor.execute(() -> {
            UserAccount user = userDao.getByUsername(username);
            boolean ok = false;
            if (user != null) {
                ok = AuthUtils.verifyPassword(password, user.salt, user.passwordHash);
                if (ok) {
                    // Store user ID and cache SMS preference
                    prefs.edit()
                        .putLong(KEY_USER_ID, user.userId)
                        .putBoolean(KEY_SMS_ENABLED, user.smsEnabled)
                        .apply();
                }
            }
            final boolean result = ok;
            mainHandler.post(() -> { if (callback != null) callback.onComplete(result); });
        });
    }

    /** Logs out the current user. */
    public void logout() {
        // Clear stored user ID and cached preferences
        prefs.edit()
            .remove(KEY_USER_ID)
            .remove(KEY_SMS_ENABLED)
            .remove(KEY_IS_NEW_ACCOUNT)
            .apply();
    }

    /** Returns whether a user is currently logged in or not. */
    public boolean isLoggedIn() {
        return prefs.contains(KEY_USER_ID);
    }

    /** Returns the currently logged-in user id or -1 if none. */
    public long getCurrentUserId() {
        return prefs.getLong(KEY_USER_ID, -1);
    }

    /** Returns whether this is a newly created account that hasn't been shown the SMS prompt yet. */
    public boolean isNewAccount() {
        return prefs.getBoolean(KEY_IS_NEW_ACCOUNT, false);
    }

    /** Clear the new account flag (should be called after showing SMS prompt). */
    public void clearNewAccountFlag() {
        prefs.edit().remove(KEY_IS_NEW_ACCOUNT).apply();
    }

    /** Update user's profile and optionally password asynchronously. If newPassword is null, password is not changed. */
    public void updateUserAsync(long userId, String firstName, String lastName, String phone, boolean smsEnabled, char[] newPassword, AuthCallback callback) {
        executor.execute(() -> {
            boolean ok = false;
            UserAccount user = userDao.getById(userId);
            if (user != null) {
                user.firstName = firstName;
                user.lastName = lastName;
                user.phone = phone;
                user.smsEnabled = smsEnabled;
                if (newPassword != null) {
                    String salt = AuthUtils.generateSalt();
                    String hash = AuthUtils.hashPassword(newPassword, salt);
                    user.salt = salt;
                    user.passwordHash = hash;
                }
                userDao.update(user);
                // Update cached SMS preference
                prefs.edit().putBoolean(KEY_SMS_ENABLED, smsEnabled).apply();
                ok = true;
            }
            final boolean result = ok;
            mainHandler.post(() -> { if (callback != null) callback.onComplete(result); });
        });
    }

    /** Asynchronously load a user by id from the DB. Callback is invoked on the main thread. */
    public interface UserLoadCallback { void onLoaded(UserAccount user); }

    public void loadUserAsync(long userId, UserLoadCallback callback) {
        executor.execute(() -> {
            UserAccount user = null;
            try {
                user = userDao.getById(userId);
            } catch (Exception e) {
                Log.e("AuthManager", "Error loading user by id: " + userId, e);
            }
            final UserAccount result = user;
            mainHandler.post(() -> { if (callback != null) callback.onLoaded(result); });
        });
    }

    /** Callback interface for authentication and user update operations. */
    public interface AuthCallback {
        void onComplete(boolean success);
    }
}
