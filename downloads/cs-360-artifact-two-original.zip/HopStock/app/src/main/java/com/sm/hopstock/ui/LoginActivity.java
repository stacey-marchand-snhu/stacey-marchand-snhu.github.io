package com.sm.hopstock.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;

import com.sm.hopstock.R;
import com.sm.hopstock.auth.AuthManager;
import com.sm.hopstock.databinding.ActivityLoginBinding;
import com.sm.hopstock.databinding.DialogCreateAccountBinding;

public class LoginActivity extends AppCompatActivity {
    private AuthManager auth;

    // Local shortcuts for frequently used views.
    private EditText etUsername, etPassword;
    private Button btnLogin;
    private View spinner, overlay;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Setup view binding.
        ActivityLoginBinding binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // If we're already logged in, skip login and start the main activity.
        auth = new AuthManager(this);
        if (auth.isLoggedIn()) {
            startMain();
            return;
        }

        // Assign local shortcuts from the binding.
        etUsername = binding.etUsername;
        etPassword = binding.etPassword;
        btnLogin = binding.btnLogin;
        spinner = binding.loginProgressSpinner;
        overlay = binding.loginProgressOverlay;

        // Set HTML formatted app name.
        String htmlText = getString(R.string.app_name_html);
        binding.tvAppName.setText(Html.fromHtml(htmlText, Html.FROM_HTML_MODE_LEGACY));

        // Dynamically enable/disable login button based on username and password fields.
        TextWatcher loginButtonStatusWatcher = UiUtils.simpleTextWatcher(s -> setLoginButtonStatus());
        etUsername.addTextChangedListener(loginButtonStatusWatcher);
        etPassword.addTextChangedListener(loginButtonStatusWatcher);

        // Assign button handlers.
        btnLogin.setOnClickListener(this::handleLoginClick);
        binding.btnCreateAccount.setOnClickListener(this::handleCreateAccountClick);
    }

    /** Start the main activity and finish this one. */
    private void startMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    /** Enable or disable the login button based on field contents. */
    private void setLoginButtonStatus() {
        // Enable login button only if both username and password fields are non-empty.
        boolean userEmpty = etUsername.getText().toString().trim().isEmpty();
        boolean passwordEmpty = etPassword.getText().toString().isEmpty();
        boolean enabled = !userEmpty && !passwordEmpty;
        btnLogin.setEnabled(enabled);
        int newTint = ContextCompat.getColor(LoginActivity.this, enabled ? R.color.green_500 : R.color.button_disabled);
        DrawableCompat.setTint(btnLogin.getBackground(), newTint);
    }

    /** Handle login button click: disable UI, show spinner, authenticate asynchronously. */
    private void handleLoginClick(View v) {
        // Disable UI and show overlay + spinner.
        DrawableCompat.setTint(btnLogin.getBackground(), ContextCompat.getColor(LoginActivity.this, R.color.button_disabled));
        btnLogin.setEnabled(false);
        etUsername.setEnabled(false);
        etPassword.setEnabled(false);
        overlay.setVisibility(View.VISIBLE);
        spinner.setVisibility(View.VISIBLE);

        // Authenticate.
        String username = etUsername.getText().toString().trim();
        char[] password = etPassword.getText().toString().toCharArray();
        auth.authenticateAsync(username, password, success -> {
            if (success) {
                runOnUiThread(this::startMain);
            } else {
                // Authentication failed — inform user and restore UI.
                runOnUiThread(() -> {
                    // Guard against activity gone.
                    if (isFinishing() || isDestroyed()) return;
                    UiUtils.simpleSnackbar(this, R.string.login_attempt_failed);
                    // Re-enable UI and hide overlay/spinner.
                    setLoginButtonStatus();
                    etUsername.setEnabled(true);
                    etPassword.setEnabled(true);
                    spinner.setVisibility(View.GONE);
                    overlay.setVisibility(View.GONE);
                });
            }
        });
    }

    /** Handle Create Account button click: show dialog and manage account creation flow. */
    private void handleCreateAccountClick(View v) {
        // Use view binding for the dialog layout.
        DialogCreateAccountBinding binding = DialogCreateAccountBinding.inflate(getLayoutInflater());
        final AlertDialog dialog = new AlertDialog.Builder(this).setView(binding.getRoot()).create();

        // Get reference shortcuts to views.
        EditText etFirstName = binding.etFirstName;
        EditText etLastName = binding.etLastName;
        EditText etPhone = binding.etPhone;
        EditText etNewUsername = binding.etNewUsername;
        EditText etNewPassword = binding.etNewPassword;
        EditText etConfirmPassword = binding.etConfirmPassword;
        TextView tvCreateError = binding.tvCreateError;
        Button btnCreate = binding.btnCreate;
        Button btnCancel = binding.btnCancelCreate;

        // Dynamically enable/disable Create button based on field contents and password match.
        TextWatcher watcher = UiUtils.simpleTextWatcher(s -> {
            // Extract field contents.
            String firstName = UiUtils.getTextSafe(etFirstName);
            String lastName = UiUtils.getTextSafe(etLastName);
            String phone = UiUtils.getTextSafe(etPhone);
            String username = UiUtils.getTextSafe(etNewUsername);
            String newPassword = UiUtils.getTextSafe(etNewPassword, false);
            String confirmPassword = UiUtils.getTextSafe(etConfirmPassword, false);

            // Check if all fields are filled and passwords match.
            boolean allFilled = !firstName.isEmpty() && !lastName.isEmpty() && !phone.isEmpty() && !username.isEmpty() && !newPassword.isEmpty() && !confirmPassword.isEmpty();
            boolean passwordsMatch = newPassword.equals(confirmPassword);
            boolean enabled = allFilled && passwordsMatch;

            // Update Create Account button enabled state and color.
            btnCreate.setEnabled(enabled);
            int newTint = ContextCompat.getColor(this, enabled ? R.color.green_500 : R.color.button_disabled);
            DrawableCompat.setTint(btnCreate.getBackground(), newTint);

            // Show/hide password mismatch error.
            if (!passwordsMatch && !newPassword.isEmpty() && !confirmPassword.isEmpty()) {
                tvCreateError.setText(R.string.passwords_do_not_match);
                tvCreateError.setVisibility(View.VISIBLE);
            } else {
                tvCreateError.setVisibility(View.GONE);
            }
        });

        // Attach watcher to all required text fields.
        etFirstName.addTextChangedListener(watcher);
        etLastName.addTextChangedListener(watcher);
        etPhone.addTextChangedListener(watcher);
        etNewUsername.addTextChangedListener(watcher);
        etNewPassword.addTextChangedListener(watcher);
        etConfirmPassword.addTextChangedListener(watcher);

        // Cancel button handler.
        btnCancel.setOnClickListener(x -> dialog.dismiss());

        // Create Account button handler.
        btnCreate.setOnClickListener(x -> {
            String firstName = UiUtils.getTextSafe(etFirstName);
            String lastName = UiUtils.getTextSafe(etLastName);
            String phone = UiUtils.getTextSafe(etPhone);
            String username = UiUtils.getTextSafe(etNewUsername);
            char[] password = UiUtils.getTextSafe(etNewPassword, false).toCharArray();

            tvCreateError.setVisibility(View.GONE);

            // Attempt to create the account.
            auth.registerUserAsync(username, password, firstName, lastName, phone, created -> this.runOnUiThread(() -> {
                if (created) {
                    dialog.dismiss();
                    startMain();
                } else {
                    tvCreateError.setText(R.string.username_already_exists);
                    tvCreateError.setVisibility(View.VISIBLE);
                }
            }));
        });

        dialog.show();
    }
}
