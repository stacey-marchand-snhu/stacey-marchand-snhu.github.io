package com.sm.hopstock.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    UserAccount getByUsername(String username);

    @Query("SELECT * FROM users WHERE userId = :id LIMIT 1")
    UserAccount getById(long id);

    @androidx.room.Update
    int update(UserAccount user);

    @Insert
    long insert(UserAccount user);
}
