package com.sm.hopstock.ui;

import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

/** Small UI helpers used across activities/fragments. */
public final class UiUtils {
    private UiUtils() {}

    /**
     * Safely extract text from an EditText, handling the rare case where getText() might return null.
     * @param editText the EditText to extract text from
     * @param trim whether to trim whitespace (default true)
     * @return the text as a String, or empty string if null
     */
    public static String getTextSafe(EditText editText, boolean trim) {
        if (editText == null) return "";
        Editable text = editText.getText();
        if (text == null) return "";
        String result = text.toString();
        return trim ? result.trim() : result;
    }

    /** Overload of getTextSafe with trim defaulting to true */
    public static String getTextSafe(EditText editText) {
        return getTextSafe(editText, true);
    }

    /**
     * Find the toolbar by resource id on the provided activity, configure it as the support
     * action bar, set title/up affordance. The activity layouts should have
     * android:fitsSystemWindows="true" on their root to handle status bar insets properly.
     *
     * @param activity host activity
     * @param toolbarResId resource id of the toolbar (for example R.id.toolbar)
     * @param titleResId title resource id to set on the action bar (pass 0 to skip)
     * @param displayHomeAsUp whether to enable the Up affordance
     */
    public static void setupActionBar(AppCompatActivity activity, int toolbarResId, int titleResId, boolean displayHomeAsUp) {
        if (activity == null) return;
        View v = activity.findViewById(toolbarResId);
        if (v == null) return;
        // Verify it's a Toolbar and configure it via the activity's support action bar APIs
        if (v instanceof androidx.appcompat.widget.Toolbar) {
            androidx.appcompat.widget.Toolbar toolbar = (androidx.appcompat.widget.Toolbar) v;
            activity.setSupportActionBar(toolbar);
            if (activity.getSupportActionBar() != null) {
                if (titleResId != 0) activity.getSupportActionBar().setTitle(titleResId);
                activity.getSupportActionBar().setDisplayHomeAsUpEnabled(displayHomeAsUp);
            }
        }
    }

    /** Functional interface for text change callbacks that receive the changed CharSequence. */
    public interface OnTextChange {
        void onTextChanged(CharSequence s);
    }

    /**
     * Factory that returns a TextWatcher which invokes the given callback on onTextChanged,
     * passing the CharSequence that was modified.
     */
    public static TextWatcher simpleTextWatcher(final OnTextChange onChange) {
        return new TextWatcher() {
            @Override public void afterTextChanged(Editable s) {}
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (onChange != null) {
                    try { onChange.onTextChanged(s); } catch (Exception e) {
                        Log.e("UiUtils", "Error in simpleTextWatcher callback", e);
                    }
                }
            }
        };
    }

    /**
     * Internal helper that creates a Snackbar attached to the Activity's root view and falls
     * back to a Toast when the root is unavailable. Centralizes action handling and exceptions.
     */
    private static void showSnackbarInternal(final Activity activity, final CharSequence message, final int actionResId, final View.OnClickListener action) {
        if (activity == null) return;
        View root = activity.findViewById(android.R.id.content);
        if (root != null) {
            try {
                // Show Snackbar with optional action.
                Snackbar sb = Snackbar.make(root, message, Snackbar.LENGTH_LONG);
                if (actionResId != 0 && action != null) {
                    sb.setAction(actionResId, action);
                }
                sb.show();
                return;
            } catch (Exception e) {
                Log.e("UiUtils", "Error showing Snackbar", e);
            }
        }
        // Fallback uses Toast (action ignored).
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
    }

    /**
     * Simple snackbar helper that attaches to the Activity's root view (android.R.id.content).
     * Falls back to a Toast if the root isn't available. This single helper accepts only a
     * string resource id and uses LENGTH_LONG by default.
     */
    public static void simpleSnackbar(final Activity activity, final int messageResId) {
        if (activity == null) return;
        showSnackbarInternal(activity, activity.getString(messageResId), 0, null);
    }

    /**
     * Overload of simpleSnackbar that accepts an action (resource id and click listener).
     * If the root view is not available the message is shown as a Toast and the action is ignored.
     *
     * @param activity host activity
     * @param messageResId message string resource id
     * @param actionResId action string resource id to show on the Snackbar (pass 0 to skip)
     * @param action click listener for the action (may be null if actionResId is 0)
     */
    public static void simpleSnackbar(final Activity activity, final int messageResId, final int actionResId, final View.OnClickListener action) {
        if (activity == null) return;
        showSnackbarInternal(activity, activity.getString(messageResId), actionResId, action);
    }
}
