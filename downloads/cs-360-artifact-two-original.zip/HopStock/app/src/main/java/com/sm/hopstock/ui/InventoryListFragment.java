package com.sm.hopstock.ui;

import static com.sm.hopstock.ui.ItemDeletionHelper.showDeleteConfirmation;
import static com.sm.hopstock.ui.UiUtils.simpleSnackbar;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.sm.hopstock.R;
import com.sm.hopstock.auth.AuthManager;
import com.sm.hopstock.data.InventoryItem;
import com.sm.hopstock.data.Repository;
import com.sm.hopstock.data.SeedUtil;
import com.sm.hopstock.notifications.SmsUtils;
import com.sm.hopstock.databinding.FragmentInventoryListBinding;

import java.util.List;

/** Fragment displaying the inventory list with search and filtering capabilities. */
public class InventoryListFragment extends Fragment implements InventoryAdapter.ItemClickListener {
    private Repository repo;
    private InventoryAdapter adapter;
    private LiveData<List<InventoryItem>> currentLiveData;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable searchRunnable;

    private FragmentInventoryListBinding binding;

    // Local shortcuts for frequently used views.
    private Button btnFilterOutOfStock;
    private RecyclerView rv;
    private TextView tvEmpty;
    private ImageButton btnClear;

    private boolean isFilteringOutOfStock = false;
    private ActivityResultLauncher<String> smsPermissionLauncher;
    private Long pendingScrollToItemId = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentInventoryListBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize SMS permission launcher
        smsPermissionLauncher = SmsUtils.createSmsPermissionLauncher(this);

        // Assign local shortcuts from binding.
        rv = binding.recyclerView;
        tvEmpty = binding.tvEmpty;
        btnClear = binding.btnClearSearch;
        btnFilterOutOfStock = binding.btnFilterOutOfStock;
        FloatingActionButton fabAdd = binding.fabAdd;
        EditText etSearch = binding.etSearch;

        // Initialize repository.
        repo = new Repository(requireContext());

        // Check if this is a new account and prompt for SMS permission.
        AuthManager auth = new AuthManager(requireContext());
        if (auth.isNewAccount()) {
            // Clear the flag immediately so we don't show again.
            auth.clearNewAccountFlag();
            // Show SMS permission prompt if SMS is enabled and permission not granted.
            if (SmsUtils.isSmsEnabled(requireContext()) && !SmsUtils.isSmsPermissionGranted(requireContext())) {
                // Use post to ensure fragment is fully created first.
                view.post(() -> SmsUtils.showSmsPermissionRequestDialog(this, smsPermissionLauncher));
            }
        }

        // Seed inventory with sample data.
        SeedUtil.seedInventory(requireContext());

        // Setup RecyclerView and its adapter with grid layout.
        rv.setLayoutManager(new GridLayoutManager(requireContext(), 1));
        adapter = new InventoryAdapter(this);
        rv.setAdapter(adapter);

        // Initially observe full inventory list.
        observeAll();

        // Handle add button click to navigate to ItemDetailFragment for new item.
        fabAdd.setOnClickListener(v -> navigateToItemDetail(null));

        // Search box text change handling with debounce.
        etSearch.addTextChangedListener(UiUtils.simpleTextWatcher(this::handleSearchTextChange));

        // Clear button clears search box and resets list.
        btnClear.setVisibility(View.GONE);
        btnClear.setOnClickListener(v -> {
            etSearch.setText("");
            if (searchRunnable != null) handler.removeCallbacks(searchRunnable);
            observeAll();
        });

        // Out-of-stock filter button toggles filtering for items with quantity = 0.
        btnFilterOutOfStock.setOnClickListener(v -> {
            isFilteringOutOfStock = !isFilteringOutOfStock;
            updateFilterButtonState();
            if (isFilteringOutOfStock) {
                observeOutOfStock();
            } else {
                observeAll();
            }
            etSearch.setText(""); // Clear search when toggling filter
            btnClear.setVisibility(View.GONE);
        });
    }


    /** Handle search box text changes with debounce. */
    private void handleSearchTextChange(CharSequence s) {
        // Debounce for 500ms.
        btnClear.setVisibility(s.toString().isEmpty() ? View.GONE : View.VISIBLE);

        // Remove any pending search runnable.
        if (searchRunnable != null) handler.removeCallbacks(searchRunnable);
        final String searchString = s.toString();

        // Create new runnable to perform search after delay.
        searchRunnable = () -> {
            if (searchString.trim().isEmpty()) {
                // Restore appropriate view based on filter state.
                if (isFilteringOutOfStock) {
                    observeOutOfStock();
                } else {
                    observeAllInternal();
                }
            } else {
                observeSearch(searchString);
            }
        };
        handler.postDelayed(searchRunnable, 500);
    }


    /** Handle fragment resume to show snackbars for operations performed in ItemDetailFragment. */
    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences prefs = requireContext().getSharedPreferences("com.sm.hopstock.PREFS", android.content.Context.MODE_PRIVATE);

        // Check for item operations saved by ItemDetailFragment (now includes SMS status).
        String itemOperation = prefs.getString("pref_item_operation", null);
        if (itemOperation != null) {
            prefs.edit().remove("pref_item_operation").apply();

            // Show snackbar based on operation type.
            switch (itemOperation) {
                case "created":
                    simpleSnackbar(requireActivity(), R.string.item_created);
                    // Scroll to the newly created item if we have its ID.
                    long newItemId = prefs.getLong("pref_new_item_id", -1);
                    if (newItemId != -1) {
                        prefs.edit().remove("pref_new_item_id").apply();
                        pendingScrollToItemId = newItemId;
                    }
                    break;
                case "updated":
                    simpleSnackbar(requireActivity(), R.string.item_updated);
                    break;
                case "deleted":
                    simpleSnackbar(requireActivity(), R.string.item_deleted);
                    break;
                case "out_of_stock_alert_sent":
                    simpleSnackbar(requireActivity(), R.string.sms_sent_message);
                    break;
                case "out_of_stock_no_recipient":
                    simpleSnackbar(requireActivity(), R.string.sms_no_recipient);
                    break;
                case "out_of_stock_alert_failed":
                    simpleSnackbar(requireActivity(), R.string.sms_failed);
                    break;
                case "out_of_stock_alert_permission_denied":
                    // Item updated but SMS permission denied. Show snackbar with Settings action.
                    View root = requireActivity().findViewById(android.R.id.content);
                    Snackbar sb = Snackbar.make(root, R.string.sms_permission_denied, Snackbar.LENGTH_LONG);
                    sb.setAction(requireActivity().getString(R.string.settings), v -> {
                        // Set flag in SharedPreferences before opening settings
                        prefs.edit().putBoolean("opened_settings_for_sms", true).apply();
                        SmsUtils.openAppPermissions(requireActivity());
                    });
                    sb.show();
                    break;
            }
            return;
        }

        // Check if we returned from settings after attempting to enable SMS permissions.
        SmsUtils.handleReturnFromSettings(requireActivity());
    }

    /** Update the inventory list based on the current LiveData source. */
    private void updateInventoryList() {
        currentLiveData.observe(getViewLifecycleOwner(), inventoryItems -> {
            adapter.submitList(inventoryItems);
            if (inventoryItems == null || inventoryItems.isEmpty()) {
                tvEmpty.setVisibility(View.VISIBLE);
                rv.setVisibility(View.GONE);
            } else {
                tvEmpty.setVisibility(View.GONE);
                rv.setVisibility(View.VISIBLE);

                // Scroll to pending item if we have one.
                if (pendingScrollToItemId != null) {
                    scrollToItemById(pendingScrollToItemId);
                    pendingScrollToItemId = null;
                }
            }
        });
    }

    /** Switch observation to the full inventory list and reset filter state. */
    private void observeAll() {
        isFilteringOutOfStock = false;
        updateFilterButtonState();
        observeAllInternal();
    }

    /** Internal method to observe the full inventory list without changing filter state. */
    private void observeAllInternal() {
        if (currentLiveData != null) currentLiveData.removeObservers(getViewLifecycleOwner());
        currentLiveData = repo.getAll();
        updateInventoryList();
    }

    /** Switch observation to search results for the given query. */
    private void observeSearch(String query) {
        if (currentLiveData != null) currentLiveData.removeObservers(getViewLifecycleOwner());
        currentLiveData = repo.search(query);
        updateInventoryList();
    }

    /** Switch observation to out-of-stock items only. */
    private void observeOutOfStock() {
        if (currentLiveData != null) currentLiveData.removeObservers(getViewLifecycleOwner());
        currentLiveData = repo.getOutOfStock();
        updateInventoryList();
    }

    /** Update the filter button appearance based on current filter state. */
    private void updateFilterButtonState() {
        int color = isFilteringOutOfStock ? R.color.green_500 : R.color.button_disabled;
        btnFilterOutOfStock.setBackgroundColor(ContextCompat.getColor(requireContext(), color));
    }

    /** Handle inventory item click to navigate to ItemDetailFragment. */
    @Override
    public void onItemClick(InventoryItem item) {
        navigateToItemDetail(item.itemId);
    }

    /** Handle inventory item delete click with confirmation dialog. */
    @Override
    public void onItemDelete(InventoryItem item) {
        showDeleteConfirmation(requireContext(), item, repo, () -> {
            // Show snackbar confirmation after deletion.
            simpleSnackbar(requireActivity(), R.string.item_deleted);
        });
    }

    /** Navigate to the ItemDetailFragment. */
    private void navigateToItemDetail(@Nullable Long itemId) {
        ItemDetailFragment fragment = ItemDetailFragment.newInstance(itemId);
        requireActivity().getSupportFragmentManager().beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit();
    }

    /** Scroll to an item by its ID in the RecyclerView. */
    private void scrollToItemById(long itemId) {
        List<InventoryItem> currentList = adapter.getCurrentList();
        for (int i = 0; i < currentList.size(); i++) {
            if (currentList.get(i).itemId == itemId) {
                rv.smoothScrollToPosition(i);
                break;
            }
        }
    }

    /** Clean up binding on view destruction. */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
