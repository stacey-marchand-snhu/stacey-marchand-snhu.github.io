package com.sm.hopstock.ui;

import static com.sm.hopstock.ui.ItemDeletionHelper.deleteImageFromInternalStorage;
import static com.sm.hopstock.ui.ItemDeletionHelper.showDeleteConfirmation;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;

import com.sm.hopstock.R;
import com.sm.hopstock.data.InventoryItem;
import com.sm.hopstock.data.Repository;
import com.sm.hopstock.databinding.FragmentItemDetailBinding;
import com.sm.hopstock.notifications.SmsUtils;

import java.util.Date;

/** Fragment for viewing and editing item details. */
public class ItemDetailFragment extends Fragment {
    private static final String ARG_ITEM_ID = "itemId";

    private Repository repo;
    private InventoryItem current;

    private FragmentItemDetailBinding binding;

    // Local shortcuts for frequently used views.
    private EditText etName, etDescription, etSku, etLocation, etQuantity;
    private Button btnDecrease;
    private Button btnIncrease;
    private Button btnSave;
    private ImageView detailImage;
    private TextView tvImageLabel;

    private Uri selectedImageUri = null;

    // Original values loaded from DB to detect changes.
    private Uri originalImageUri = null;
    private String originalName = "";
    private String originalDescription = "";
    private String originalSku = "";
    private String originalLocation = "";
    private int originalQuantity = 0;

    private ActivityResultLauncher<PickVisualMediaRequest> photoPickerLauncher;
    private ActivityResultLauncher<String[]> openDocumentLauncher;

    private OnBackPressedCallback backPressedCallback;

    public static ItemDetailFragment newInstance(@Nullable Long itemId) {
        ItemDetailFragment fragment = new ItemDetailFragment();
        Bundle args = new Bundle();
        if (itemId != null) {
            args.putLong(ARG_ITEM_ID, itemId);
        }
        fragment.setArguments(args);
        return fragment;
    }

    /** Returns true if this fragment is adding a new item. */
    public boolean isAddingNewItem() {
        return getArguments() == null || !getArguments().containsKey(ARG_ITEM_ID);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentItemDetailBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        repo = new Repository(requireContext());

        // Setup menu provider to handle options menu.
        requireActivity().addMenuProvider(createMenuProvider(), getViewLifecycleOwner(), Lifecycle.State.RESUMED);

        // Initialize image picker launchers.
        photoPickerLauncher = registerForActivityResult(
            new ActivityResultContracts.PickVisualMedia(),
            this::handleSelectedImageUri
        );
        openDocumentLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            this::handleOpenDocumentResult
        );

        // Assign local shortcuts from the binding.
        etName = binding.etName;
        etDescription = binding.etDescription;
        etSku = binding.etSku;
        etLocation = binding.etLocation;
        etQuantity = binding.etQuantity;
        detailImage = binding.detailImage;
        tvImageLabel = binding.tvImageLabel;
        btnSave = binding.btnSave;
        Button btnDelete = binding.btnDelete;
        btnDecrease = binding.btnDecrease;
        btnIncrease = binding.btnIncrease;

        // Handle back press using AndroidX OnBackPressedDispatcher
        backPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() { handleBackPress(); }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), backPressedCallback);

        // Allow tapping the image to select from device album.
        detailImage.setOnClickListener(v -> openImagePicker());
        tvImageLabel.setOnClickListener(v -> openImagePicker());

        // Quick +/- buttons.
        btnDecrease.setOnClickListener(v -> adjustQuantity(-1));
        btnIncrease.setOnClickListener(v -> adjustQuantity(1));

        Bundle args = getArguments();
        if (args != null && args.containsKey(ARG_ITEM_ID)) {
            // Existing item: Load from database.
            long itemId = args.getLong(ARG_ITEM_ID);
            repo.getById(itemId, item -> {
                current = item;
                requireActivity().runOnUiThread(() -> {
                    populateFields();
                    captureOriginals();
                    wireChangeListeners();
                });
            });
        } else {
            // New item: Wire listeners and keep originals empty.
            captureOriginals();
            wireChangeListeners();
            // Change delete button to "Cancel" for new items.
            btnDelete.setText(R.string.cancel);
        }

        // Save and Delete button handlers.
        btnSave.setOnClickListener(v -> handleSaveClick());
        btnDelete.setOnClickListener(v -> handleDeleteClick());
    }

    /** Opens the device's image picker to select a photo from the album. */
    private void openImagePicker() {
        if (ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(requireContext())) {
            PickVisualMediaRequest request = new PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                .build();
            photoPickerLauncher.launch(request);
        } else {
            // SAF fallback provides broad compatibility and supports persistable access.
            openDocumentLauncher.launch(new String[] {"image/*"});
        }
    }

    /**
     * Copy an image from an external URI to internal storage.
     * Returns the internal file URI, or null if the copy failed.
     */
    private Uri copyImageToInternalStorage(Uri sourceUri) {
        java.io.File destFile = new java.io.File(requireContext().getFilesDir(),
            "item_image_" + System.currentTimeMillis() + ".jpg");
        try (java.io.InputStream inputStream = requireContext().getContentResolver().openInputStream(sourceUri);
             java.io.FileOutputStream outputStream = new java.io.FileOutputStream(destFile)) {
            if (inputStream == null) return null;
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            return Uri.fromFile(destFile);
        } catch (Exception e) {
            android.util.Log.e("ItemDetailFragment", "Failed to copy image to internal storage", e);
            return null;
        }
    }

    /** Saves the item after validation passes. */
    private void saveItem(String name, String description, String sku, String location, int quantity) {
        String imageUriString = selectedImageUri != null ? selectedImageUri.toString() : null;

        if (current == null) {
            // For new items, create with the selected image URI and clear imageResId.
            InventoryItem item = new InventoryItem(name, description, sku, location, quantity, 0, imageUriString, new Date().getTime());
            repo.insert(item, id -> requireActivity().runOnUiThread(() -> {
                // Store operation type and new item ID for InventoryListFragment to show snackbar and scroll to it.
                SharedPreferences prefs = requireContext().getSharedPreferences("com.sm.hopstock.PREFS", android.content.Context.MODE_PRIVATE);
                prefs.edit()
                    .putString("pref_item_operation", "created")
                    .putLong("pref_new_item_id", id)
                    .apply();
                requireActivity().getSupportFragmentManager().popBackStack();
            }));
        } else {
            // For existing items, delete the old image if we're replacing it with a new one.
            if (originalImageUri != null && !originalImageUri.equals(selectedImageUri)) {
                deleteImageFromInternalStorage(originalImageUri);
            }

            // Update existing item fields.
            current.name = name;
            current.description = description;
            current.sku = sku;
            current.location = location;
            current.quantity = quantity;
            current.imageUri = imageUriString;

            // Clear imageResId when using a custom URI
            if (imageUriString != null) {
                current.imageResId = 0;
            }

            // Update timestamp and save to database.
            current.updatedAt = new Date().getTime();
            repo.update(current, previousItem -> {
                // Check if quantity transitioned to zero and send SMS alert if needed.
                String itemOperation = "updated";
                if (previousItem != null && previousItem.quantity > 0 && current.quantity == 0) {
                    int smsStatus = SmsUtils.sendOutOfStockAlert(requireContext(), repo, current);
                    if (smsStatus == SmsUtils.STATUS_SENT) {
                        itemOperation = "out_of_stock_alert_sent";
                    } else if (smsStatus == SmsUtils.STATUS_PERMISSION_DENIED) {
                        itemOperation = "out_of_stock_alert_permission_denied";
                    } else if (smsStatus == SmsUtils.STATUS_NO_RECIPIENT) {
                        itemOperation = "out_of_stock_no_recipient";
                    } else if (smsStatus == SmsUtils.STATUS_FAILED) {
                        itemOperation = "out_of_stock_alert_failed";
                    }
                }

                final String finalItemOperation = itemOperation;
                requireActivity().runOnUiThread(() -> {
                    // Store operation type for InventoryListFragment to show snackbar.
                    SharedPreferences prefs = requireContext().getSharedPreferences("com.sm.hopstock.PREFS", android.content.Context.MODE_PRIVATE);
                    prefs.edit().putString("pref_item_operation", finalItemOperation).apply();

                    // Pop back stack to return to the inventory list.
                    requireActivity().getSupportFragmentManager().popBackStack();
                });
            });
        }
    }

    /**
     * Safely adjust the numeric quantity shown in the quantity EditText.
     * delta may be positive or negative. Quantity is clamped to >= 0.
     */
    private void adjustQuantity(int delta) {
        int newQuantity = 0;
        try {
            String s = etQuantity.getText().toString().trim();
            if (!s.isEmpty()) newQuantity = Integer.parseInt(s);
        } catch (NumberFormatException ignored) {}
        newQuantity += delta;
        if (newQuantity < 0) newQuantity = 0;
        etQuantity.setText(String.valueOf(newQuantity));
    }

    /** Populate the input fields with data from the current item. */
    private void populateFields() {
        if (current == null) return;
        // Populate text fields.
        etName.setText(current.name);
        etDescription.setText(current.description);
        etSku.setText(current.sku);
        etLocation.setText(current.location);
        etQuantity.setText(String.valueOf(current.quantity));

        // Load the item's image into the detail image view
        if (detailImage != null) {
            // Priority: user-selected URI > static resource > placeholder
            if (current.imageUri != null && !current.imageUri.isEmpty()) {
                try {
                    // Try to parse and load the URI.
                    selectedImageUri = Uri.parse(current.imageUri);
                    detailImage.setImageURI(selectedImageUri);
                    if (tvImageLabel != null) tvImageLabel.setVisibility(View.GONE);
                } catch (Exception e) {
                    // If URI parsing fails, fall back to placeholder.
                    detailImage.setImageResource(R.drawable.hopstock_logo);
                    if (tvImageLabel != null) tvImageLabel.setVisibility(View.VISIBLE);
                    selectedImageUri = null;
                }
            } else if (current.imageResId != 0) {
                // Load static resource image.
                detailImage.setImageResource(current.imageResId);
                if (tvImageLabel != null) tvImageLabel.setVisibility(View.GONE);
                selectedImageUri = null;
            } else {
                // No image: use placeholder.
                detailImage.setImageResource(R.drawable.placeholder);
                if (tvImageLabel != null) tvImageLabel.setVisibility(View.VISIBLE);
                selectedImageUri = null;
            }
        }
    }

    /** Capture the original input values for change detection. */
    private void captureOriginals() {
        // Store original values for change detection.
        originalName = etName.getText().toString();
        originalDescription = etDescription.getText().toString();
        originalSku = etSku.getText().toString();
        originalLocation = etLocation.getText().toString();

        // Safely parse original quantity.
        int quantity = 0;
        try {
            quantity = Integer.parseInt(etQuantity.getText().toString());
        } catch (Exception ignored) {}

        // Store original quantity and image URI.
        originalQuantity = quantity;
        originalImageUri = selectedImageUri;
        updateSaveButtonState(false);
    }

    /** Wire up change listeners to input fields to detect changes. */
    private void wireChangeListeners() {
        // Text watcher for automatically enabling/disabling Save button.
        TextWatcher watcher = UiUtils.simpleTextWatcher(s -> checkForChanges());
        etName.addTextChangedListener(watcher);
        etDescription.addTextChangedListener(watcher);
        etSku.addTextChangedListener(watcher);
        etLocation.addTextChangedListener(watcher);
        etQuantity.addTextChangedListener(watcher);

        // Quantity adjustment buttons.
        btnDecrease.setOnClickListener(v -> {
            adjustQuantity(-1);
            checkForChanges();
        });
        btnIncrease.setOnClickListener(v -> {
            adjustQuantity(1);
            checkForChanges();
        });
    }

    /** Check if any input fields have changed and update Save button state. */
    private void checkForChanges() {
        // Gather current input values.
        String name = etName.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String sku = etSku.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        int quantity = 0;
        try {
            quantity = Integer.parseInt(etQuantity.getText().toString());
        } catch (Exception ignored) {}

        // Check if all required fields are filled
        boolean allFieldsFilled = !name.isEmpty() && !description.isEmpty() && !sku.isEmpty() && !location.isEmpty();

        // Check if image changed (comparing URIs)
        boolean imageChanged = (selectedImageUri == null && originalImageUri != null) ||
                               (selectedImageUri != null && !selectedImageUri.equals(originalImageUri));

        // Check if any field has changed from originals.
        boolean changed = !name.equals(originalName) || !description.equals(originalDescription) ||
                          !sku.equals(originalSku) || !location.equals(originalLocation) ||
                          quantity != originalQuantity || imageChanged;

        // Enable save button only if all fields are filled and something has changed
        updateSaveButtonState(allFieldsFilled && changed);
    }

    /** Update the Save button's enabled state and color. */
    private void updateSaveButtonState(boolean enabled) {
        btnSave.setEnabled(enabled);
        int tint = ContextCompat.getColor(requireContext(), enabled ? R.color.green_500 : R.color.button_disabled);
        DrawableCompat.setTint(btnSave.getBackground(), tint);
    }

    private void handleSelectedImageUri(@Nullable Uri imageUri) {
        if (imageUri == null) return;
        // Copy the image to internal storage so we can access it later.
        Uri copiedUri = copyImageToInternalStorage(imageUri);
        if (copiedUri != null) {
            // Delete the old image file before replacing it.
            deleteImageFromInternalStorage(selectedImageUri);
            selectedImageUri = copiedUri;
            detailImage.setImageURI(copiedUri);
            if (tvImageLabel != null) tvImageLabel.setVisibility(View.GONE);
            checkForChanges();
        }
    }

    private void handleOpenDocumentResult(@Nullable Uri imageUri) {
        if (imageUri == null) return;
        try {
            requireContext().getContentResolver().takePersistableUriPermission(
                imageUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        } catch (SecurityException ignored) {
        }
        handleSelectedImageUri(imageUri);
    }

    /** Handle back press with unsaved changes check. */
    private void handleBackPress() {
        if (hasUnsavedChanges()) {
            // Prompt user to confirm discarding changes.
            new AlertDialog.Builder(requireContext())
                .setTitle(R.string.discard_changes_title)
                .setMessage(R.string.discard_changes_message)
                .setPositiveButton(R.string.discard, (dialog, which) -> {
                    dialog.dismiss();
                    requireActivity().getSupportFragmentManager().popBackStack();
                })
                .setNegativeButton(R.string.keep_editing, (dialog, which) -> dialog.dismiss())
                .show();
        } else {
            // No unsaved changes, just pop back.
            requireActivity().getSupportFragmentManager().popBackStack();
        }
    }

    /** Handle saving the item after validating for duplicates. */
    private void handleSaveClick() {
        // Gather input values.
        String name = etName.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String sku = etSku.getText().toString().trim();
        String location = etLocation.getText().toString().trim();

        // Safely parse quantity.
        int quantity = 0;
        try {
            quantity = Integer.parseInt(etQuantity.getText().toString());
        } catch (NumberFormatException ignored) {}
        final int finalQuantity = quantity;

        // Check for duplicate SKU and name before saving.
        long itemId = (current == null) ? 0 : current.itemId;
        repo.checkDuplicateSku(sku, itemId, skuExists -> {
            if (skuExists) {
                requireActivity().runOnUiThread(() -> UiUtils.simpleSnackbar(requireActivity(), R.string.error_duplicate_sku));
                return;
            }

            repo.checkDuplicateName(name, itemId, nameExists -> {
                if (nameExists) {
                    requireActivity().runOnUiThread(() -> UiUtils.simpleSnackbar(requireActivity(), R.string.error_duplicate_name));
                    return;
                }

                // No duplicates, proceed with save.
                requireActivity().runOnUiThread(() -> saveItem(name, description, sku, location, finalQuantity));
            });
        });
    }

    /** Handle deletion of the current item after user confirmation. */
    private void handleDeleteClick() {
        if (isAddingNewItem()) {
            // For new items, just go back (Cancel action).
            requireActivity().getSupportFragmentManager().popBackStack();
        } else {
            // For existing items, show delete confirmation dialog.
            showDeleteConfirmation(requireContext(), current, repo, () -> {
                // Store operation type for InventoryListFragment to show snackbar.
                SharedPreferences prefs = requireContext().getSharedPreferences("com.sm.hopstock.PREFS", Context.MODE_PRIVATE);
                prefs.edit().putString("pref_item_operation", "deleted").apply();
                requireActivity().getSupportFragmentManager().popBackStack();
            });
        }
    }


    /** Check if there are unsaved changes compared to the original values. */
    private boolean hasUnsavedChanges() {
        // Gather current input values.
        String name = etName.getText().toString();
        String description = etDescription.getText().toString();
        String sku = etSku.getText().toString();
        String location = etLocation.getText().toString();

        // Safely parse quantity.
        int quantity = 0;
        try {
            quantity = Integer.parseInt(etQuantity.getText().toString());
        } catch (Exception ignored) {}

        // Check if image changed (comparing URIs)
        boolean imageChanged = (selectedImageUri == null && originalImageUri != null) ||
                               (selectedImageUri != null && !selectedImageUri.equals(originalImageUri));

        // Determine if any field has changed from originals.
        return (!name.equals(originalName) || !description.equals(originalDescription) ||
                !sku.equals(originalSku) || !location.equals(originalLocation) ||
                quantity != originalQuantity || imageChanged);
    }



    /** Create a MenuProvider to handle the toolbar menu for this fragment. */
    private MenuProvider createMenuProvider() {
        return new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {}

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                // Handle back button in toolbar.
                if (menuItem.getItemId() == android.R.id.home) {
                    if (hasUnsavedChanges()) {
                        // Prompt user to confirm discarding changes.
                        new AlertDialog.Builder(requireContext())
                            .setTitle(R.string.discard_changes_title)
                            .setMessage(R.string.discard_changes_message)
                            .setPositiveButton(R.string.discard, (dialog, which) -> {
                                dialog.dismiss();
                                requireActivity().getSupportFragmentManager().popBackStack();
                            })
                            .setNegativeButton(R.string.keep_editing, (dialog, which) -> dialog.dismiss())
                            .show();
                    } else {
                        // No unsaved changes, just pop back.
                        requireActivity().getSupportFragmentManager().popBackStack();
                    }
                    return true;
                }
                return false;
            }
        };
    }

    /** Clean up resources on view destruction. */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (backPressedCallback != null) {
            backPressedCallback.remove();
        }
        binding = null;
    }
}
