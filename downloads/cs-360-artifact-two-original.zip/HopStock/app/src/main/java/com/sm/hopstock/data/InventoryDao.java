package com.sm.hopstock.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryDao {
    @Query("SELECT * FROM inventory_items ORDER BY name ASC")
    LiveData<List<InventoryItem>> getAll();

    @Query("SELECT * FROM inventory_items WHERE itemId = :id LIMIT 1")
    InventoryItem getById(long id);

    @Insert
    long insert(InventoryItem item);

    @Update
    void update(InventoryItem item);

    @Delete
    void delete(InventoryItem item);

    @Query("SELECT * FROM inventory_items WHERE name LIKE :query OR sku LIKE :query ORDER BY name ASC")
    LiveData<List<InventoryItem>> search(String query);

    @Query("SELECT * FROM inventory_items WHERE quantity = 0 ORDER BY name ASC")
    LiveData<List<InventoryItem>> getOutOfStock();

    @Query("SELECT * FROM inventory_items WHERE LOWER(TRIM(sku)) = LOWER(TRIM(:sku)) AND itemId != :excludeItemId LIMIT 1")
    InventoryItem findBySku(String sku, long excludeItemId);

    @Query("SELECT * FROM inventory_items WHERE LOWER(TRIM(name)) = LOWER(TRIM(:name)) AND itemId != :excludeItemId LIMIT 1")
    InventoryItem findByName(String name, long excludeItemId);

    @Query("DELETE FROM inventory_items")
    void deleteAll();
}
