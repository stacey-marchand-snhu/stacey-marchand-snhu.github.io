package com.sm.hopstock.data;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {
    final AppDatabase db;
    private final InventoryDao inventoryDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    /** Constructor. */
    public Repository(Context context) {
        db = AppDatabase.getInstance(context);
        inventoryDao = db.inventoryDao();
    }

    /** Get UserDao for accessing user data. */
    public UserDao getUserDao() {
        return db.userDao();
    }

    /** Get all inventory items as LiveData. */
    public LiveData<List<InventoryItem>> getAll() {
        return inventoryDao.getAll();
    }

    public LiveData<List<InventoryItem>> search(String query) {
        String q = "%" + query + "%";
        return inventoryDao.search(q);
    }

    /** Get all out-of-stock inventory items as LiveData. */
    public LiveData<List<InventoryItem>> getOutOfStock() {
        return inventoryDao.getOutOfStock();
    }

    /** Get an inventory item by ID asynchronously. */
    public void getById(final long id, final Callback<InventoryItem> callback) {
        executor.execute(() -> {
            InventoryItem item = inventoryDao.getById(id);
            if (callback != null) callback.onComplete(item);
        });
    }

    /** Insert a new inventory item asynchronously. */
    public void insert(final InventoryItem item, final Callback<Long> callback) {
        executor.execute(() -> {
            long id = inventoryDao.insert(item);
            if (callback != null) callback.onComplete(id);
        });
    }

    /**
     * Update an existing inventory item asynchronously.
     * Returns the previous item state via callback so the caller can detect transitions and handle business logic.
     */
    public void update(final InventoryItem item, final Callback<InventoryItem> callback) {
        executor.execute(() -> {
            // Fetch previous state before updating.
            InventoryItem before = inventoryDao.getById(item.itemId);
            inventoryDao.update(item);
            if (callback != null) callback.onComplete(before);
        });
    }

    /** Delete an inventory item asynchronously. */
    public void delete(final InventoryItem item, final Callback<Void> callback) {
        executor.execute(() -> {
            inventoryDao.delete(item);
            if (callback != null) callback.onComplete(null);
        });
    }

    /**
     * Check for duplicate SKU asynchronously, excluding the given item ID.
     * The callback returns true if a duplicate exists, false otherwise.
     */
    public void checkDuplicateSku(final String sku, final long excludeItemId, final Callback<Boolean> callback) {
        executor.execute(() -> {
            InventoryItem existing = inventoryDao.findBySku(sku, excludeItemId);
            if (callback != null) callback.onComplete(existing != null);
        });
    }

    /**
     * Check for duplicate name asynchronously, excluding the given item ID.
     * The callback returns true if a duplicate exists, false otherwise.
     */
    public void checkDuplicateName(final String name, final long excludeItemId, final Callback<Boolean> callback) {
        executor.execute(() -> {
            InventoryItem existing = inventoryDao.findByName(name, excludeItemId);
            if (callback != null) callback.onComplete(existing != null);
        });
    }

    /** Generic callback interface for asynchronous operations. */
    public interface Callback<T> {
        void onComplete(T result);
    }
}
