package com.sm.hopstock.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.sm.hopstock.R;
import com.sm.hopstock.auth.AuthManager;
import com.sm.hopstock.databinding.ActivityMainBinding;

/** Main activity that hosts fragments. Uses a single fragment container to display different screens. */
public class MainActivity extends AppCompatActivity {
    private AuthManager auth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Setup toolbar as action bar.
        UiUtils.setupActionBar(this, R.id.toolbar, R.string.browse_inventory, false);

        // Initialize auth manager.
        auth = new AuthManager(this);

        // Load the inventory list fragment if this is a fresh start.
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new InventoryListFragment())
                .commit();
        }

        // Listen for fragment changes to update the toolbar.
        getSupportFragmentManager().addOnBackStackChangedListener(this::updateToolbar);
    }

    /** Update toolbar when activity resumes to ensure it matches the current fragment. */
    @Override
    protected void onResume() {
        super.onResume();
        updateToolbar();
    }

    /** Update toolbar based on current fragment. */
    private void updateToolbar() {
        FragmentManager fm = getSupportFragmentManager();
        Fragment currentFragment = fm.findFragmentById(R.id.fragment_container);

        if (currentFragment instanceof InventoryListFragment) {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle(R.string.browse_inventory);
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            }
        } else if (currentFragment instanceof ItemDetailFragment) {
            if (getSupportActionBar() != null) {
                ItemDetailFragment detailFragment = (ItemDetailFragment) currentFragment;
                if (detailFragment.isAddingNewItem()) {
                    getSupportActionBar().setTitle(R.string.add_new_item);
                } else {
                    getSupportActionBar().setTitle(R.string.item_details);
                }
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        } else if (currentFragment instanceof ProfileFragment) {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle(R.string.profile);
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }
    }

    /** Inflate the options menu. */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Only show menu items when on the inventory list fragment.
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        if (currentFragment instanceof InventoryListFragment) {
            getMenuInflater().inflate(R.menu.main_menu, menu);
            return true;
        }
        return false;
    }

    /** Handle options menu item selections. */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here.
        if (item.getItemId() == R.id.action_logout) {
            // Log out and return to LoginActivity.
            auth.logout();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return true;
        } else if (item.getItemId() == R.id.action_profile) {
            // Navigate to profile fragment.
            getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new ProfileFragment())
                .addToBackStack(null)
                .commit();
            return true;
        } else if (item.getItemId() == android.R.id.home) {
            // Delegate to OnBackPressedDispatcher so fragments can intercept via their callbacks.
            getOnBackPressedDispatcher().onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        // Delegate to the OnBackPressedDispatcher so fragments can intercept via their callbacks.
        getOnBackPressedDispatcher().onBackPressed();
        return true;
    }
}

