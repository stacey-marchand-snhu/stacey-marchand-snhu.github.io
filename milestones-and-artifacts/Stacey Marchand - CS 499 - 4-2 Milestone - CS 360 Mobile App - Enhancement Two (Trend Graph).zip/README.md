# HopStock - Android Inventory Management App

A native Android inventory tracker for managing stock items, user accounts, SMS out-of-stock alerts, and projected depletion trends.

Originally built for SNHU CS-360. Updated for CS-499 by Stacey Marchand.

## Architecture

```
HopStock/
├── app/
│   ├── schemas/                        # Exported Room database schemas
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml     # App declaration, launcher activity, SMS permission
│       │   ├── java/com/sm/hopstock/
│       │   │   ├── HopStockApp.java    # App startup and notification channel setup
│       │   │   ├── auth/               # Account registration, login, password hashing
│       │   │   ├── data/               # Room entities, DAOs, repository, seed data, trends
│       │   │   ├── notifications/      # SMS permission and out-of-stock alert helpers
│       │   │   └── ui/                 # Activities, fragments, adapters, shared UI helpers
│       │   └── res/                    # Layouts, drawables, menus, strings, themes
│       │
│       ├── test/                       # Local JVM unit tests
│       └── androidTest/                # Instrumented Android tests
```

## Android Tech Stack

| Concern      | Library / Platform                       |
|--------------|------------------------------------------|
| Language     | Java 11                                  |
| Build system | Gradle wrapper + Android Gradle Plugin   |
| UI           | AppCompat, Material Components           |
| Persistence  | Room database backed by on-device SQLite |
| Charts       | MPAndroidChart                           |
| Testing      | JUnit                                    |

## Prerequisites

- **Android Studio** with the Android SDK installed
- **JDK 17+** for the Android Gradle Plugin
- **Android SDK Platform 36** to match `compileSdk = 36`
- An **Android emulator or physical Android device** running API 26 or newer

No backend server, cloud project, or `.env` file is required. HopStock stores its data locally on the device.

## Getting Started

Open the project in Android Studio from the repository root.
Then let Android Studio sync Gradle, select an emulator or connected device, and run the `app` configuration.

Build and test from the project root:

```powershell
# Run local unit tests
.\gradlew.bat testDebugUnitTest

# Build a debug APK
.\gradlew.bat assembleDebug

# Install on a connected emulator or device
.\gradlew.bat installDebug
```

## First Run

1. Launch HopStock.
2. Create a local account from the login screen.
3. The app opens to the inventory list after registration.
4. Sample inventory and synthetic six-month stock history are automatically seeded on first install.

To reset the local demo data, clear the app's storage from Android system settings or uninstall and reinstall the app.

## Local Data

- **Database:** Room database named `app.db`
- **Entities:**
  - `inventory_items` - item details, SKU, quantity, image, and timestamps.
  - `users` - local account and profile records.
  - `stock_history` - timestamped quantity snapshots for trend charts.
- **Seed data:** `SeedUtil` inserts sample inventory and synthetic history once per installation.
- **Migrations:** Room schema version 2 adds stock history while preserving existing inventory and user data.

## SMS Permissions

HopStock can run fully without SMS permissions. SMS is only needed if out-of-stock text alerts are enabled in the user profile.