/**
 * File: TrendCalculatorTest.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Verifies stock depletion trend calculations, projections, and edge cases.
 */
package com.sm.hopstock;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.sm.hopstock.data.StockHistoryEntry;
import com.sm.hopstock.data.TrendCalculator;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TrendCalculatorTest {
    private static final long DAY = TrendCalculator.DAY_MS;

    /** Verify null history does not produce a trend. */
    @Test
    public void calculate_nullHistory_returnsEmptyResult() {
        TrendCalculator.TrendResult result = TrendCalculator.calculate(null);

        assertFalse(result.hasTrend);
        assertNull(result.projectedOutOfStockAt);
        assertEquals(0f, result.slopePerDay, 0.001f);
    }

    /** Verify empty history does not produce a trend. */
    @Test
    public void calculate_emptyHistory_returnsEmptyResult() {
        TrendCalculator.TrendResult result = TrendCalculator.calculate(Collections.emptyList());

        assertFalse(result.hasTrend);
        assertNull(result.projectedOutOfStockAt);
    }

    /** Verify one snapshot does not produce a trend. */
    @Test
    public void calculate_singleEntry_returnsEmptyResult() {
        TrendCalculator.TrendResult result = TrendCalculator.calculate(Collections.singletonList(entry(1L, 20, 0L)));

        assertFalse(result.hasTrend);
        assertNull(result.projectedOutOfStockAt);
    }

    /** Verify that multiple snapshots on the same calendar day are not enough for a trend. */
    @Test
    public void calculate_requiresHistoryOnAtLeastTwoDifferentDays() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 20, 1_000L),
            entry(1L, 18, 3_000L)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertFalse(result.hasTrend);
    }

    /** Verify that two different days are enough to produce a trend. */
    @Test
    public void calculate_allowsHistoryAcrossDifferentDays() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 20, 0L),
            entry(1L, 18, DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertTrue(result.hasTrend);
        assertNotNull(result.projectedOutOfStockAt);
    }

    /** Verify steady depletion calculates the expected slope and projected out-of-stock date. */
    @Test
    public void calculate_steadyDepletion_projectsExpectedZeroDate() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 30, 0L),
            entry(1L, 20, 10L * DAY),
            entry(1L, 10, 20L * DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertTrue(result.hasTrend);
        assertEquals(-1f, result.slopePerDay, 0.001f);
        assertNotNull(result.projectedOutOfStockAt);
        assertEquals(30L * DAY, result.projectedOutOfStockAt.longValue());
        assertEquals(30f, result.lineStartQuantity, 0.001f);
        assertEquals(0f, result.lineEndQuantity, 0.001f);
    }

    /** Verify unordered input is sorted before regression. */
    @Test
    public void calculate_unorderedHistory_sortsBeforeCalculatingTrend() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 10, 20L * DAY),
            entry(1L, 30, 0L),
            entry(1L, 20, 10L * DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertTrue(result.hasTrend);
        assertEquals(-1f, result.slopePerDay, 0.001f);
        assertNotNull(result.projectedOutOfStockAt);
        assertEquals(30L * DAY, result.projectedOutOfStockAt.longValue());
    }

    /** Verify restock jumps are filtered out so they do not flatten the depletion slope. */
    @Test
    public void calculate_restockJump_usesDepletionPeriodsForSlope() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 30, 0L),
            entry(1L, 20, 10L * DAY),
            entry(1L, 50, 11L * DAY),
            entry(1L, 40, 21L * DAY),
            entry(1L, 30, 31L * DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertTrue(result.hasTrend);
        assertTrue(result.slopePerDay < -0.9f);
        assertTrue(result.slopePerDay > -1.1f);
        assertNotNull(result.projectedOutOfStockAt);
        assertTrue(result.projectedOutOfStockAt > 55L * DAY);
        assertTrue(result.projectedOutOfStockAt < 70L * DAY);
    }

    /** Verify stable stock has a trend line but no out-of-stock projection. */
    @Test
    public void calculate_stableStock_returnsTrendWithoutProjection() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 20, 0L),
            entry(1L, 20, 10L * DAY),
            entry(1L, 20, 20L * DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertTrue(result.hasTrend);
        assertNull(result.projectedOutOfStockAt);
        assertEquals(0f, result.slopePerDay, 0.001f);
    }

    /** Verify increasing stock has no depletion projection. */
    @Test
    public void calculate_increasingStock_returnsTrendWithoutProjection() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 10, 0L),
            entry(1L, 15, 10L * DAY),
            entry(1L, 20, 20L * DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertTrue(result.hasTrend);
        assertNull(result.projectedOutOfStockAt);
        assertTrue(result.slopePerDay >= 0f);
    }

    /** Verify a very slow depletion projection is capped to one year of line rendering. */
    @Test
    public void calculate_slowDepletion_capsRenderedTrendLineAtOneYear() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 100, 0L),
            entry(1L, 99, 10L * DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertTrue(result.hasTrend);
        assertNotNull(result.projectedOutOfStockAt);
        assertEquals(1000L * DAY, result.projectedOutOfStockAt.longValue());
        assertEquals(375L * DAY, result.lineEndAt);
        assertTrue(result.lineEndQuantity > 0f);
    }

    /** Verify repeated timestamps on different input rows still produce an empty result. */
    @Test
    public void calculate_duplicateTimestamps_returnsEmptyResult() {
        List<StockHistoryEntry> history = Arrays.asList(
            entry(1L, 20, 10L * DAY),
            entry(1L, 18, 10L * DAY)
        );

        TrendCalculator.TrendResult result = TrendCalculator.calculate(history);

        assertFalse(result.hasTrend);
    }

    /** Create a stock history entry for a test timeline. */
    private static StockHistoryEntry entry(long itemId, int quantity, long recordedAt) {
        return new StockHistoryEntry(itemId, quantity, recordedAt);
    }
}
