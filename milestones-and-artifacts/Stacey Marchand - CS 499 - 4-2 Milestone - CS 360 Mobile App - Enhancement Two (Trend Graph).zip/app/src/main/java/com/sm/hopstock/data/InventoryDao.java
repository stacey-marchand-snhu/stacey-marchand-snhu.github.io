/**
 * File: InventoryDao.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Provides Room queries for reading and mutating inventory item records.
 */
package com.sm.hopstock.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryDao {
    /** Get all inventory items as observable LiveData for the list screen. */
    @Query("SELECT * FROM inventory_items ORDER BY name ASC")
    LiveData<List<InventoryItem>> getAll();

    /** Get all items synchronously for background seed/backfill work. */
    @Query("SELECT * FROM inventory_items ORDER BY name ASC")
    List<InventoryItem> getAllSync();

    /** Count inventory rows synchronously for seed checks. */
    @Query("SELECT COUNT(*) FROM inventory_items")
    int getItemCountSync();

    /** Get one inventory item synchronously by database ID. */
    @Query("SELECT * FROM inventory_items WHERE itemId = :id LIMIT 1")
    InventoryItem getById(long id);

    /** Insert one inventory item and return the generated database ID. */
    @Insert
    long insert(InventoryItem item);

    /** Update an existing inventory item. */
    @Update
    void update(InventoryItem item);

    /** Delete an inventory item. */
    @Delete
    void delete(InventoryItem item);

    /** Search inventory items by name or SKU as observable LiveData. */
    @Query("SELECT * FROM inventory_items WHERE name LIKE :query OR sku LIKE :query ORDER BY name ASC")
    LiveData<List<InventoryItem>> search(String query);

    /** Get all inventory items with a quantity of zero. */
    @Query("SELECT * FROM inventory_items WHERE quantity = 0 ORDER BY name ASC")
    LiveData<List<InventoryItem>> getOutOfStock();

    /** Find an item with the same SKU, excluding the item currently being edited. */
    @Query("SELECT * FROM inventory_items WHERE LOWER(TRIM(sku)) = LOWER(TRIM(:sku)) AND itemId != :excludeItemId LIMIT 1")
    InventoryItem findBySku(String sku, long excludeItemId);

    /** Find an item with the same name, excluding the item currently being edited. */
    @Query("SELECT * FROM inventory_items WHERE LOWER(TRIM(name)) = LOWER(TRIM(:name)) AND itemId != :excludeItemId LIMIT 1")
    InventoryItem findByName(String name, long excludeItemId);

    /** Delete all inventory items during sample-data seeding. */
    @Query("DELETE FROM inventory_items")
    void deleteAll();
}
