/**
 * File: TrendCalculator.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Calculates depletion trends and projected out-of-stock dates from stock history.
 */
package com.sm.hopstock.data;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

/** Math helper for converting stock history into a depletion trend projection. */
public final class TrendCalculator {
    public static final long DAY_MS = 24L * 60L * 60L * 1000L;
    private static final long MAX_PROJECTION_MS = 365L * DAY_MS;

    private TrendCalculator() {}

    /**
     * Calculate the trend line and projected zero-stock date from stock history.
     * Restock jumps are offset before regression so replenishment events do not affect the depletion slope.
     */
    public static TrendResult calculate(List<StockHistoryEntry> history) {
        if (history == null || history.size() < 2) {
            return TrendResult.empty();
        }

        // Sort defensively so regression always runs on chronological stock history.
        List<StockHistoryEntry> sorted = new ArrayList<>(history);
        sorted.sort(Comparator.comparingLong(entry -> entry.recordedAt));

        StockHistoryEntry first = sorted.get(0);
        StockHistoryEntry latest = sorted.get(sorted.size() - 1);
        if (latest.recordedAt <= first.recordedAt) {
            return TrendResult.empty();
        }
        if (toEpochDay(first.recordedAt) == toEpochDay(latest.recordedAt)) {
            return TrendResult.empty();
        }

        double restockOffset = 0.0;
        int previousQuantity = first.quantity;
        int n = 0;
        double sumX = 0.0;
        double sumY = 0.0;
        double sumXY = 0.0;
        double sumX2 = 0.0;

        // Convert timestamps to day offsets and remove restock jumps from the regression input.
        for (StockHistoryEntry entry : sorted) {
            if (entry.quantity > previousQuantity) {
                restockOffset += entry.quantity - previousQuantity;
            }

            double x = (double) (entry.recordedAt - first.recordedAt) / DAY_MS;
            double y = entry.quantity - restockOffset;
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumX2 += x * x;
            n++;

            previousQuantity = entry.quantity;
        }

        // Apply least-squares regression to the adjusted quantity values.
        // Don't divide by zero.
        double denominator = n * sumX2 - sumX * sumX;
        if (denominator == 0.0) {
            return TrendResult.empty();
        }

        // The slope is the depletion rate in quantity per day. A negative slope projects depletion, while a positive slope projects growth.
        double slopePerDay = (n * sumXY - sumX * sumY) / denominator;
        double latestX = (double) (latest.recordedAt - first.recordedAt) / DAY_MS;

        // If the slope is positive or non-finite, the trend does not project depletion so return the history endpoints without a projection.
        if (!Double.isFinite(slopePerDay) || slopePerDay >= 0.0) {
            return TrendResult.withoutProjection(first.recordedAt, latest.recordedAt, latest.quantity, latestX, slopePerDay);
        }

        // Project forward from the latest real quantity using the depletion slope.
        double daysToZero = latest.quantity / -slopePerDay;
        if (!Double.isFinite(daysToZero) || daysToZero < 0.0) {
            return TrendResult.withoutProjection(first.recordedAt, latest.recordedAt, latest.quantity, latestX, slopePerDay);
        }

        // Cap the projection to a reasonable maximum so the UI does not render an excessively long trend line.
        long projectedOutOfStockAt = latest.recordedAt + Math.round(daysToZero * DAY_MS);
        long lineEndAt = projectedOutOfStockAt;
        if (lineEndAt - latest.recordedAt > MAX_PROJECTION_MS) {
            lineEndAt = latest.recordedAt + MAX_PROJECTION_MS;
        }

        // Calculate the trend line endpoints based on the regression slope and the first/latest data points.
        double firstX = 0.0;
        double lineEndX = (double) (lineEndAt - first.recordedAt) / DAY_MS;
        float lineStartQuantity = (float) Math.max(0.0, latest.quantity + slopePerDay * (firstX - latestX));
        float lineEndQuantity = (float) Math.max(0.0, latest.quantity + slopePerDay * (lineEndX - latestX));

        // Return precomputed endpoints so the UI can render the trend without knowing the regression details.
        return new TrendResult(
            true,
            first.recordedAt,
            lineEndAt,
            lineStartQuantity,
            lineEndQuantity,
            projectedOutOfStockAt,
            (float) slopePerDay
        );
    }

    /** Convert a timestamp to an epoch day so trend checks require distinct calendar days. */
    private static long toEpochDay(long timestampMs) {
        return timestampMs / DAY_MS;
    }

    /** Immutable result consumed by the stock history chart. */
    public static final class TrendResult {
        public final boolean hasTrend;
        public final long lineStartAt;
        public final long lineEndAt;
        public final float lineStartQuantity;
        public final float lineEndQuantity;
        public final Long projectedOutOfStockAt;
        public final float slopePerDay;

        private TrendResult(boolean hasTrend, long lineStartAt, long lineEndAt, float lineStartQuantity,
                            float lineEndQuantity, Long projectedOutOfStockAt, float slopePerDay) {
            this.hasTrend = hasTrend;
            this.lineStartAt = lineStartAt;
            this.lineEndAt = lineEndAt;
            this.lineStartQuantity = lineStartQuantity;
            this.lineEndQuantity = lineEndQuantity;
            this.projectedOutOfStockAt = projectedOutOfStockAt;
            this.slopePerDay = slopePerDay;
        }

        /** Result used when there is not enough data to draw a useful trend. */
        private static TrendResult empty() {
            return new TrendResult(false, 0L, 0L, 0f, 0f, null, 0f);
        }

        /** Result used when history exists but the data does not show a depletion projection. */
        private static TrendResult withoutProjection(long firstAt, long latestAt, int latestQuantity, double latestX, double slopePerDay) {
            float lineStartQuantity = (float) Math.max(0.0, latestQuantity + slopePerDay * -latestX);
            return new TrendResult(
                true,
                firstAt,
                latestAt,
                lineStartQuantity,
                latestQuantity,
                null,
                (float) slopePerDay
            );
        }
    }
}
