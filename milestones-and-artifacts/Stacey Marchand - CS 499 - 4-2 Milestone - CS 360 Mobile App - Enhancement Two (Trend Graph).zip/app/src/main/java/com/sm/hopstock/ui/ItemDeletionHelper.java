/**
 * File: ItemDeletionHelper.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Centralizes item deletion confirmation and cleanup behavior.
 */
package com.sm.hopstock.ui;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.appcompat.app.AlertDialog;

import com.sm.hopstock.R;
import com.sm.hopstock.data.InventoryItem;
import com.sm.hopstock.data.Repository;

/** Utility class for common item deletion operations across the app. */
public class ItemDeletionHelper {
    private static final String TAG = "ItemDeletionHelper";

    /** Interface for callbacks after item deletion. */
    public interface DeletionCallback {
        void onItemDeleted();
    }

    /**
     * Show a confirmation dialog and delete the item if confirmed.
     * Handles image cleanup and repository deletion.
     *
     * @param context The context for showing the dialog
     * @param item The item to delete
     * @param repo The repository for database operations
     * @param callback Callback to execute after successful deletion (on UI thread)
     */
    public static void showDeleteConfirmation(
            Context context,
            InventoryItem item,
            Repository repo,
            DeletionCallback callback) {

        // If the item is null, try to use the callback anyways. Otherwise, do nothing.
        if (item == null) {
            if (callback != null) callback.onItemDeleted();
            return;
        }

        new AlertDialog.Builder(context)
            .setTitle(R.string.delete_item)
            .setMessage(R.string.item_delete_confirmation)
            .setPositiveButton(R.string.delete, (dialog, which) -> {
                // Delete the associated image file if it exists from internal storage.
                if (item.imageUri != null && !item.imageUri.isEmpty()) {
                    try {
                        //
                        Uri imageUri = Uri.parse(item.imageUri);
                        deleteImageFromInternalStorage(imageUri);
                    } catch (Exception e) {
                        Log.w(TAG, "Failed to parse/delete image URI during item deletion", e);
                    }
                }

                // Delete the item from the repository.
                repo.delete(item, unused -> {
                    // Execute callback on UI thread if provided.
                    if (callback != null) {
                        if (context instanceof Activity) {
                            ((Activity) context).runOnUiThread(callback::onItemDeleted);
                        } else {
                            callback.onItemDeleted();
                        }
                    }
                });
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    /**
     * Delete an image file from internal storage based on its URI.
     *
     * @param imageUri The URI of the image to delete
     */
    public static void deleteImageFromInternalStorage(Uri imageUri) {
        if (imageUri == null) return;
        try {
            // Only delete if it's a file:// URI (our internal storage)
            if ("file".equals(imageUri.getScheme())) {
                String path = imageUri.getPath();
                if (path == null) return;
                java.io.File file = new java.io.File(path);
                if (file.exists() && file.delete()) {
                    Log.d(TAG, "Deleted old image: " + file.getName());
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Failed to delete old image: " + e.getMessage(), e);
        }
    }
}
