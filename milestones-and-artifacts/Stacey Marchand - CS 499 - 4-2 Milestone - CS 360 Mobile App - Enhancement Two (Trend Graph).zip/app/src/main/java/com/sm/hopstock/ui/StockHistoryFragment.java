/**
 * File: StockHistoryFragment.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Displays stored stock history and a projected depletion trend chart for one item.
 */
package com.sm.hopstock.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;

import com.github.mikephil.charting.listener.ChartTouchListener;
import com.github.mikephil.charting.listener.OnChartGestureListener;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.sm.hopstock.R;
import com.sm.hopstock.data.Repository;
import com.sm.hopstock.data.StockHistoryEntry;
import com.sm.hopstock.data.TrendCalculator;
import com.sm.hopstock.databinding.FragmentInventoryGraphBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Fragment that shows stored stock history with a best-fit depletion trend line. */
public class StockHistoryFragment extends Fragment {
    private static final String ARG_ITEM_ID = "itemId";

    private Repository repo;
    private FragmentInventoryGraphBinding binding;

    /** Create the fragment for the selected inventory item. */
    public static StockHistoryFragment newInstance(long itemId) {
        StockHistoryFragment fragment = new StockHistoryFragment();
        Bundle args = new Bundle();
        args.putLong(ARG_ITEM_ID, itemId);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentInventoryGraphBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        repo = Repository.getInstance(requireContext());

        // Get the item ID from the fragment arguments and load its stock history.
        // If no valid ID was passed, show an empty chart.
        long itemId = getArguments() != null ? getArguments().getLong(ARG_ITEM_ID, -1L) : -1L;
        if (itemId == -1L) {
            binding.tvGraphItemName.setText(R.string.item_details);
            configureEmptyChart(binding.inventoryLineChart);
            return;
        }

        // Load the item name separately from the history stream so the title stays current.
        repo.getById(itemId, item -> {
            if (!isAdded() || isDetached() || binding == null || item == null) return;
            binding.getRoot().post(() -> {
                if (!isAdded() || isDetached() || binding == null) return;
                binding.tvGraphItemName.setText(item.name);
            });
        });

        // Add a back button to the toolbar and handle it here since this fragment is added on top of the item details screen.
        requireActivity().addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {}

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                // The only menu item in this screen is the Up button, so pop the back stack when it is tapped.
                if (menuItem.getItemId() == android.R.id.home) {
                    requireActivity().getSupportFragmentManager().popBackStack();
                    return true;
                }
                return false;
            }
        }, getViewLifecycleOwner(), Lifecycle.State.RESUMED);

        // Observe Room LiveData so new stock snapshots redraw the chart while this screen is open.
        repo.getStockHistoryForItem(itemId).observe(getViewLifecycleOwner(), this::renderHistory);
    }

    /** Convert persisted history rows into chart entries, trend entries, and summary text. */
    private void renderHistory(List<StockHistoryEntry> history) {
        if (history == null || history.isEmpty()) {
            configureEmptyChart(binding.inventoryLineChart);
            binding.tvDepletionRate.setText(R.string.not_enough_stock_history_rate);
            binding.tvProjection.setText(R.string.no_stock_history);
            return;
        }

        // Sort the history by recorded date so the chart line and trend calculations are accurate.
        List<StockHistoryEntry> sorted = new ArrayList<>(history);
        sorted.sort(Comparator.comparingLong(entry -> entry.recordedAt));

        // The x-axis is based on recorded dates, so find the time bounds to configure the axis.
        long baseMs = sorted.get(0).recordedAt;
        long latestMs = sorted.get(sorted.size() - 1).recordedAt;

        // Calculate the depletion trend line based on the sorted history.
        TrendCalculator.TrendResult trend = TrendCalculator.calculate(sorted);

        // Actual stock entries use fractional day offsets so sub-day timing is preserved on the chart.
        // A separate marker list highlights only the first snapshot and quantity changes.
        List<Entry> actualEntries = new ArrayList<>();
        List<Entry> changedEntries = new ArrayList<>();
        float maxQuantity = 0f;
        Integer previousQuantity = null;

        // Iterate in order so the trend line and marker logic can compare each entry to the previous one.
        for (int i = 0; i < sorted.size(); i++) {
            StockHistoryEntry entry = sorted.get(i);
            float x = daysSince(baseMs, entry.recordedAt);
            float y = entry.quantity;
            Entry chartEntry = new Entry(x, y);
            actualEntries.add(chartEntry);

            // Add a marker entry when the quantity changes from the previous entry,
            // or for the first entry to mark the start of history.
            if (previousQuantity == null || entry.quantity != previousQuantity) {
                int adjustment = previousQuantity == null ? 0 : entry.quantity - previousQuantity;
                Entry markerEntry = new Entry(
                    x,
                    y,
                    new StockHistoryMarkerView.MarkerInfo(entry.recordedAt, entry.quantity, adjustment)
                );
                changedEntries.add(markerEntry);
            }

            // Track the maximum quantity for axis scaling so the chart has padding above the highest point.
            previousQuantity = entry.quantity;
            maxQuantity = Math.max(maxQuantity, y);
        }

        // Draw the full stock history as a plain line without circles. Marker circles are a second,
        // transparent-line dataset so taps focus only on quantity changes.
        LineDataSet actualSet = new LineDataSet(actualEntries, getString(R.string.actual_stock));
        actualSet.setColor(Color.parseColor("#2E7D32"));
        actualSet.setLineWidth(2.5f);
        actualSet.setDrawCircles(false);
        actualSet.setDrawValues(false);
        actualSet.setHighlightEnabled(false);
        actualSet.setMode(LineDataSet.Mode.LINEAR);

        // The marker dataset has invisible connecting lines and only draws circles
        // on entries where the quantity changed.
        LineData lineData = new LineData(actualSet);
        LineDataSet changedPointSet = new LineDataSet(changedEntries, getString(R.string.actual_stock));
        changedPointSet.setColor(Color.TRANSPARENT);
        changedPointSet.setLineWidth(0f);
        changedPointSet.setCircleColor(Color.parseColor("#2E7D32"));
        changedPointSet.setCircleRadius(3f);
        changedPointSet.setDrawCircleHole(false);
        changedPointSet.setDrawValues(false);
        changedPointSet.setHighlightEnabled(true);
        changedPointSet.setMode(LineDataSet.Mode.LINEAR);
        lineData.addDataSet(changedPointSet);

        // Keep the axis wide enough to include both historical data and any near-term projected trend line.
        long maxAxisMs = latestMs;

        // If a trend exists, add it as a dashed red line and include its endpoints in the axis bounds and max quantity.
        if (trend.hasTrend) {
            List<Entry> trendEntries = new ArrayList<>();
            trendEntries.add(new Entry(daysSince(baseMs, trend.lineStartAt), trend.lineStartQuantity));
            trendEntries.add(new Entry(daysSince(baseMs, trend.lineEndAt), trend.lineEndQuantity));
            maxQuantity = Math.max(maxQuantity, trend.lineStartQuantity);
            maxQuantity = Math.max(maxQuantity, trend.lineEndQuantity);
            maxAxisMs = Math.max(maxAxisMs, trend.lineEndAt);

            // The trend line is styled as dashed red with no circles so it is visually distinct from the actual history.
            LineDataSet trendSet = new LineDataSet(trendEntries, getString(R.string.depletion_trend));
            trendSet.setColor(Color.parseColor("#C62828"));
            trendSet.setLineWidth(2f);
            trendSet.enableDashedLine(12f, 6f, 0f);
            trendSet.setDrawCircles(false);
            trendSet.setDrawValues(false);
            trendSet.setHighlightEnabled(false);
            lineData.addDataSet(trendSet);
        }

        // Show the calculated depletion rate and projected out-of-stock date in summary text above the chart.
        updateProjectionText(trend);
        configureChart(binding.inventoryLineChart, lineData, baseMs, latestMs, maxAxisMs, maxQuantity);
    }

    /** Apply data, axes, labels, and touch behavior to the MPAndroidChart view. */
    private void configureChart(LineChart chart, LineData data, long baseMs, long latestMs, long maxAxisMs, float maxQuantity) {
        chart.setData(data);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);

        // Enable drag and pinch zoom so dense histories can be inspected without leaving the screen.
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);
        chart.setDoubleTapToZoomEnabled(true);
        chart.setDrawGridBackground(false);
        chart.setMarker(new StockHistoryMarkerView(requireContext()));
        chart.setExtraLeftOffset(12f);
        chart.setExtraRightOffset(12f);
        chart.setExtraBottomOffset(22f);

        // Use fractional-day offsets rather than row indexes so panning and zooming stay tied to actual time.
        XAxis xAxis = chart.getXAxis();
        xAxis.removeAllLimitLines();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setLabelCount(5, false);
        xAxis.setAxisMinimum(0f);
        xAxis.setAxisMaximum(Math.max(1f, daysSince(baseMs, maxAxisMs)));
        xAxis.setDrawGridLines(true);
        xAxis.setGridColor(Color.parseColor("#1A000000"));
        xAxis.setGridLineWidth(0.8f);
        xAxis.setTextColor(Color.GRAY);
        xAxis.setLabelRotationAngle(-30f);
        xAxis.setAvoidFirstLastClipping(false);
        DateAxisFormatter dateAxisFormatter = new DateAxisFormatter(baseMs);
        xAxis.setValueFormatter(dateAxisFormatter);

        // Mark the latest real snapshot so projected history to the right is visually separated from today.
        LimitLine todayLine = new LimitLine(daysSince(baseMs, latestMs), getString(R.string.today));
        todayLine.setLineColor(Color.parseColor("#777777"));
        todayLine.setLineWidth(1.5f);
        todayLine.enableDashedLine(8f, 4f, 0f);
        todayLine.setTextColor(Color.GRAY);
        todayLine.setTextSize(10f);
        todayLine.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        xAxis.addLimitLine(todayLine);

        // The y-axis is based on quantity, so it starts at zero and has a maximum based on the
        // highest historical or projected quantity with some padding.
        chart.getAxisLeft().setAxisMinimum(0f);
        chart.getAxisLeft().setAxisMaximum(Math.max(5f, maxQuantity * 1.15f));
        chart.getAxisLeft().setTextColor(Color.GRAY);
        chart.getAxisLeft().setGridColor(Color.parseColor("#22000000"));
        chart.getAxisRight().setEnabled(false);

        // Limit zoom enough to keep labels readable while still allowing sub-day inspection.
        chart.setVisibleXRangeMinimum(0.25f);
        chart.setOnChartGestureListener(new StockHistoryGestureListener(chart, dateAxisFormatter));
        chart.setOnChartValueSelectedListener(new StockHistorySelectionListener(chart, dateAxisFormatter));

        // Reset old viewport state and then update labels from the actual visible time span.
        chart.fitScreen();
        updateXAxisForVisibleRange(chart, dateAxisFormatter);
        chart.post(() -> {
            updateXAxisForVisibleRange(chart, dateAxisFormatter);
            chart.invalidate();
        });
        chart.invalidate();
    }

    /** Reset the chart into its no-data state. */
    private void configureEmptyChart(LineChart chart) {
        chart.clear();
        chart.setNoDataText(getString(R.string.no_stock_history));
        chart.invalidate();
    }

    /** Show a concise projection message above the graph. */
    private void updateProjectionText(TrendCalculator.TrendResult trend) {
        if (!trend.hasTrend) {
            binding.tvDepletionRate.setText(R.string.not_enough_stock_history_rate);
            binding.tvProjection.setText(R.string.not_enough_stock_history);
            return;
        }

        // The depletion rate is the negative slope of the trend line, but it is only useful when the slope is negative.
        float depletionRate = Math.max(0f, -trend.slopePerDay);
        binding.tvDepletionRate.setText(getString(R.string.historical_depletion_rate_format, depletionRate));

        if (trend.projectedOutOfStockAt == null) {
            // Stable or increasing history still has a trend rate, but no zero-stock crossing.
            binding.tvProjection.setText(R.string.no_depletion_projection);
            return;
        }

        // Format the projected out-of-stock date as a string for the summary text above the chart.
        SimpleDateFormat formatter = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault());
        binding.tvProjection.setText(getString(
            R.string.projected_out_of_stock_format,
            formatter.format(new Date(trend.projectedOutOfStockAt))
        ));
    }

    /** Convert an absolute timestamp into fractional days from the first stock history point. */
    private static float daysSince(long baseMs, long timestampMs) {
        return (float) ((double) (timestampMs - baseMs) / TrendCalculator.DAY_MS);
    }

    /** Adjust x-axis label density based on the current zoomed time range. */
    private static void updateXAxisForVisibleRange(LineChart chart, DateAxisFormatter dateAxisFormatter) {
        XAxis xAxis = chart.getXAxis();
        float visibleDays = getVisibleDaySpan(chart);
        dateAxisFormatter.setVisibleDays(visibleDays);

        // Wider visible ranges need coarser date spacing so labels stay readable.
        if (visibleDays <= 2f) {
            xAxis.setGranularity(0.25f);
            xAxis.setLabelCount(5, false);
        } else if (visibleDays <= 14f) {
            xAxis.setGranularity(1f);
            xAxis.setLabelCount(5, false);
        } else if (visibleDays <= 45f) {
            xAxis.setGranularity(7f);
            xAxis.setLabelCount(5, false);
        } else if (visibleDays <= 140f) {
            xAxis.setGranularity(14f);
            xAxis.setLabelCount(5, false);
        } else if (visibleDays <= 370f) {
            xAxis.setGranularity(30f);
            xAxis.setLabelCount(6, false);
        } else {
            xAxis.setGranularity(90f);
            xAxis.setLabelCount(5, false);
        }
    }

    /** Calculate the current x-axis span in days, falling back to the full axis range before layout completes. */
    private static float getVisibleDaySpan(LineChart chart) {
        float visibleDays = chart.getHighestVisibleX() - chart.getLowestVisibleX();
        if (Float.isNaN(visibleDays) || Float.isInfinite(visibleDays) || visibleDays <= 0f) {
            visibleDays = chart.getXAxis().getAxisMaximum() - chart.getXAxis().getAxisMinimum();
        }
        if (Float.isNaN(visibleDays) || Float.isInfinite(visibleDays) || visibleDays <= 0f) {
            visibleDays = chart.getVisibleXRange();
        }
        return Math.max(visibleDays, 0.25f);
    }

    /** Formats fractional day offsets into readable date labels for the x-axis. */
    private static class DateAxisFormatter extends ValueFormatter {
        private final long baseMs;
        private final SimpleDateFormat timeFormatter = new SimpleDateFormat("h:mm a", Locale.getDefault());
        private final SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("MMM d h:mm a", Locale.getDefault());
        private final SimpleDateFormat dayFormatter = new SimpleDateFormat("MMM d", Locale.getDefault());
        private final SimpleDateFormat monthFormatter = new SimpleDateFormat("MMM yyyy", Locale.getDefault());
        private float visibleDays = 30f;

        DateAxisFormatter(long baseMs) {
            this.baseMs = baseMs;
        }

        /** Store the latest visible span so label formatting stays in sync with zoom level. */
        void setVisibleDays(float visibleDays) {
            this.visibleDays = visibleDays;
        }

        @Override
        public String getFormattedValue(float value) {
            // Convert through double arithmetic so six-month offsets do not overflow Math.round(float).
            long ms = baseMs + Math.round((double) value * TrendCalculator.DAY_MS);
            if (visibleDays <= 1f) {
                return timeFormatter.format(new Date(ms));
            } else if (visibleDays <= 7f) {
                return dateTimeFormatter.format(new Date(ms));
            } else if (visibleDays > 370f) {
                return monthFormatter.format(new Date(ms));
            }
            return dayFormatter.format(new Date(ms));
        }
    }

    /** Centers the viewport on a tapped stock-change marker so its tooltip is easier to read. */
    private static class StockHistorySelectionListener implements OnChartValueSelectedListener {
        private final LineChart chart;
        private final DateAxisFormatter dateAxisFormatter;

        StockHistorySelectionListener(LineChart chart, DateAxisFormatter dateAxisFormatter) {
            this.chart = chart;
            this.dateAxisFormatter = dateAxisFormatter;
        }

        @Override
        public void onValueSelected(Entry entry, Highlight highlight) {
            if (entry == null) {
                return;
            }

            // Animate both axes to the selected point so the marker sits near the middle of the graph.
            chart.centerViewToAnimated(entry.getX(), entry.getY(), YAxis.AxisDependency.LEFT, 300);
            chart.postDelayed(() -> {
                updateXAxisForVisibleRange(chart, dateAxisFormatter);
                chart.invalidate();
            }, 300);
        }

        @Override
        public void onNothingSelected() {}
    }

    /** Keeps axis label spacing in step with drag and pinch zoom gestures. */
    private static class StockHistoryGestureListener implements OnChartGestureListener {
        private final LineChart chart;
        private final DateAxisFormatter dateAxisFormatter;

        StockHistoryGestureListener(LineChart chart, DateAxisFormatter dateAxisFormatter) {
            this.chart = chart;
            this.dateAxisFormatter = dateAxisFormatter;
        }

        @Override public void onChartGestureStart(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {}
        @Override public void onChartGestureEnd(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {
            updateXAxisForVisibleRange(chart, dateAxisFormatter);
        }
        @Override public void onChartLongPressed(MotionEvent me) {}
        @Override public void onChartDoubleTapped(MotionEvent me) {
            updateXAxisForVisibleRange(chart, dateAxisFormatter);
        }
        @Override public void onChartSingleTapped(MotionEvent me) {}
        @Override public void onChartFling(MotionEvent me1, MotionEvent me2, float velocityX, float velocityY) {}
        @Override public void onChartScale(MotionEvent me, float scaleX, float scaleY) {
            updateXAxisForVisibleRange(chart, dateAxisFormatter);
        }
        @Override public void onChartTranslate(MotionEvent me, float dX, float dY) {
            updateXAxisForVisibleRange(chart, dateAxisFormatter);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
