/**
 * File: SeedUtil.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Seeds sample inventory data and synthetic stock history for demo installs.
 */
package com.sm.hopstock.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.sm.hopstock.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Utility for creating sample inventory and history data on first launch. */
public class SeedUtil {
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final String PREFS_NAME = "com.sm.hopstock.SEED_PREFS";
    private static final String KEY_SEEDED = "inventory_seeded";
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;
    private static final long HOUR_MS = 60L * 60L * 1000L;
    private static final long MINUTE_MS = 60L * 1000L;
    private static final int HISTORY_DAYS = 180;
    private static final int HISTORY_SAMPLE_INTERVAL_DAYS = 3;
    private static final int RESTOCK_END_PADDING_DAYS = 8;

    /** Seed the inventory database with initial data (only runs once per app installation). */
    public static void seedInventory(final Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        executor.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(context);
            InventoryDao inventoryDao = db.inventoryDao();
            StockHistoryDao stockHistoryDao = db.stockHistoryDao();

            // If the seeded flag is set and there are items in the database, assume seeding has already run and just backfill history if needed.
            if (prefs.getBoolean(KEY_SEEDED, false) && inventoryDao.getItemCountSync() > 0) {
                seedStockHistoryIfNeeded(inventoryDao, stockHistoryDao);
                return;
            }

            // First-run seeding owns the sample inventory set, so it resets both current items and history.
            inventoryDao.deleteAll();
            stockHistoryDao.deleteAll();

            // Insert each item and immediately generate its six-month history so the graph has real DB data.
            long now = new Date().getTime();
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Commuter Hoodie", "Soft hoodie with reflective stripe for evening commutes.", "1000001", "Apparel A1", 250, R.drawable.commuter_hoodie, null, now), now, 1);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Sunset Tee", "Lightweight tee in gradient sunset colors, breathable for long shifts.", "1000002", "Apparel A1", 402, R.drawable.sunset_tee, null, now), now, 2);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Trail Cap", "Durable cap with moisture-wicking sweatband.", "1000003", "Headwear B2", 158, R.drawable.trail_cap, null, now), now, 3);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Cozy Socks (3-pack)", "Plush three-pack socks with reinforced heels for comfort.", "1000004", "Accessories C3", 17, R.drawable.cozy_socks, null, now), now, 4);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("RainShield Windbreaker", "Compact windbreaker that packs into its pocket - water resistant.", "1000005", "Outerwear D4", 98, R.drawable.rainshield_windbreaker, null, now), now, 5);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Infinity Scarf", "Versatile scarf that can be styled multiple ways (limited edition).", "1000006", "Accessories C3", 0, R.drawable.infinity_scarf, null, now), now, 6);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Dream Pajama Set", "Ultra-soft pajama set with breathable fabric for cozy nights.", "1000007", "Apparel A2", 112, R.drawable.dream_pajama_set, null, now), now, 7);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Pixel Beanie", "Retro knit beanie with pixel-pattern cuff.", "1000008", "Headwear B2", 303, R.drawable.pixel_beanie, null, now), now, 8);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Worksmith Apron", "Heavy-duty apron with reinforced pockets for tools and pens.", "1000009", "Workwear D5", 55, R.drawable.worksmith_apron, null, now), now, 9);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Retro Trainer Jacket", "Vintage-inspired trainer jacket with contrasting stripes.", "1000010", "Outerwear D4", 731, R.drawable.retro_trainer_jacket, null, now), now, 10);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Flex Pants", "Stretchy, durable pants with articulated knees for movement.", "1000011", "Workwear D5", 20, R.drawable.flex_pants, null, now), now, 11);
            insertSeedItem(inventoryDao, stockHistoryDao, new InventoryItem("Storm Guard Raincoat", "Long raincoat with taped seams and storm hood.", "1000012", "Outerwear E6", 104, R.drawable.storm_guard_raincoat, null, now), now, 12);

            prefs.edit()
                .putBoolean(KEY_SEEDED, true)
                .apply();
        });
    }

    /** Backfill synthetic stock history for existing installs that were seeded before history existed. */
    private static void seedStockHistoryIfNeeded(InventoryDao inventoryDao, StockHistoryDao stockHistoryDao) {
        long now = new Date().getTime();
        List<InventoryItem> items = inventoryDao.getAllSync();
        if (items.isEmpty()) {
            // There is no history to backfill when the inventory table is empty; first-run seeding handles that case.
            return;
        }

        int patternIndex = 1;
        for (InventoryItem item : items) {
            // Replace only seed-item baseline history created by migration, and backfill user items only if history is absent.
            int historyCount = stockHistoryDao.getHistoryCountForItem(item.itemId);
            if (shouldGenerateSyntheticHistory(item, historyCount)) {
                stockHistoryDao.deleteHistoryForItem(item.itemId);
                seedSyntheticHistory(stockHistoryDao, item.itemId, item.quantity, now, patternIndex);
            }
            patternIndex++;
        }
    }

    /**
     * Decide whether this item should receive synthetic history during the one-time backfill.
     * Seed items with only the migration-created baseline point get demo history; user items are left alone unless they have no history at all.
     */
    private static boolean shouldGenerateSyntheticHistory(InventoryItem item, int historyCount) {
        if (!isSeedSku(item.sku)) {
            return historyCount == 0;
        }

        return historyCount <= 1;
    }

    /** Identify built-in sample inventory SKUs that can receive generated demo history. */
    private static boolean isSeedSku(String sku) {
        int value = seedPatternForSku(sku);
        return value >= 1 && value <= 12;
    }

    /** Convert built-in sample SKU values into stable generator patterns. */
    private static int seedPatternForSku(String sku) {
        try {
            return Integer.parseInt(sku) - 1000000;
        } catch (NumberFormatException ignored) {
            return -1;
        }
    }

    /** Insert one sample inventory item and seed its matching stock history. */
    private static void insertSeedItem(InventoryDao inventoryDao, StockHistoryDao stockHistoryDao, InventoryItem item, long now, int patternIndex) {
        long itemId = inventoryDao.insert(item);
        seedSyntheticHistory(stockHistoryDao, itemId, item.quantity, now, patternIndex);
    }

    /**
     * Generate deterministic stock history with normal depletion and occasional restocks.
     * The generated curve is offset after simulation so today's final point is the item's current quantity.
     */
    private static void seedSyntheticHistory(StockHistoryDao stockHistoryDao, long itemId, int currentQuantity, long now, int patternIndex) {
        if (HISTORY_SAMPLE_INTERVAL_DAYS <= 0 || HISTORY_SAMPLE_INTERVAL_DAYS > HISTORY_DAYS) {
            throw new IllegalStateException("History sample interval must be between 1 and HISTORY_DAYS.");
        }

        Random random = new Random(14000L + patternIndex * 997L);
        int[] dailyQuantities = new int[HISTORY_DAYS + 1];
        int[] restockAmountsByDay = buildRestockSchedule(random, patternIndex);

        // The loop walks backward from today, so the first "next day" quantity is the current real stock level.
        int nextDayQuantity = currentQuantity;
        dailyQuantities[HISTORY_DAYS] = currentQuantity;

        for (int day = HISTORY_DAYS - 1; day >= 0; day--) {
            // Work backward from today's real quantity. Normal sales mean yesterday's stock was higher
            // than today's; restock days mean yesterday's stock was lower before the delivery arrived.
            int depletion = demandForDay(random, patternIndex, day);
            int restock = restockAmountsByDay[day + 1];
            int previousQuantity = nextDayQuantity + depletion - restock;
            if (random.nextFloat() < 0.05f) {
                previousQuantity += random.nextInt(7) - 3;
            }

            // Clamp to zero so the graph does not show negative stock levels,
            // which would be unrealistic and potentially confusing.
            dailyQuantities[day] = Math.max(0, previousQuantity);
            nextDayQuantity = dailyQuantities[day];
        }

        // Insert sampled history points at intervals so the graph has enough data
        // to show a trend without overcrowding the database.
        List<StockHistoryEntry> entries = new ArrayList<>();
        for (int day = 0; day < HISTORY_DAYS; day += HISTORY_SAMPLE_INTERVAL_DAYS) {
            long recordedAt = now - (HISTORY_DAYS - day) * DAY_MS + sampleTimeOffset(random, patternIndex, day);
            entries.add(new StockHistoryEntry(itemId, dailyQuantities[day], recordedAt));
        }

        // Insert the final current-quantity point at the exact current time so the graph has a real anchor for today.
        entries.add(new StockHistoryEntry(itemId, currentQuantity, now));
        for (StockHistoryEntry entry : entries) {
            long insertedId = stockHistoryDao.insert(entry);
            if (insertedId == -1L) {
                throw new IllegalStateException("Failed to insert synthetic stock history entry.");
            }
        }
    }

    /**
     * Pick varied times within each sample day so marker timestamps do not all land at the same time of day.
     * The final current-quantity point is still inserted separately at the exact current time.
     */
    private static long sampleTimeOffset(Random random, int patternIndex, int day) {
        int shiftWindow = 6 + patternIndex % 5;
        long baseBusinessTime = (7L + (day + patternIndex) % shiftWindow) * HOUR_MS;
        long minuteJitter = random.nextInt(180) * MINUTE_MS;

        // Add a random extra restock delay to some points so the graph has more varied step shapes.
        if (random.nextFloat() < 0.18f) {
            baseBusinessTime += (4L + random.nextInt(5)) * HOUR_MS;
        }

        return Math.min(baseBusinessTime + minuteJitter, DAY_MS - MINUTE_MS);
    }

    /** Build irregular restock events so sample items do not all follow the same visible rhythm. */
    private static int[] buildRestockSchedule(Random random, int patternIndex) {
        int[] restockAmountsByDay = new int[HISTORY_DAYS + 1];
        int restockCount = 2 + random.nextInt(4);
        int minGap = 21 + random.nextInt(14);
        int day = 18 + random.nextInt(18);

        // The loop walks forward from the past so restock events are applied to the next day after they are generated,
        for (int i = 0; i < restockCount && day < HISTORY_DAYS - RESTOCK_END_PADDING_DAYS; i++) {
            int amount = 24 + random.nextInt(65) + patternIndex * (1 + random.nextInt(3));
            restockAmountsByDay[day] += amount;
            // Add a few extra random restock events to make the graph more interesting and less predictable.
            if (random.nextFloat() < 0.25f) {
                restockAmountsByDay[day + 1 + random.nextInt(3)] += 8 + random.nextInt(24);
            }
            day += minGap + random.nextInt(31);
        }

        return restockAmountsByDay;
    }

    /** Generate item-specific daily usage with quiet days, busy bursts, and small random variance. */
    private static int demandForDay(Random random, int patternIndex, int day) {
        float seasonalWave = (float) Math.sin((day + patternIndex * 13) / (14.0 + patternIndex % 5));
        float baseDemand = 1.2f + (patternIndex % 4) * 0.45f + Math.max(0f, seasonalWave) * 2.3f;

        if (day % (9 + patternIndex % 6) == 0 || random.nextFloat() < 0.08f) {
            baseDemand += 2.0f + random.nextFloat() * 4.0f;
        }

        if (random.nextFloat() < 0.12f) {
            return 0;
        }

        // Clamp after rounding so future demand tweaks cannot create negative simulated sales.
        return Math.max(0, Math.round(baseDemand + random.nextFloat() * 2.2f));
    }
}
