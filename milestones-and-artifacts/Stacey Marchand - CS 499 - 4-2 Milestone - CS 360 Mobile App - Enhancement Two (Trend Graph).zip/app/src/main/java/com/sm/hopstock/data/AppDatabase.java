/**
 * File: AppDatabase.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Defines the Room database, DAOs, and schema migration path for persistent app data.
 */
package com.sm.hopstock.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

/** Room database definition for inventory, user profile, and stock history storage. */
@Database(entities = {InventoryItem.class, UserAccount.class, StockHistoryEntry.class}, version = 2, exportSchema = true)
public abstract class AppDatabase extends RoomDatabase {
    private static final String DB_NAME = "app.db";
    private static volatile AppDatabase instance;

    public abstract InventoryDao inventoryDao();
    public abstract UserDao userDao();
    public abstract StockHistoryDao stockHistoryDao();

    /**
     * Migration that adds stock history without dropping existing inventory or user data.
     * Existing inventory rows get one current snapshot so upgraded installs have a valid baseline.
     */
    private static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Create the history table with a cascading item relationship so deleted items remove their history too.
            database.execSQL("CREATE TABLE IF NOT EXISTS `stock_history` (`historyId` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `itemId` INTEGER NOT NULL, `quantity` INTEGER NOT NULL, `recordedAt` INTEGER NOT NULL, FOREIGN KEY(`itemId`) REFERENCES `inventory_items`(`itemId`) ON UPDATE NO ACTION ON DELETE CASCADE)");
            database.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_history_itemId` ON `stock_history` (`itemId`)");

            // Backfill each existing item with its current quantity to establish a first data point.
            database.execSQL("INSERT INTO `stock_history` (`itemId`, `quantity`, `recordedAt`) SELECT `itemId`, `quantity`, CASE WHEN `updatedAt` > 0 THEN `updatedAt` ELSE strftime('%s','now') * 1000 END FROM `inventory_items`");
        }
    };

    /** Get the singleton instance of AppDatabase. */
    public static AppDatabase getInstance(Context context) {
        if (instance == null) {
            synchronized (AppDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, DB_NAME)
                        .addMigrations(MIGRATION_1_2)
                        .build();
                }
            }
        }
        return instance;
    }
}
