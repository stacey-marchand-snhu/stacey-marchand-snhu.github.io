/**
 * File: InventoryItem.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Represents one inventory item stored in the Room database.
 */
package com.sm.hopstock.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory_items")
public class InventoryItem {
    @PrimaryKey(autoGenerate = true)
    public long itemId;

    public String name;
    public String description;
    public String sku;
    public String location;
    public int quantity;

    // Resolved resource id (0 == none)
    public int imageResId;

    // User-selected image URI (null == none)
    public String imageUri;
    public long updatedAt;

    /** Default constructor. */
    public InventoryItem(String name, String description, String sku, String location, int quantity, int imageResId, String imageUri, long updatedAt) {
        this.name = name;
        this.description = description;
        this.sku = sku;
        this.location = location;
        this.quantity = quantity;
        this.imageResId = imageResId;
        this.imageUri = imageUri;
        this.updatedAt = updatedAt;
    }
}
