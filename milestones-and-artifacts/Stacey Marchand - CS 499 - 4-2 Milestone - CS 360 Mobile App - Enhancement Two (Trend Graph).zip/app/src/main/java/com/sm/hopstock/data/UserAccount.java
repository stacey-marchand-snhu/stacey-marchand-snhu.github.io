/**
 * File: UserAccount.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Represents a user account stored in the Room database.
 */
package com.sm.hopstock.data;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class UserAccount {
    @PrimaryKey(autoGenerate = true)
    public long userId;

    public String username;
    public String passwordHash;
    public String salt;
    public String firstName;
    public String lastName;
    public String phone;
    public long createdAt;
    public boolean smsEnabled = true; // Default to true

    /** Default constructor. Required by Room. */
    public UserAccount() {}

    /** Full constructor. */
    @Ignore
    public UserAccount(String username, String passwordHash, String salt, String firstName, String lastName, String phone, long createdAt) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.salt = salt;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.createdAt = createdAt;
        this.smsEnabled = true; // Default to true
    }
}
