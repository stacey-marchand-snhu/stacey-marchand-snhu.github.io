/**
 * File: StockHistoryMarkerView.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Displays a small chart tooltip for selected stock history change points.
 */
package com.sm.hopstock.ui;

import android.content.Context;
import android.widget.TextView;

import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;
import com.sm.hopstock.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** MarkerView that shows date, quantity, and adjustment details for a stock history point. */
public class StockHistoryMarkerView extends MarkerView {
    private final TextView tvDate;
    private final TextView tvTime;
    private final TextView tvQuantity;
    private final TextView tvAdjustment;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault());
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a", Locale.getDefault());

    public StockHistoryMarkerView(Context context) {
        super(context, R.layout.marker_stock_history);
        tvDate = findViewById(R.id.tvMarkerDate);
        tvTime = findViewById(R.id.tvMarkerTime);
        tvQuantity = findViewById(R.id.tvMarkerQuantity);
        tvAdjustment = findViewById(R.id.tvMarkerAdjustment);
    }

    /** Refresh tooltip text when the user selects a chart entry. */
    @Override
    public void refreshContent(Entry entry, Highlight highlight) {
        Object data = entry.getData();
        if (data instanceof MarkerInfo) {
            MarkerInfo info = (MarkerInfo) data;
            Date recordedAt = new Date(info.recordedAt);
            tvDate.setText(dateFormat.format(recordedAt));
            tvTime.setText(timeFormat.format(recordedAt));
            tvQuantity.setText(getContext().getString(R.string.marker_stock_level_format, info.quantity));
            tvAdjustment.setText(getContext().getString(R.string.marker_adjustment_format, formatAdjustment(info.adjustment)));
        }
        super.refreshContent(entry, highlight);
    }

    /** Position the marker centered above the selected point. */
    @Override
    public MPPointF getOffset() {
        return new MPPointF(-(getWidth() / 2f), -getHeight() - 12f);
    }

    /** Format the stock change with an explicit sign for gains and losses. */
    private String formatAdjustment(int adjustment) {
        if (adjustment > 0) {
            return "+" + adjustment;
        }
        return String.valueOf(adjustment);
    }

    /** Small data object attached to chart entries that should display a marker. */
    public static class MarkerInfo {
        public final long recordedAt;
        public final int quantity;
        public final int adjustment;

        public MarkerInfo(long recordedAt, int quantity, int adjustment) {
            this.recordedAt = recordedAt;
            this.quantity = quantity;
            this.adjustment = adjustment;
        }
    }
}
