/**
 * File: AppPrefs.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Centralizes shared preference names and keys used across the app.
 */
package com.sm.hopstock.data;

import android.content.Context;
import android.content.SharedPreferences;

/** Global preference constants and helpers. */
public final class AppPrefs {
    public static final String PREFS_NAME = "hopstock_prefs";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_SMS_ENABLED = "sms_enabled";
    public static final String KEY_IS_NEW_ACCOUNT = "is_new_account";
    public static final String KEY_OPENED_SETTINGS_FOR_SMS = "opened_settings_for_sms";
    public static final String KEY_FAILED_LOGIN_ATTEMPTS = "failed_login_attempts";
    public static final String KEY_LOGIN_LOCKED_UNTIL = "login_locked_until";

    private AppPrefs() {}

    /** Get the app-wide shared preferences file. */
    public static SharedPreferences get(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
}
