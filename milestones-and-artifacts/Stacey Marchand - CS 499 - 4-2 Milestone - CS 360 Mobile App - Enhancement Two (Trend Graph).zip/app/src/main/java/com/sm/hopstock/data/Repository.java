/**
 * File: Repository.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Coordinates data access for inventory, users, and stock history behind an asynchronous API.
 */
package com.sm.hopstock.data;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {
    private static volatile Repository instance;
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    final AppDatabase db;
    private final InventoryDao inventoryDao;
    // The repository owns stock history writes so UI screens do not need to remember to record snapshots.
    private final StockHistoryDao stockHistoryDao;

    /** Constructor. */
    private Repository(Context context) {
        db = AppDatabase.getInstance(context.getApplicationContext());
        inventoryDao = db.inventoryDao();
        stockHistoryDao = db.stockHistoryDao();
    }

    /** Get the singleton Repository instance for the app process. */
    public static Repository getInstance(Context context) {
        if (instance == null) {
            synchronized (Repository.class) {
                if (instance == null) {
                    instance = new Repository(context);
                }
            }
        }
        return instance;
    }

    /** Get UserDao for accessing user data. */
    public UserDao getUserDao() {
        return db.userDao();
    }

    /** Get all inventory items as LiveData. */
    public LiveData<List<InventoryItem>> getAll() {
        return inventoryDao.getAll();
    }

    public LiveData<List<InventoryItem>> search(String query) {
        String q = "%" + query + "%";
        return inventoryDao.search(q);
    }

    /** Get all out-of-stock inventory items as LiveData. */
    public LiveData<List<InventoryItem>> getOutOfStock() {
        return inventoryDao.getOutOfStock();
    }

    /** Get stock history for an item as LiveData. */
    public LiveData<List<StockHistoryEntry>> getStockHistoryForItem(long itemId) {
        return stockHistoryDao.getHistoryForItem(itemId);
    }

    /** Get an inventory item by ID asynchronously. */
    public void getById(final long id, final Callback<InventoryItem> callback) {
        executor.execute(() -> {
            InventoryItem item = inventoryDao.getById(id);
            if (callback != null) callback.onComplete(item);
        });
    }

    /** Insert a new inventory item asynchronously. */
    public void insert(final InventoryItem item, final Callback<Long> callback) {
        executor.execute(() -> {
            long id = inventoryDao.insert(item);
            // Every new item starts with a baseline stock history entry.
            recordStockSnapshotSync(id, item.quantity, snapshotTime(item.updatedAt));
            if (callback != null) callback.onComplete(id);
        });
    }

    /**
     * Update an existing inventory item asynchronously.
     * Returns the previous item state via callback so the caller can detect transitions and handle business logic.
     */
    public void update(final InventoryItem item, final Callback<InventoryItem> callback) {
        executor.execute(() -> {
            // Fetch previous state before updating.
            InventoryItem before = inventoryDao.getById(item.itemId);
            inventoryDao.update(item);
            // Saving item details also records the current quantity for trend analysis.
            recordStockSnapshotSync(item.itemId, item.quantity, snapshotTime(item.updatedAt));
            if (callback != null) callback.onComplete(before);
        });
    }

    /** Insert a stock snapshot on the repository executor or from another background caller. */
    private void recordStockSnapshotSync(long itemId, int quantity, long recordedAt) {
        stockHistoryDao.insert(new StockHistoryEntry(itemId, quantity, recordedAt));
    }

    /** Use the item update timestamp when present, otherwise fall back to the current time. */
    private long snapshotTime(long updatedAt) {
        return updatedAt > 0 ? updatedAt : System.currentTimeMillis();
    }

    /** Delete an inventory item asynchronously. */
    public void delete(final InventoryItem item, final Callback<Void> callback) {
        executor.execute(() -> {
            inventoryDao.delete(item);
            if (callback != null) callback.onComplete(null);
        });
    }

    /**
     * Check for duplicate SKU asynchronously, excluding the given item ID.
     * The callback returns true if a duplicate exists, false otherwise.
     */
    public void checkDuplicateSku(final String sku, final long excludeItemId, final Callback<Boolean> callback) {
        executor.execute(() -> {
            InventoryItem existing = inventoryDao.findBySku(sku, excludeItemId);
            if (callback != null) callback.onComplete(existing != null);
        });
    }

    /**
     * Check for duplicate name asynchronously, excluding the given item ID.
     * The callback returns true if a duplicate exists, false otherwise.
     */
    public void checkDuplicateName(final String name, final long excludeItemId, final Callback<Boolean> callback) {
        executor.execute(() -> {
            InventoryItem existing = inventoryDao.findByName(name, excludeItemId);
            if (callback != null) callback.onComplete(existing != null);
        });
    }

    /** Generic callback interface for asynchronous operations. */
    public interface Callback<T> {
        void onComplete(T result);
    }
}
