/**
 * File: SmsUtils.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Handles SMS permission prompts, settings routing, and out-of-stock alert sending.
 */
package com.sm.hopstock.notifications;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import android.util.Log;
import android.annotation.SuppressLint;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.sm.hopstock.R;
import com.sm.hopstock.auth.AuthManager;
import com.sm.hopstock.data.AppPrefs;
import com.sm.hopstock.data.InventoryItem;
import com.sm.hopstock.data.Repository;
import com.sm.hopstock.data.UserAccount;
import com.sm.hopstock.ui.UiUtils;

public class SmsUtils {
    private static final String TAG = "SmsUtils";

    public static final int STATUS_NO_RECIPIENT = 0;
    public static final int STATUS_PERMISSION_DENIED = 1;
    public static final int STATUS_SENT = 2;
    public static final int STATUS_FAILED = 3;

    /** Check if the SEND_SMS permission is granted. */
    public static boolean isSmsPermissionGranted(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    /** Returns whether SMS is enabled for the current user. Defaults to true if not set. */
    public static boolean isSmsEnabled(Context context) {
        SharedPreferences prefs = AppPrefs.get(context);
        return prefs.getBoolean(AppPrefs.KEY_SMS_ENABLED, true);
    }

    /** Check if we recently opened settings for SMS permission. */
    public static boolean didOpenSettingsForSms(Context context) {
        SharedPreferences prefs = AppPrefs.get(context);
        return prefs.getBoolean(AppPrefs.KEY_OPENED_SETTINGS_FOR_SMS, false);
    }

    /** Clear the flag that tracks if we opened settings for SMS permission. */
    public static void clearOpenedSettingsForSmsFlag(Context context) {
        SharedPreferences prefs = AppPrefs.get(context);
        prefs.edit().remove(AppPrefs.KEY_OPENED_SETTINGS_FOR_SMS).apply();
    }

    /**
     * Check if we returned from settings and show appropriate snackbar.
     * Call this from onResume() in fragments that open SMS settings.
     * Returns true if the snackbar was shown (meaning we returned from settings).
     *
     * @param activity The activity to show the snackbar in
     */
    public static void handleReturnFromSettings(Activity activity) {
        Context context = activity.getApplicationContext();
        if (didOpenSettingsForSms(context)) {
            clearOpenedSettingsForSmsFlag(context);

            // Check current permission state and show appropriate snackbar
            if (isSmsPermissionGranted(context)) {
                UiUtils.simpleSnackbar(activity, R.string.sms_permission_enabled);
            } else {
                UiUtils.simpleSnackbar(
                    activity,
                    R.string.sms_permission_disabled,
                    R.string.settings,
                    v -> {
                        // Set flag again before opening settings
                        SharedPreferences prefs = AppPrefs.get(context);
                        prefs.edit().putBoolean(AppPrefs.KEY_OPENED_SETTINGS_FOR_SMS, true).apply();
                        openAppPermissions(activity);
                    }
                );
            }
        }
    }

    /** Attempt to send SMS. Returns a status code indicating outcome so callers can react in the UI. */
    @SuppressLint("ObsoleteSdkInt")
    @SuppressWarnings("deprecation")
    public static int sendSmsIfPermitted(Context context, String phoneNumber, String message) {
        // Validate recipient and permission.
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            Log.w(TAG, "No SMS recipient configured; skipping SMS alert");
            return STATUS_NO_RECIPIENT;
        }
        if (!isSmsPermissionGranted(context)) {
            Log.w(TAG, "SEND_SMS permission not granted; skipping SMS alert to " + phoneNumber);
            return STATUS_PERMISSION_DENIED;
        }

        try {
            // Use subscription-aware SmsManager on newer Android versions to avoid deprecated getDefault().
            SmsManager sms;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Get user's default SMS subscription id and obtain the SmsManager for it
                int subId = SubscriptionManager.getDefaultSmsSubscriptionId();
                sms = SmsManager.getSmsManagerForSubscriptionId(subId);
            } else {
                // Fallback on older APIs
                sms = SmsManager.getDefault();
            }
            sms.sendTextMessage(phoneNumber, null, message, null, null);
            Log.i(TAG, "Sent SMS to " + phoneNumber + ": " + message);
            return STATUS_SENT;
        } catch (Exception e) {
            Log.w(TAG, "Failed to send SMS to " + phoneNumber + ": " + e.getMessage());
            return STATUS_FAILED;
        }
    }

    /**
     * Send out-of-stock SMS alert to the current user's phone number.
     * Returns the SMS sending status code.
     * Note: This should be called from a background thread as it accesses the database.
     *
     * @param context The context to use for accessing resources and database
     * @param repo The repository instance to use for database access
     * @param item The inventory item that is out of stock
     * @return SMS status code (STATUS_SENT, STATUS_PERMISSION_DENIED, STATUS_NO_RECIPIENT, or STATUS_FAILED)
     */
    public static int sendOutOfStockAlert(Context context, Repository repo, InventoryItem item) {
        try {
            // Get current user's phone number.
            AuthManager auth = AuthManager.getInstance(context);
            long userId = auth.getCurrentUserId();
            if (userId <= 0) {
                Log.w(TAG, "No user logged in; cannot send SMS alert");
                return STATUS_NO_RECIPIENT;
            }

            // Fetch user from database to get phone number (synchronous since we're on background thread).
            UserAccount user = repo.getUserDao().getById(userId);
            if (user != null && user.phone != null && !user.phone.trim().isEmpty()) {
                String message = context.getString(
                        R.string.sms_alert_template,
                        user.firstName,
                        user.lastName,
                        item.name,
                        item.sku
                );
                return sendSmsIfPermitted(context, user.phone.trim(), message);
            } else {
                Log.w(TAG, "No phone number configured for user; cannot send SMS alert");
                return STATUS_NO_RECIPIENT;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error sending out-of-stock SMS alert", e);
            return STATUS_FAILED;
        }
    }

    /** Open the app's permissions settings page. */
    @SuppressLint("ObsoleteSdkInt")
    public static void openAppPermissions(Activity activity) {
        if (activity == null) return;

        // Use the appropriate intent based on Android version.
        Intent intent;
        if (Build.VERSION.SDK_INT >= 30) {
            String action = "android.settings.MANAGE_APP_PERMISSIONS";
            intent = new Intent(action, Uri.parse("package:" + activity.getPackageName()));
        } else {
            intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
        }

        // Start activity on main thread to be safe and guard against no-activity handlers.
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                activity.startActivity(intent);
            } catch (Exception e) {
                Log.e(TAG, "Failed to open app permissions: " + e.getMessage(), e);
                // Fallback: try opening the app details settings page.
                try {
                    Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    fallback.setData(Uri.parse("package:" + activity.getPackageName()));
                    activity.startActivity(fallback);
                } catch (Exception ex) {
                    // Nothing we can do except inform the user.
                    Log.e(TAG, "Failed to open app details settings: " + ex.getMessage(), ex);
                    Toast.makeText(activity, activity.getString(R.string.settings_unavailable), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Create an ActivityResultLauncher for requesting SMS permission.
     * This handles the permission result by showing appropriate snackbars.
     * Must be called during initialization (onCreate/onViewCreated), not during user interaction.
     *
     * @param fragment The fragment that will use this launcher
     * @return A configured ActivityResultLauncher for SEND_SMS permission
     */
    public static ActivityResultLauncher<String> createSmsPermissionLauncher(Fragment fragment) {
        return fragment.registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGranted -> {
                if (isGranted) {
                    // Permission granted - show success snackbar
                    UiUtils.simpleSnackbar(fragment.requireActivity(), R.string.sms_permission_enabled);
                } else {
                    // Permission denied - show snackbar with Settings action
                    UiUtils.simpleSnackbar(
                        fragment.requireActivity(),
                        R.string.sms_permission_disabled,
                        R.string.settings,
                        v -> openAppPermissions(fragment.requireActivity())
                    );
                }
            }
        );
    }

    /**
     * Shows a dialog requesting SMS permissions with appropriate actions.
     * The launcher parameter must be created during initialization using createSmsPermissionLauncher.
     *
     * @param fragment The fragment showing the dialog
     * @param launcher The permission launcher to use for requesting permission
     */
    public static void showSmsPermissionRequestDialog(Fragment fragment, ActivityResultLauncher<String> launcher) {
        // Create and configure the dialog.
        AlertDialog dialog = new AlertDialog.Builder(fragment.requireActivity()).create();
        View dialogView = fragment.requireActivity().getLayoutInflater().inflate(R.layout.dialog_sms_permission, null);
        dialog.setView(dialogView);

        // Set up button click handlers
        dialogView.findViewById(R.id.btnNotNow).setOnClickListener(v -> dialog.dismiss());
        dialogView.findViewById(R.id.btnSettings).setOnClickListener(v -> {
            dialog.dismiss();

            // Check if we should show permission rationale.
            // If shouldShowRequestPermissionRationale returns true, the user has denied before but
            // hasn't selected "Don't ask again", so we can request permission again.
            // If it returns false and permission is not granted, either:
            // 1. This is the first time asking (permission will show), or
            // 2. User selected "Don't ask again" (permission won't show, need to go to settings)
            if (!isSmsPermissionGranted(fragment.requireContext()) &&
                !fragment.shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
                // First time or permanently denied - on permanently denied, permission dialog won't show
                // so we should guide user to settings instead
                // Set flag so we can show snackbar when returning from settings
                SharedPreferences prefs = AppPrefs.get(fragment.requireContext());
                prefs.edit().putBoolean(AppPrefs.KEY_OPENED_SETTINGS_FOR_SMS, true).apply();
                openAppPermissions(fragment.requireActivity());
            } else {
                // User has denied before but can still be asked, or permission is already granted
                launcher.launch(Manifest.permission.SEND_SMS);
            }
        });

        dialog.show();
    }
}
