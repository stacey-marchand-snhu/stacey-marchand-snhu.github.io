/**
 * File: StockHistoryDao.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Provides Room accessors for recording and observing stock history entries.
 */
package com.sm.hopstock.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/** DAO for inserting and observing item quantity snapshots over time. */
@Dao
public interface StockHistoryDao {
    /** Insert one stock history snapshot. */
    @Insert
    long insert(StockHistoryEntry entry);

    /** Get all snapshots for an item in chronological order. */
    @Query("SELECT * FROM stock_history WHERE itemId = :itemId ORDER BY recordedAt ASC")
    LiveData<List<StockHistoryEntry>> getHistoryForItem(long itemId);

    /** Count snapshots for an item synchronously */
    @Query("SELECT COUNT(*) FROM stock_history WHERE itemId = :itemId")
    int getHistoryCountForItem(long itemId);

    /** Delete all snapshots for an item when the item is deleted. */
    @Query("DELETE FROM stock_history WHERE itemId = :itemId")
    void deleteHistoryForItem(long itemId);

    /** Delete all snapshots for all items when the database is cleared. */
    @Query("DELETE FROM stock_history")
    void deleteAll();
}
