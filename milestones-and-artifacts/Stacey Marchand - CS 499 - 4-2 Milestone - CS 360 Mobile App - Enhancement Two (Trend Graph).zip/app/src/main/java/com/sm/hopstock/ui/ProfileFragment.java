/**
 * File: ProfileFragment.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Displays and updates the signed-in user profile and SMS preferences.
 */
package com.sm.hopstock.ui;

import android.os.Bundle;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.sm.hopstock.R;
import com.sm.hopstock.auth.AuthManager;
import com.sm.hopstock.auth.AuthUtils;
import com.sm.hopstock.data.UserAccount;
import com.sm.hopstock.databinding.FragmentProfileBinding;
import com.sm.hopstock.notifications.SmsUtils;

/** Fragment for viewing and editing user profile information. */
public class ProfileFragment extends Fragment {
    private AuthManager authManager;
    private UserAccount currentUser;

    private FragmentProfileBinding binding;

    // Local shortcuts for frequently used views.
    private EditText etFirstName, etLastName, etPhone, etPassword, etConfirmPassword;
    private TextView tvProfileError;
    private Button btnSaveProfile;
    private MaterialSwitch switchSmsEnabled;
    private ActivityResultLauncher<String> smsPermissionLauncher;

    // Must be a field to keep strong reference; prevents garbage collection while fragment is active.
    @SuppressWarnings("FieldCanBeLocal")
    private OnBackPressedCallback backPressedCallback;

    // Original values loaded from DB to detect changes.
    private String originalFirstName = "";
    private String originalLastName = "";
    private String originalPhone = "";
    private boolean originalSmsEnabled = true;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        // Initialize SMS permission launcher.
        smsPermissionLauncher = SmsUtils.createSmsPermissionLauncher(this);

        // Handle back press using AndroidX OnBackPressedDispatcher.
        backPressedCallback = new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { handleBackPress(); }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), backPressedCallback);

        // Assign local shortcuts from the binding.
        etFirstName = binding.etFirstName;
        etLastName = binding.etLastName;
        etPhone = binding.etPhone;
        etPassword = binding.etPassword;
        etConfirmPassword = binding.etConfirmPassword;
        tvProfileError = binding.tvProfileError;
        btnSaveProfile = binding.btnSaveProfile;
        switchSmsEnabled = binding.switchSmsEnabled;

        tvProfileError.setVisibility(View.GONE);

        // Set up SMS toggle listener.
        switchSmsEnabled.setChecked(SmsUtils.isSmsEnabled(requireContext()));
        switchSmsEnabled.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // User enabled SMS; check permission, and show request dialog if not granted.
            if (isChecked && !SmsUtils.isSmsPermissionGranted(requireContext())) {
                SmsUtils.showSmsPermissionRequestDialog(this, smsPermissionLauncher);
            }
            updateFormState();
        });

        // Text watcher for automatically enabling/disabling Save Changes button.
        TextWatcher watcher = UiUtils.simpleTextWatcher(s -> updateFormState());
        etFirstName.addTextChangedListener(watcher);
        etLastName.addTextChangedListener(watcher);
        etPhone.addTextChangedListener(watcher);
        etPassword.addTextChangedListener(watcher);
        etConfirmPassword.addTextChangedListener(watcher);

        // Disable save until data is loaded.
        btnSaveProfile.setEnabled(false);

        // Show loading overlay while we fetch the user from DB
        binding.profileProgressOverlay.setVisibility(View.VISIBLE);
        binding.profileProgressSpinner.setVisibility(View.VISIBLE);

        // Get current user info and populate fields.
        authManager = AuthManager.getInstance(requireContext());
        long currentUserId = authManager.getCurrentUserId();
        authManager.loadUserAsync(currentUserId, user -> {
            if (!isAdded() || isDetached() || binding == null || user == null) return;
            // Populate fields with current user data.
            currentUser = user;
            binding.tvUsername.setText(currentUser.username);
            etFirstName.setText(currentUser.firstName);
            etLastName.setText(currentUser.lastName);
            etPhone.setText(currentUser.phone);

            // Store original values for change detection.
            originalFirstName = currentUser.firstName;
            originalLastName = currentUser.lastName;
            originalPhone = currentUser.phone;
            originalSmsEnabled = currentUser.smsEnabled;

            // Enable the UI and hide overlay/spinner.
            binding.profileProgressOverlay.setVisibility(View.GONE);
            binding.profileProgressSpinner.setVisibility(View.GONE);
            updateFormState();
        });

        // Assign Save Changes button handler.
        btnSaveProfile.setOnClickListener(this::handleSaveChangesClick);
    }

    @Override
    public void onResume() {
        super.onResume();

        // Check if we returned from settings after attempting to enable SMS permissions.
        SmsUtils.handleReturnFromSettings(requireActivity());
    }

    /** Check if there are unsaved changes in the form. */
    private boolean hasUnsavedChanges() {
        // If user data hasn't loaded yet, no changes to check.
        if (currentUser == null) return false;

        // Get current field values.
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        boolean smsEnabled = switchSmsEnabled.isChecked();
        String password = etPassword.getText().toString();
        String confirmPassword = etConfirmPassword.getText().toString();

        // Check if any field has changed from original values or if password fields have content.
        return !firstName.equals(originalFirstName)
            || !lastName.equals(originalLastName)
            || !phone.equals(originalPhone)
            || smsEnabled != originalSmsEnabled
            || !password.isEmpty()
            || !confirmPassword.isEmpty();
    }

    /** Handle back press with unsaved changes check. */
    private void handleBackPress() {
        if (hasUnsavedChanges()) {
            UiUtils.showDiscardChangesDialog(this, () -> requireActivity().getSupportFragmentManager().popBackStack());
        } else {
            // No unsaved changes, just pop back.
            requireActivity().getSupportFragmentManager().popBackStack();
        }
    }

    /** Update the enabled state of the Save Changes button based on form validity and changes. */
    private void updateFormState() {
        // Enable save button only if all required fields have valid data.
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirmPassword = etConfirmPassword.getText().toString();
        boolean smsEnabled = switchSmsEnabled.isChecked();

        // Validate required fields and password match.
        boolean userInfoOk = !firstName.isEmpty() && !lastName.isEmpty() && !phone.isEmpty();
        boolean passwordStrong = password.isEmpty() || AuthUtils.isStrongPassword(password);
        boolean passwordOk = (password.isEmpty() && confirmPassword.isEmpty()) || (password.equals(confirmPassword) && passwordStrong);

        // Check if at least one editable field differs from the original, or a new password was entered.
        boolean dataChanged = !firstName.equals(originalFirstName) || !lastName.equals(originalLastName) || !phone.equals(originalPhone) || smsEnabled != originalSmsEnabled || !password.isEmpty() || !confirmPassword.isEmpty();
        boolean enabled = userInfoOk && passwordOk && dataChanged;
        btnSaveProfile.setEnabled(enabled);

        // Update button background tint to match enabled/disabled state.
        int newTint = ContextCompat.getColor(requireContext(), enabled ? R.color.green_500 : R.color.button_disabled);
        DrawableCompat.setTint(btnSaveProfile.getBackground(), newTint);

        // Show inline errors proactively so user sees why Save Changes is disabled.
        if (!userInfoOk) {
            // One or more required fields are empty.
            tvProfileError.setText(R.string.profile_required_fields);
            tvProfileError.setVisibility(View.VISIBLE);

            // Set per-field errors to make it obvious which fields are missing
            etFirstName.setError(firstName.isEmpty() ? getString(R.string.profile_required_fields) : null);
            etLastName.setError(lastName.isEmpty() ? getString(R.string.profile_required_fields) : null);
            etPhone.setError(phone.isEmpty() ? getString(R.string.profile_required_fields) : null);

            // Ensure the inline message is visible by scrolling the ScrollView if needed.
            try {
                tvProfileError.bringToFront();
                tvProfileError.requestLayout();
                final int offset = (int) (getResources().getDisplayMetrics().density * 8); // 8dp
                binding.profileScroll.post(() -> binding.profileScroll.smoothScrollTo(0, Math.max(0, tvProfileError.getTop() - offset)));
            } catch (Exception e) {
                Log.e("ProfileFragment", "Error scrolling to error message", e);
            }
        } else {
            // Only show password mismatch if both fields are non-empty and they differ.
            if (!passwordOk) {
                tvProfileError.setText(password.equals(confirmPassword) ? R.string.password_strength_error : R.string.passwords_do_not_match);
                tvProfileError.setVisibility(View.VISIBLE);
            } else {
                tvProfileError.setVisibility(View.GONE);
            }
            etFirstName.setError(null);
            etLastName.setError(null);
            etPhone.setError(null);
        }
    }

    /** Handle Save Changes button click: validate data and perform async update. */
    private void handleSaveChangesClick(View v) {
        // Save is only clickable when data is valid (per updateSaveButtonState), so skip re-validating here.
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        boolean smsEnabled = switchSmsEnabled.isChecked();
        String password = etPassword.getText().toString();
        if (!password.isEmpty() && !AuthUtils.isStrongPassword(password)) {
            tvProfileError.setText(R.string.password_strength_error);
            tvProfileError.setVisibility(View.VISIBLE);
            return;
        }
        char[] newPassword = password.isEmpty() ? null : password.toCharArray();

        tvProfileError.setVisibility(View.GONE);

        // Show progress overlay and disable Save Changes button.
        binding.profileProgressOverlay.setVisibility(View.VISIBLE);
        binding.profileProgressSpinner.setVisibility(View.VISIBLE);
        btnSaveProfile.setEnabled(false);

        // Perform async update of the user in the DB.
        authManager.updateUserAsync(currentUser.userId, firstName, lastName, phone, smsEnabled, newPassword, success -> {
            // Guard against fragment gone.
            if (!isAdded() || isDetached() || binding == null) return;
            // Re-enable UI and hide overlay/spinner.
            binding.profileProgressOverlay.setVisibility(View.GONE);
            binding.profileProgressSpinner.setVisibility(View.GONE);
            if (success) {
                // Update original values to reflect the saved state.
                originalFirstName = firstName;
                originalLastName = lastName;
                originalPhone = phone;
                originalSmsEnabled = smsEnabled;

                // Clear password fields after successful save.
                etPassword.setText("");
                etConfirmPassword.setText("");

                // Show success snackbar.
                UiUtils.simpleSnackbar(requireActivity(), R.string.profile_successfully_updated);

                // Update form state (this will disable the save button since no changes now).
                updateFormState();
            } else {
                tvProfileError.setText(R.string.failed_to_save_user_data);
                tvProfileError.setVisibility(View.VISIBLE);
                updateFormState();
            }
        });
    }


    /** Clean up binding reference to avoid memory leaks. */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
