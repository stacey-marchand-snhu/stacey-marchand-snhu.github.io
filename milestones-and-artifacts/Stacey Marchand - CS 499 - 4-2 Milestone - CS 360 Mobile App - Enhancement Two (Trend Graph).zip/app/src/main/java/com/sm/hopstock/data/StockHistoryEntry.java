/**
 * File: StockHistoryEntry.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Represents one timestamped quantity snapshot for an inventory item.
 */
package com.sm.hopstock.data;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** Room entity for one item's stock level at a specific moment in time. */
@Entity(
    tableName = "stock_history",
    foreignKeys = @ForeignKey(
        entity = InventoryItem.class,
        parentColumns = "itemId",
        childColumns = "itemId",
        onDelete = ForeignKey.CASCADE
    ),
    indices = {@Index("itemId")}
)
public class StockHistoryEntry {
    @PrimaryKey(autoGenerate = true)
    public long historyId;

    // itemId links each snapshot back to its inventory item. Room cascades deletes through the foreign key.
    public long itemId;
    public int quantity;
    public long recordedAt;

    /** Default constructor. Required by Room. */
    public StockHistoryEntry() {}

    /** Convenience constructor used by repository, seed data, and tests. */
    @Ignore
    public StockHistoryEntry(long itemId, int quantity, long recordedAt) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.recordedAt = recordedAt;
    }
}
