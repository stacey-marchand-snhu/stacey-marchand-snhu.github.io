/**
 * File: UserDao.java
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Provides Room queries for creating and retrieving user accounts.
 */
package com.sm.hopstock.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    /** Find a user account by username during login and duplicate checks. */
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    UserAccount getByUsername(String username);

    /** Find a user account by database ID for profile loading and SMS alerts. */
    @Query("SELECT * FROM users WHERE userId = :id LIMIT 1")
    UserAccount getById(long id);

    /** Update an existing user account and return the number of rows changed. */
    @androidx.room.Update
    int update(UserAccount user);

    /** Insert a new user account and return the generated database ID. */
    @Insert
    long insert(UserAccount user);
}
