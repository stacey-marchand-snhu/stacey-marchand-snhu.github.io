/**
 * File: index.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express Router that maps the root path to the main controller.
 */

import { Router } from 'express'
import * as ctrlMain from '../controllers/main'

const router = Router()

// GET home page.
router.get('/', ctrlMain.index)

export default router
