/**
 * File: travel.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express Router that maps the travel path to the travel controller.
 */

import { Router } from 'express'
import * as controller from '../controllers/travel'

const router = Router()

// GET travel page.
router.get('/', controller.travel)

export default router
