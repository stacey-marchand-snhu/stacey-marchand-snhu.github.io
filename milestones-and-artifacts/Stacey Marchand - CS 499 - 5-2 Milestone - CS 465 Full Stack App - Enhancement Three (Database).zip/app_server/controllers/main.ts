/**
 * File: main.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express controller that renders the application's home page view.
 */

import type { Request, Response } from 'express'

// GET Homepage
const index = (_req: Request, res: Response): void => {
  res.render('index', { title: 'Travlr Getaways' })
}

export { index }
