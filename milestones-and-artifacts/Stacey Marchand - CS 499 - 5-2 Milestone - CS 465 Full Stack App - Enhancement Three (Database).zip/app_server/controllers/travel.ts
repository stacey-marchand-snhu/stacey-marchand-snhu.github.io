/**
 * File: travel.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express controller that fetches trips from the API and renders the
 *          travel page view.
 */

import type { Request, Response, NextFunction } from 'express'

const tripsEndpoint = 'http://localhost:3000/api/trips'
const options: RequestInit = {
  method: 'GET',
  headers: {
    Accept: 'application/json',
  },
}

// GET travel view
const travel = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  console.log('TRAVEL CONTROLLER BEGIN')
  try {
    const response = await fetch(tripsEndpoint, options)
    let json: unknown = await response.json()
    let message: string | null = null

    if (!Array.isArray(json)) {
      message = 'API lookup error'
      json = []
    } else if (json.length === 0) {
      message = 'No trips exist in our database!'
    }

    res.render('travel', { title: 'Travlr Getaways', trips: json, message })
  } catch (err) {
    next(err)
  }
}

export { travel }
