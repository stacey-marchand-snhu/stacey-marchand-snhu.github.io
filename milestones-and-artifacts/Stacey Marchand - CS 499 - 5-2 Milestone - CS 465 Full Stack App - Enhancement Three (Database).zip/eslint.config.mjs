import js from '@eslint/js'
import tsPlugin from '@typescript-eslint/eslint-plugin'
import tsParser from '@typescript-eslint/parser'
import prettierConfig from 'eslint-config-prettier'
import prettierPlugin from 'eslint-plugin-prettier'
import globals from 'globals'

export default [
  // Exclude compiled output, the separate React admin app, and static assets.
  {
    ignores: ['dist/**', 'app_admin/**', 'public/**', 'data/**'],
  },

  // Base JavaScript recommended rules.
  js.configs.recommended,

  {
    // Target all TypeScript source files in the server-side codebase.
    files: ['**/*.ts'],

    plugins: {
      '@typescript-eslint': tsPlugin,
      prettier: prettierPlugin,
    },

    languageOptions: {
      parser: tsParser,
      parserOptions: {
        ecmaVersion: 'latest',
        sourceType: 'module',
      },
      // Node.js + ES2022 globals (process, __dirname, Buffer, console, etc.)
      globals: {
        ...globals.node,
        ...globals.es2022,
      },
    },

    rules: {
      // TypeScript ESLint recommended rule set.
      ...tsPlugin.configs['recommended'].rules,

      // TypeScript's compiler already catches undefined variables and understands
      // global type namespaces (NodeJS, FirebaseFirestore, RequestInit, etc.) that
      // ESLint's no-undef rule cannot see. Disabling avoids false positives.
      'no-undef': 'off',

      // Allow underscore-prefixed parameters that are intentionally unused
      // (e.g., the required _next in Express error handlers).
      '@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],

      // Report Prettier formatting issues as warnings so the file still compiles.
      'prettier/prettier': 'warn',
    },
  },

  // Must be the last entry: turns off all ESLint rules that would conflict with Prettier.
  prettierConfig,
]


