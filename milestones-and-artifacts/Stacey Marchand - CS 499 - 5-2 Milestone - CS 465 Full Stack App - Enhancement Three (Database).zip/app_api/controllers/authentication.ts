/**
 * File: authentication.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express controller that handles user registration by creating a Firebase
 *          Auth account, setting a custom role claim, and writing a Firestore profile document.
 */

import type { Request, Response } from 'express'
import { FieldValue } from 'firebase-admin/firestore'
import { auth, db } from '../auth/firebase'
import { registerSchema } from '../validation/userSchema'

const usersCollection = db.collection('users')

// POST /register
// Creates a Firebase Auth account, attaches a custom role claim to the token,
// and writes a Firestore profile document. Returns 201 on success.
// The client then calls Firebase signInWithEmailAndPassword directly to establish
// the session - registration is kept server-side because custom claims can only
// be set via the Admin SDK in a trusted server environment.
export const register = async (req: Request, res: Response): Promise<void> => {
  // Validate and parse the request body with the shared Zod schema.
  // safeParse never throws; invalid input returns a structured error list.
  const result = registerSchema.safeParse(req.body)
  if (!result.success) {
    const errors = result.error.issues.map((i) => i.message)
    res.status(400).json({ message: 'Validation failed.', errors })
    return
  }

  const { name, email, password, role } = result.data

  try {
    // Create the Firebase Auth account. This is the source of truth for login credentials.
    const userRecord = await auth.createUser({ email, displayName: name, password })

    // Attach the role as a custom claim so it is embedded in every ID token this user receives.
    await auth.setCustomUserClaims(userRecord.uid, { role })

    // Store the public profile in Firestore so other parts of the app can
    // query user data without going through the Auth Admin SDK.
    await usersCollection.doc(userRecord.uid).set({
      uid: userRecord.uid,
      name,
      email,
      role,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.status(201).json({ message: 'Registration successful. Please log in.' })
  } catch (err) {
    // Surface duplicate-email conflicts as a 409 so the client can show a useful message.
    if ((err as { errorInfo?: { code: string } }).errorInfo?.code === 'auth/email-already-exists') {
      res.status(409).json({ message: 'An account with that email already exists.' })
      return
    }
    res.status(500).json({ message: (err as Error).message })
  }
}
