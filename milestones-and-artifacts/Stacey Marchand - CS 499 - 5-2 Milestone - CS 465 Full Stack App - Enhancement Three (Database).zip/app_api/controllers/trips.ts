/**
 * File: trips.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express controller providing CRUD handlers for trip documents stored
 *          in Firestore.
 */

import type { Request, Response } from 'express'
import { z } from 'zod'
import { tripsCollection } from '../types/trip'
import { tripSchema } from '../validation/tripSchema'

// Converts a Firestore DocumentSnapshot into a plain object, promoting the doc ID alongside the rest of the fields.
const docToObj = (doc: FirebaseFirestore.DocumentSnapshot) => ({ id: doc.id, ...doc.data() })

// Validates the request body against the trip schema.
// Returns the parsed data on success, or sends a 400 response and returns null.
const parseTrip = (req: Request, res: Response): z.infer<typeof tripSchema> | null => {
  const result = tripSchema.safeParse(req.body)
  if (!result.success) {
    const errors = result.error.issues.map((i) => i.message)
    res.status(400).json({ message: 'Validation failed.', errors })
    return null
  }
  return result.data
}

// GET /trips - returns all trips.
export const tripsList = async (_req: Request, res: Response): Promise<void> => {
  try {
    // Fetch every document in the trips collection and return them as an array.
    const snapshot = await tripsCollection.get()
    res.status(200).json(snapshot.docs.map(docToObj))
  } catch (err) {
    res.status(500).json({ message: (err as Error).message })
  }
}

// GET /trips/:tripCode - returns the trip matching the given code.
export const tripsFindByCode = async (req: Request, res: Response): Promise<void> => {
  try {
    // Query by the human-readable code field rather than the Firestore document id.
    const snapshot = await tripsCollection.where('code', '==', req.params.tripCode).get()
    if (snapshot.empty) {
      res.status(404).json({ message: 'Trip not found' })
      return
    }
    res.status(200).json(snapshot.docs.map(docToObj))
  } catch (err) {
    res.status(500).json({ message: (err as Error).message })
  }
}

// POST /trips - creates a new trip and returns the saved document.
export const tripsAddTrip = async (req: Request, res: Response): Promise<void> => {
  const data = parseTrip(req, res)
  if (!data) return

  try {
    const docRef = await tripsCollection.add(data)

    // Re-fetch the created document so the response includes the server-assigned id.
    const created = await docRef.get()
    res.status(201).json(docToObj(created))
  } catch (err) {
    // Zod already rejected invalid input above, so any error here is a server/infrastructure failure.
    res.status(500).json({ message: (err as Error).message })
  }
}

// PUT /trips/:tripCode - updates the matching trip in place.
export const tripsUpdateTrip = async (req: Request, res: Response): Promise<void> => {
  const data = parseTrip(req, res)
  if (!data) return

  // Reject if the body's code field doesn't match the URL parameter. Allowing it would
  // silently rename the trip and orphan any links built around the original code.
  if (data.code !== req.params.tripCode) {
    res.status(400).json({ message: 'Trip code in the request body must match the URL.' })
    return
  }

  try {
    // Find the document to update. The code field is the public identifier used in URLs.
    const snapshot = await tripsCollection.where('code', '==', req.params.tripCode).get()
    if (snapshot.empty) {
      res.status(404).json({ message: 'Trip not found' })
      return
    }

    // Apply the update and re-fetch so the response reflects the current stored state.
    await snapshot.docs[0].ref.update(data)
    const updated = await snapshot.docs[0].ref.get()
    res.status(200).json(docToObj(updated))
  } catch (err) {
    res.status(500).json({ message: (err as Error).message })
  }
}

// DELETE /trips/:tripCode - permanently removes the matching trip.
export const tripsDeleteTrip = async (req: Request, res: Response): Promise<void> => {
  try {
    // Look up the document by code before attempting deletion.
    const snapshot = await tripsCollection.where('code', '==', req.params.tripCode).get()
    if (snapshot.empty) {
      res.status(404).json({ message: 'Trip not found' })
      return
    }
    await snapshot.docs[0].ref.delete()
    res.status(200).json({ message: 'Trip deleted successfully' })
  } catch (err) {
    res.status(500).json({ message: (err as Error).message })
  }
}
