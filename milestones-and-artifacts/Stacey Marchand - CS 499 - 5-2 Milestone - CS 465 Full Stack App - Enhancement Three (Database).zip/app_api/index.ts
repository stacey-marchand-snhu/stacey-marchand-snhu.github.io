/**
 * File: index.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express Router that wires API endpoints for trip management and user
 *          registration to their respective controllers and middleware.
 */

import { Router } from 'express'
import * as tripsController from './controllers/trips'
import * as authController from './controllers/authentication'
import { verifyFirebaseTokenMiddleware } from './auth/verifyFirebaseTokenMiddleware'
import { requireRoleMiddleware } from './auth/requireRoleMiddleware'

// Middleware that verifies the caller's Firebase ID token and requires the admin role.
const adminMiddleware = [verifyFirebaseTokenMiddleware, requireRoleMiddleware('admin')]

const router = Router()

// For user management, only registration is handled server-side.
router.post('/register', authController.register)

// Trip management routes
router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(adminMiddleware, tripsController.tripsAddTrip)
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(adminMiddleware, tripsController.tripsUpdateTrip)
  .delete(adminMiddleware, tripsController.tripsDeleteTrip)

export default router
