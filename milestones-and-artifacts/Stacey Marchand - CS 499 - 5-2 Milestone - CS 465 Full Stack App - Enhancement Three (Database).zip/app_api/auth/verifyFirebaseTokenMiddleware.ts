/**
 * File: verifyFirebaseTokenMiddleware.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express middleware that validates a Firebase Bearer token from the
 *          Authorization header and attaches the decoded payload to req.auth.
 */

import type { Request, Response, NextFunction } from 'express'
import { auth } from './firebase'

export const verifyFirebaseTokenMiddleware = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  // Reject immediately if no Authorization header was sent at all.
  const authHeader = req.headers['authorization']
  if (!authHeader) {
    console.log('Authorization header is required but was not present.')
    res.sendStatus(401)
    return
  }

  // Ensure the header follows the "Bearer <token>" format before splitting.
  const parts = authHeader.split(' ')
  if (parts.length < 2 || parts[0].toLowerCase() !== 'bearer' || !parts[1]) {
    console.log('Authorization header is malformed. Expected: Bearer <token>')
    res.sendStatus(401)
    return
  }

  // Verify the token with Firebase and attach the decoded payload to the request.
  // Any verification failure (expired, revoked, tampered) results in a 401.
  const idToken = parts[1]
  try {
    req.auth = await auth.verifyIdToken(idToken)
    next()
  } catch (err) {
    console.log('Firebase token verification failed:', (err as Error).message)
    res.sendStatus(401)
  }
}
