/**
 * File: requireRoleMiddleware.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Express middleware that enforces role-based access control by checking
 *          the caller's custom role claim against an allowed list.
 */

import type { Request, Response, NextFunction } from 'express'
import type { Role } from '../types/user'

// Middleware that ensures the caller has one of the allowed role claims.
// Use this after verifyFirebaseToken so req.auth is already populated.
export const requireRoleMiddleware =
  (...roles: Role[]) =>
  (req: Request, res: Response, next: NextFunction): void => {
    const role = req.auth?.['role'] as Role | undefined
    if (!role || !roles.includes(role)) {
      res.status(403).json({ message: 'Forbidden: insufficient permissions.' })
      return
    }
    next()
  }
