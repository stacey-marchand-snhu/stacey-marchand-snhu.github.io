/**
 * File: seed.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Script that clears the Firestore trips collection and repopulates it
 *          from the local JSON data file.
 */

import 'dotenv/config'
import * as fs from 'fs'
import * as path from 'path'
import { db } from '../auth/firebase'
import type { TripData } from '../types/trip'

// Read and parse the seed data from the local JSON file at startup.
const trips: TripData[] = JSON.parse(
  fs.readFileSync(path.resolve(__dirname, '../../data/trips.json'), 'utf8')
)

const seedDB = async (): Promise<void> => {
  const collection = db.collection('trips')

  // Delete all existing documents before inserting fresh data.
  const existing = await collection.get()
  await Promise.all(existing.docs.map((doc) => doc.ref.delete()))
  console.log(`Deleted ${existing.size} existing trip(s).`)

  // Insert each trip from the JSON file as a new document.
  await Promise.all(trips.map((trip) => collection.add(trip)))
  console.log(`Inserted ${trips.length} trip(s) into Firestore.`)
}

seedDB()
  .then(() => {
    console.log('Firestore seeded successfully.')
    process.exit(0)
  })
  .catch((err: Error) => {
    console.error('Seed failed:', err.message)
    process.exit(1)
  })
