/**
 * File: trip.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: TypeScript interface and Firestore collection reference for trip documents
 *          used across the API.
 */

// Trip data shape and Firestore collection reference.
import { db } from '../auth/firebase'

export interface Trip {
  id?: string
  code: string
  name: string
  length: string
  start: string
  resort: string
  perPerson: string
  image: string
  description: string
}

// TripData omits the server-assigned id so it can be used safely for create and update payloads.
export type TripData = Omit<Trip, 'id'>

export const tripsCollection = db.collection('trips')
