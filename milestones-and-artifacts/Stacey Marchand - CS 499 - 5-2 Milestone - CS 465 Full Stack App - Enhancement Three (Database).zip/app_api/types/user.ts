/**
 * File: user.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: TypeScript types and valid role constants for user roles used across
 *          the API.
 */

// User role types used across the API.
export const VALID_ROLES = ['user', 'admin'] as const
export type Role = (typeof VALID_ROLES)[number]
