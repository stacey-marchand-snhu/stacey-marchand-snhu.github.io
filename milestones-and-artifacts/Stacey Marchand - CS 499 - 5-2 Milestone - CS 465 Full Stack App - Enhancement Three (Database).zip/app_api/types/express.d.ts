/**
 * File: express.d.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: TypeScript module augmentation that adds a typed req.auth property
 *          to the Express Request interface for the decoded Firebase ID token.
 */

// Augments express-serve-static-core (the actual home of the Request interface)
// so that req.auth is typed throughout the API without casting.
import type { DecodedIdToken } from 'firebase-admin/auth'

declare module 'express-serve-static-core' {
  interface Request {
    auth?: DecodedIdToken
  }
}
