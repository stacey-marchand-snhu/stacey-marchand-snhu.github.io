/**
 * File: tripSchema.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Zod validation schema for trip create and update request payloads,
 *          mirroring the client-side validation rules in TripForm.tsx.
 */

import { z } from 'zod'

// Duration format: "7 days", "10 nights", or compound "4 nights / 5 days".
const durationRegEx = /^\d+\s+(day|days|night|nights)(\s*\/\s*\d+\s+(day|days|night|nights))?$/i

// Trip code: uppercase letters, digits, and hyphens, 3–20 characters.
const codeRegEx = /^[A-Z0-9-]{3,20}$/

// Image: a bare filename with a known image extension OR a full http(s) URL.
const imageRegEx = /\.(jpe?g|png|gif|webp|svg|avif)(\?.*)?$/i
const urlRegEx = /^https?:\/\/.+/i

// Returns today's date as a YYYY-MM-DD string.
const todayIso = () => new Date().toISOString().split('T')[0]

export const tripSchema = z.object({
  code: z
    .string()
    .trim()
    .min(1, 'Trip code is required.')
    .regex(codeRegEx, 'Code must be 3–20 uppercase letters, digits, or hyphens.'),

  name: z
    .string()
    .trim()
    .min(3, 'Name must be at least 3 characters.')
    .max(40, 'Name must be 40 characters or fewer.'),

  length: z
    .string()
    .trim()
    .min(1, 'Duration is required.')
    .max(30, 'Duration must be 30 characters or fewer.')
    .regex(durationRegEx, 'Enter duration like "7 days", "10 nights", or "4 nights / 5 days".'),

  start: z
    .string()
    .trim()
    .min(1, 'Start date is required.')
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Start date must be in YYYY-MM-DD format.')
    .refine((v) => v >= todayIso(), 'Start date cannot be in the past.'),

  resort: z
    .string()
    .trim()
    .min(3, 'Resort name must be at least 3 characters.')
    .max(40, 'Resort name must be 40 characters or fewer.'),

  perPerson: z
    .string()
    .trim()
    .min(1, 'Price per person is required.')
    .refine((v) => {
      const n = Number(v)
      return !Number.isNaN(n) && n > 0
    }, 'Price must be a positive number.')
    .refine((v) => Number(v) <= 1_000_000, 'Maximum price is $1,000,000.'),

  image: z
    .string()
    .trim()
    .min(1, 'Image filename or URL is required.')
    .max(2048, 'Image path must be 2,048 characters or fewer.')
    .refine(
      (v) => imageRegEx.test(v) || urlRegEx.test(v),
      'Must be an image filename (e.g. bali.jpg) or a full URL starting with http.'
    ),

  description: z
    .string()
    .trim()
    .min(20, 'Description must be at least 20 characters.')
    .max(1000, 'Description must be 1,000 characters or fewer.'),
})
