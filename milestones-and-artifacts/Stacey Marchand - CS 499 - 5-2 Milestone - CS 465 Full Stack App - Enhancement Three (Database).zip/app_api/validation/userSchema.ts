/**
 * File: userSchema.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Zod validation schema for user registration request payloads.
 */

import { z } from 'zod'
import { VALID_ROLES } from '../types/user'

// Password complexity rules.
const passwordRules = z
  .string()
  .min(8, 'Password must be at least 8 characters.')
  .max(50, 'Password must be 50 characters or fewer.')
  .refine((v) => /[A-Z]/.test(v), 'Password must contain at least 1 uppercase letter.')
  .refine((v) => /[0-9]/.test(v), 'Password must contain at least 1 number.')
  .refine((v) => /[^A-Za-z0-9]/.test(v), 'Password must contain at least 1 special character.')

export const registerSchema = z.object({
  name: z
    .string()
    .trim()
    .min(3, 'Name must be at least 3 characters.')
    .max(50, 'Name must be 50 characters or fewer.'),

  email: z
    .string()
    .trim()
    .min(1, 'Email is required.')
    .max(60, 'Email must be 60 characters or fewer.')
    .regex(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'A valid email address is required.'),

  password: passwordRules,

  role: z
    .enum(VALID_ROLES, { error: `role must be one of: ${VALID_ROLES.join(', ')}` })
    .default('user'),
})
