# Travlr Getaways - Full-Stack Web Application

A travel booking platform consisting of a public server-rendered site, a Firebase-backed REST API, and a React admin portal.

Originally built for SNHU CS-465. Updated for CS-499 by Stacey Marchand.

| App                | Technology                                   | Port | Purpose                              |
|--------------------|----------------------------------------------|------|--------------------------------------|
| **Express server** | Node.js + Express + Handlebars + TypeScript  | 3000 | Public-facing website + REST API     |
| **Admin SPA**      | React 19 + TypeScript + Vite                 | 3001 | Authenticated trip management portal |

## Architecture

```
CS465-fullstack/
├── app.ts                          # Express application entry point
├── bin/www.ts                      # HTTP server bootstrap (port 3000)
├── package.json                    # Root Node.js dependencies & scripts
│
├── app_server/                     # Handlebars public website (MVC)
│   ├── controllers/
│   │   ├── main.ts                 # Renders the home page
│   │   └── travel.ts               # Fetches trips from the API and renders the travel page
│   ├── routes/
│   │   ├── index.ts                # Home route
│   │   └── travel.ts               # Travel page route
│   └── views/                      # Handlebars templates (layouts, partials, pages)
│
├── app_api/                        # Express REST API (JSON) with Firebase authentication
│   ├── index.ts                    # API router mounted at /api
│   ├── auth/
│   │   ├── firebase.ts             # Firebase Admin SDK initialization (auth + Firestore)
│   │   ├── verifyFirebaseTokenMiddleware.ts  # Validates Bearer tokens on protected routes
│   │   └── requireRoleMiddleware.ts          # Enforces role claims (e.g. admin)
│   ├── controllers/
│   │   ├── authentication.ts       # POST /api/register - server-side account provisioning
│   │   └── trips.ts                # CRUD operations for trip documents in Firestore
│   ├── types/
│   │   ├── express.d.ts            # Augments req.auth with DecodedIdToken type
│   │   ├── trip.ts                 # Trip type + Firestore collection reference
│   │   └── user.ts                 # Role types (user | admin)
│   └── scripts/
│       └── seed.ts                 # Clears and repopulates the Firestore trips collection
│
├── app_admin/                      # React admin SPA (see app_admin/README.md)
├── data/trips.json                 # Seed data for the Firestore trips collection
└── public/                         # Static assets (images, CSS for the public site)
```

## Backend Tech Stack

| Concern            | Library                                                                       |
|--------------------|-------------------------------------------------------------------------------|
| Web framework      | Express 4                                                                     |
| Templating         | Handlebars (`hbs`)                                                            |
| Database           | Firestore via Firebase Admin SDK (`firebase-admin`)                           |
| Authentication     | Firebase Authentication - token issued by Firebase, verified server-side      |
| Auth middleware    | Custom `verifyFirebaseTokenMiddleware` + `requireRoleMiddleware`              |
| Environment config | `dotenv`                                                                      |

For the admin SPA tech stack, see [app_admin/README.md](./app_admin/README.md).

## Prerequisites

- **Node.js 24+**
- A **Firebase project** with Authentication (Email/Password) and Firestore enabled
- A **service account key** downloaded from Firebase Console → Project Settings → Service Accounts

## Environment Variables

Copy `.env-example` to `.env` and fill in the values as indicated within the file.

```bash
cp .env-example .env
```

Note, the admin SPA requires its own `.env` file - see [app_admin/README.md](./app_admin/README.md) for details.

## Getting Started

> ⚠️ The Express server must be running before the admin SPA is started. All data and authentication calls go through the Express server.

```bash
# 1. Install root dependencies
npm install

# 2. Seed Firestore with trip data (first run only, or to reset)
npm run seed-db

# 3. Start the Express server
npm start
```

Then, in a separate terminal, follow the setup steps in [app_admin/README.md](./app_admin/README.md) to install and start the admin SPA.

## Available Scripts

| Script               | Description                                                               |
|----------------------|---------------------------------------------------------------------------|
| `npm start`          | Start the Express server via `ts-node` on port 3000                       |
| `npm run build`      | Compile TypeScript to `dist/`                                             |
| `npm run typecheck`  | Type-check without emitting files                                         |
| `npm run start:prod` | Run the compiled production build from `dist/`                            |
| `npm run seed-db`    | Clear and reseed the Firestore `trips` collection from `data/trips.json`  |

For admin SPA scripts, see [app_admin/README.md](./app_admin/README.md).

## REST API

All endpoints are prefixed with `/api` and served on port **3000**.

### Authentication

| Method | Path            | Auth Required | Description                                                                  |
|--------|-----------------|---------------|------------------------------------------------------------------------------|
| `POST` | `/api/register` | No            | Creates a Firebase Auth account, sets role claim, stores Firestore profile   |

Note: In the future, this would be a protected route accessible only to existing admins.
For simplicity, however, it is currently unprotected.
You can create admin accounts by sending a `POST` request with `name`, `email`, `role`, and `password` to `/api/register`.

### Trips

| Method   | Path                   | Auth Required   | Description                  |
|----------|------------------------|-----------------|------------------------------|
| `GET`    | `/api/trips`           | No              | Return all trips             |
| `GET`    | `/api/trips/:tripCode` | No              | Return a single trip by code |
| `POST`   | `/api/trips`           | **Admin token** | Create a new trip            |
| `PUT`    | `/api/trips/:tripCode` | **Admin token** | Update an existing trip      |
| `DELETE` | `/api/trips/:tripCode` | **Admin token** | Delete a trip                |

Protected routes require a valid Firebase ID token as a `Bearer` token in the `Authorization` header. The token must also carry the `role: admin` custom claim.

## Authentication Flow

1. An admin account is created server-side via `POST /api/register`.
2. The Firebase Admin SDK sets a custom `role` claim on the account at creation time.
3. The client signs in using the Firebase SDK; the issued ID token contains the `role` claim.
4. The admin SPA attaches a fresh token to every API request automatically – see [app_admin/README.md](./app_admin/README.md).

## CORS

The Express server allows cross-origin requests from `http://localhost:3001` on all `/api` routes, supporting `GET`, `POST`, `PUT`, and `DELETE` with an `Authorization` header. Configured in `app.ts`.

## Database

- **Provider:** Google Cloud Firestore (managed, serverless – no local database required)
- **Collections:**
  - `trips` - Trip documents (`code`, `name`, `length`, `start`, `resort`, `perPerson`, `image`, `description`)
  - `users` - User profile documents (`uid`, `name`, `email`, `role`, `createdAt`)
- **Seed script:** `npm run seed-db` clears the `trips` collection and repopulates it from `data/trips.json`
