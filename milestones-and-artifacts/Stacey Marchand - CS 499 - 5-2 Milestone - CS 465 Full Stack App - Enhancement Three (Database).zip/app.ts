import 'dotenv/config'
import createError from 'http-errors'
import express, { type Request, type Response, type NextFunction } from 'express'
import path from 'path'
import cookieParser from 'cookie-parser'
import logger from 'morgan'
import hbs from 'hbs'

// Initialize Firebase / Firestore
import './app_api/auth/firebase'

import apiRouter from './app_api'
import indexRouter from './app_server/routes/index'
import travelRouter from './app_server/routes/travel'

const app = express()

// View engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'))
app.set('view engine', 'hbs')

hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'))

app.use(logger('dev'))
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())
app.use(express.static(path.join(__dirname, 'public')))

// Enable CORS for the React admin app dev server
app.use('/api', (req: Request, res: Response, next: NextFunction) => {
  const allowedOrigin = process.env.CORS_ORIGIN ?? 'http://localhost:3001'
  res.header('Access-Control-Allow-Origin', allowedOrigin)
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  )
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  if (req.method === 'OPTIONS') {
    res.sendStatus(204)
    return
  }
  next()
})

app.use('/', indexRouter)
app.use('/travel', travelRouter)
app.use('/api', apiRouter)

// 404 handler
app.use((_req: Request, _res: Response, next: NextFunction) => {
  next(createError(404))
})

// Error handler
app.use(
  (err: { status?: number; message: string }, req: Request, res: Response, _next: NextFunction) => {
    res.locals.message = err.message
    res.locals.error = req.app.get('env') === 'development' ? err : {}
    res.status(err.status ?? 500)
    res.render('error')
  }
)

export default app
