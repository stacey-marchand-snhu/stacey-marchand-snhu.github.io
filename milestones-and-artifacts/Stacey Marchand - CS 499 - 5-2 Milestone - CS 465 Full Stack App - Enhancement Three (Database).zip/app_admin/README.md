# Travlr Getaways - Admin Portal

A React + TypeScript single-page application that provides authenticated trip management for the Travlr Getaways platform.

Built for SNHU CS-465 and updated for CS-499 by Stacey Marchand.

## Tech Stack

| Layer          | Library / Tool                        |
|----------------|---------------------------------------|
| UI framework   | React 19 + TypeScript                 |
| Build tool     | Vite 6                                |
| Styling        | Tailwind CSS                          |
| Routing        | React Router v6                       |
| HTTP client    | Axios                                 |
| Authentication | Firebase client SDK (`firebase/auth`) |
| HTML sanitizer | DOMPurify                             |
| Linting        | ESLint + `eslint-plugin-prettier`     |
| Formatting     | Prettier                              |

## Project Structure

```
src/
├── api/
│   ├── authApi.ts         # login() via Firebase signInWithEmailAndPassword
│   ├── AuthContext.tsx    # Firebase auth state, role helpers, and useAuth hook
│   ├── axiosInstance.ts   # Configures base URL, attaches ID token, handles 401 globally
│   ├── firebase.ts        # Firebase client SDK initialization
│   └── tripApi.ts         # Trip CRUD API wrappers (getTrips, addTrip, updateTrip, deleteTrip)
├── components/
│   ├── ConfirmDialog.tsx  # Native <dialog> modal for confirming destructive actions
│   ├── Layout.tsx         # Full-page layout with sticky Navbar and footer
│   ├── Navbar.tsx         # Top navigation bar with user greeting and logout button
│   ├── PageTransition.tsx # Fade-in animation wrapper for route changes
│   ├── ProtectedRoute.tsx # Redirects unauthenticated users; enforces role when specified
│   ├── Toast.tsx          # Slide-in toast notification with auto-dismiss
│   ├── TripCard.tsx       # Displays a trip's details; admin controls for edit and delete
│   └── TripForm.tsx       # Reusable form for creating and editing trips with validation
├── models/
│   ├── Trip.ts            # Trip and TripFormData interfaces
│   └── User.ts            # User interface and Role type
├── pages/
│   ├── LoginPage.tsx      # Login form with inline validation
│   ├── DashboardPage.tsx  # Trip grid with toast support and delete-refresh
│   ├── AddTripPage.tsx    # Wraps TripForm for creating a new trip
│   └── EditTripPage.tsx   # Loads an existing trip and wraps TripForm for editing
├── utils/
│   └── tripHelpers.ts     # sanitizeHtml (DOMPurify) and resolveImageUrl helpers
├── App.tsx                # Route definitions and AuthProvider wrapper
└── index.tsx              # React entry point
```

## Getting Started

### Prerequisites

- Node.js 24+
- The Express API server running on port **3000** (see root `README.md`)
- A `.env` file (copy from `app_admin/.env-example`)

### Environment Variables

Copy `.env-example` to `.env` and fill in the values as indicated within the file.

```bash
cp .env-example .env
```

### Install & Run

```bash
# from the app_admin/ directory
npm install      # install dependencies
npm start        # start SPA development server on http://localhost:3001
```

## Available Scripts

| Script             | Description                                                       |
|--------------------|-------------------------------------------------------------------|
| `npm start`        | Start the Vite dev server with hot reload @ http://localhost:3001 |
| `npm run build`    | Type-check then produce a production build in `dist/`             |
| `npm run lint`     | Check for ESLint errors                                           |
| `npm run lint:fix` | Auto-fix ESLint errors where possible                             |
| `npm run format`   | Format all source files with Prettier                             |

## Authentication Flow

1. The user submits credentials on `/login`.
2. `authApi.login()` calls Firebase `signInWithEmailAndPassword` directly.
3. Firebase issues an ID token containing the user's `role` custom claim.
4. `AuthContext` subscribes to `onAuthStateChanged` and exposes `isLoggedIn()`, `isAdmin()`, and `getCurrentUser()`.
5. Every Axios request automatically attaches a fresh `Bearer` token via the request interceptor in `axiosInstance.ts`.
6. If any API response returns `401`, the interceptor signs the user out via Firebase and redirects to `/login`.
7. `ProtectedRoute` guards all non-login routes and can optionally enforce the `admin` role.
8. Logging out shows a `ConfirmDialog` before calling Firebase `signOut()` and navigating to `/login`.

## API Endpoints Consumed

All requests go to `VITE_API_URL` (default: `http://localhost:3000/api`).

| Method   | Path               | Auth required | Description                      |
|----------|--------------------|---------------|----------------------------------|
| `GET`    | `/trips`           | No            | Returns all trips                |
| `GET`    | `/trips/:tripCode` | No            | Returns a single trip (for edit) |
| `POST`   | `/trips`           | Admin token   | Creates a new trip               |
| `PUT`    | `/trips/:tripCode` | Admin token   | Updates an existing trip         |
| `DELETE` | `/trips/:tripCode` | Admin token   | Deletes a trip                   |

> The admin app does not have a registration UI. Admin accounts are provisioned server-side via `POST /api/register`.
