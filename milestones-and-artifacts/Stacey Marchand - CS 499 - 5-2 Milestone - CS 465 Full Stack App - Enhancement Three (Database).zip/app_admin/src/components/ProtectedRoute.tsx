﻿/**
 * File: ProtectedRoute.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Guards routes so only authenticated (and optionally role-authorized) users
 *          can access them; redirects unauthenticated users to the login page.
 */

import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../api/AuthContext'
import { Role } from '../models/User'

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredRole?: Role // when set, also enforces the role in addition to login
}

// Renders children only when the user is authenticated and (optionally) holds
// the required role. During Firebase's brief startup initialization, it renders
// nothing to avoid a false redirect before the session has been resolved.
const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, requiredRole }) => {
  const { isLoggedIn, isAdmin, loading } = useAuth()

  // Wait for Firebase to resolve the persisted session before making any decision.
  if (loading) return null

  if (!isLoggedIn()) return <Navigate to="/login" replace />

  if (requiredRole === 'admin' && !isAdmin()) {
    return (
      <Navigate
        to="/"
        replace
        state={{ toast: 'Access denied: admin only.', toastType: 'warning' }}
      />
    )
  }

  return <>{children}</>
}

export default ProtectedRoute
