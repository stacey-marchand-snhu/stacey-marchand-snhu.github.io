/**
 * File: Navbar.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Sticky top navigation bar that displays the portal branding, an authenticated
 *          user's greeting with role badge, and a logout button with confirmation dialog.
 */

import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../api/AuthContext'
import { LogOut } from 'lucide-react'
import ConfirmDialog from './ConfirmDialog'

const Navbar: React.FC = () => {
  const { isLoggedIn, logout, getCurrentUser, isAdmin } = useAuth()
  const location = useLocation()
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)

  const loggedIn = isLoggedIn()
  const admin = loggedIn && isAdmin()
  const user = loggedIn ? getCurrentUser() : null

  // Hide the Login link when the user is already on the login page.
  const onLoginPage = location.pathname === '/login'

  const handleLogout = () => {
    setShowLogoutConfirm(false)
    logout()
  }

  // Sticky bar spanning the full viewport width with brand title left, auth controls right.
  return (
    <nav className="bg-surface-800 border-b border-surface-500 sticky top-0 z-50 shadow-lg shadow-black/40">
      {/* Constrained inner row - max width matches the dashboard grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Title */}
        <span className="text-white font-medium text-lg tracking-wide">
          Travlr Getaways Administrator Portal
        </span>

        {/* Auth controls - greeting + logout when authenticated, login link when not */}
        <div className="flex items-center gap-7">
          {loggedIn ? (
            <>
              {/* Welcome message - hidden on small screens to save horizontal space */}
              {user && (
                <span className="text-slate-400 text-sm hidden sm:block">
                  Welcome, <span className="font-medium text-white">{user.name}</span>
                  {admin ? (
                    <span className="ml-2 text-xs bg-cyan-900/50 text-cyan-400 border border-cyan-700 px-1.5 py-0.5 rounded-full">
                      admin
                    </span>
                  ) : (
                    <span className="ml-2 text-xs bg-slate-700/60 text-slate-400 border border-slate-600 px-1.5 py-0.5 rounded-full">
                      standard user
                    </span>
                  )}
                </span>
              )}

              {/* Logout button with icon */}
              <button
                onClick={() => setShowLogoutConfirm(true)}
                className="flex items-center gap-1.5 text-sm font-medium text-slate-300 hover:bg-surface-700 hover:text-white px-4 py-1.5 rounded-lg transition-colors"
              >
                <LogOut size={16} aria-hidden="true" />
                Logout
              </button>

              {/* Logout confirmation dialog */}
              {showLogoutConfirm && (
                <ConfirmDialog
                  title="Log Out"
                  message="Are you sure you want to log out?"
                  confirmLabel="Log Out"
                  cancelLabel="Cancel"
                  onConfirm={handleLogout}
                  onCancel={() => setShowLogoutConfirm(false)}
                />
              )}
            </>
          ) : (
            // Login link.
            !onLoginPage && (
              <Link
                to="/login"
                className="text-sm font-medium bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-1.5 rounded-lg transition-colors"
              >
                Login
              </Link>
            )
          )}
        </div>
      </div>
    </nav>
  )
}

export default Navbar
