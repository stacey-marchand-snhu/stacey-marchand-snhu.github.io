/**
 * File: ConfirmDialog.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Reusable modal confirmation dialog built on the native HTML dialog element,
 *          providing automatic focus trapping, an accessible backdrop, and Escape key handling.
 */

import React, { useRef, useEffect } from 'react'

interface ConfirmDialogProps {
  message: string
  title?: string
  confirmLabel?: string
  cancelLabel?: string
  onConfirm: () => void
  onCancel: () => void
}

// Modal confirmation dialog built on the native HTML <dialog> element.
// The native element provides automatic focus trapping and a backdrop.
// showModal() is called via a ref once the element is in the DOM.
const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  message,
  title,
  confirmLabel = 'Delete',
  cancelLabel = 'Cancel',
  onConfirm,
  onCancel,
}) => {
  const dialogRef = useRef<HTMLDialogElement>(null)

  // Open the dialog as a modal as soon as it mounts.
  useEffect(() => dialogRef.current?.showModal(), [])

  // Native <dialog> element - showModal() activates the full-screen ::backdrop overlay.
  return (
    <dialog
      ref={dialogRef}
      // Prevent default on the native cancel event to keep onCancel in control of the Escape key.
      onCancel={(e) => {
        e.preventDefault()
        onCancel()
      }}
      aria-labelledby={title ? 'confirm-title' : 'confirm-message'}
      className="rounded-2xl shadow-2xl border border-surface-500 bg-surface-700 text-white p-6 w-full max-w-sm backdrop:bg-black/70"
    >
      {/* Title */}
      {title && (
        <h2 id="confirm-title" className="text-white font-semibold text-lg mb-3">
          {title}
        </h2>
      )}

      {/* Body message */}
      <p id="confirm-message" className="text-slate-300 text-base leading-relaxed mb-6">
        {message}
      </p>

      {/* Buttons */}
      <div className="flex justify-end gap-3">
        {/* Cancel */}
        <button
          onClick={onCancel}
          className="px-4 py-2 rounded-lg border border-surface-400 text-slate-300 hover:bg-surface-600 text-sm font-medium transition-colors"
        >
          {cancelLabel}
        </button>

        {/* Confirm */}
        <button
          onClick={onConfirm}
          className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-semibold transition-colors"
        >
          {confirmLabel}
        </button>
      </div>
    </dialog>
  )
}

export default ConfirmDialog
