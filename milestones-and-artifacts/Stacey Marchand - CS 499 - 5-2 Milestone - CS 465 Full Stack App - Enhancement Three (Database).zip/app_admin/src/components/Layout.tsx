/**
 * File: Layout.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Root layout shell that renders the sticky Navbar at the top, an animated
 *          content outlet in the middle, and a scroll-aware sticky footer at the bottom.
 */

import React, { useEffect, useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Navbar from './Navbar'
import PageTransition from './PageTransition'

const Layout: React.FC = () => {
  const location = useLocation()
  const [showFooterShadow, setShowFooterShadow] = useState(false)

  // Intensify the footer shadow while the page is scrollable; clear it once the user reaches the bottom.
  useEffect(() => {
    const onScroll = () => {
      // A tolerance of 8px prevents the shadow from flickering on sub-pixel scroll positions.
      const atBottom = window.innerHeight + window.scrollY >= document.body.scrollHeight - 8
      setShowFooterShadow(!atBottom)
    }
    window.addEventListener('scroll', onScroll, { passive: true })

    // Fire immediately to set the correct initial state before the first scroll.
    onScroll()
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Full-page flex column - Navbar sticks to the top, main grows to fill remaining space, footer sticks to the bottom.
  return (
    <div className="min-h-screen bg-surface-900 flex flex-col font-sans">
      {/* Sticky top navigation bar */}
      <Navbar />

      {/* Primary content area - pb-14 reserves space so content never slides behind the sticky footer */}
      <main className="flex-1 flex flex-col pb-14">
        {/* Animates the page in on route change */}
        <PageTransition locationKey={location.pathname}>
          {/* Renders whichever child route is currently active */}
          <Outlet />
        </PageTransition>
      </main>

      {/* Sticky footer - shadow intensifies while the page is scrollable, fades once at the bottom */}
      <footer
        className={`sticky bottom-0 z-40 bg-surface-800 border-t border-surface-500 text-slate-500 text-center py-4 text-sm transition-shadow duration-300 ${
          showFooterShadow
            ? 'shadow-[0_-12px_40px_rgba(0,0,0,0.75)]'
            : 'shadow-[0_-4px_16px_rgba(0,0,0,0.35)]'
        }`}
      >
        &copy; {new Date().getFullYear()} Travlr Getaways - Re-imagined by Stacey Marchand for SNHU
        CS-499
      </footer>
    </div>
  )
}

export default Layout
