/**
 * File: tripHelpers.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Utility functions for sanitizing HTML content and resolving trip image
 *          URLs used across the admin application.
 */

import DOMPurify from 'dompurify'

// Sanitizes an HTML string using DOMPurify so it is safe to inject via dangerouslySetInnerHTML.
export const sanitizeHtml = (html: string): string => {
  const clean = DOMPurify.sanitize(html, {
    ALLOWED_TAGS: ['p', 'br', 'strong', 'em', 'b', 'i', 'ul', 'ol', 'li', 'h3', 'h4', 'a'],
    ALLOWED_ATTR: ['href', 'target', 'rel'],
  })
  // Post-process: enforce rel="noopener noreferrer" on every anchor tag so
  // that no link can leak the referrer or gain opener access.
  const doc = new DOMParser().parseFromString(clean, 'text/html')
  doc.querySelectorAll('a').forEach((el) => el.setAttribute('rel', 'noopener noreferrer'))
  return doc.body.innerHTML
}

// Resolves a trip image filename to a full URL. Bare filenames are served by the Express static
// middleware at /images/<filename>; absolute http(s) URLs are returned unchanged.
export const resolveImageUrl = (image: string): string => {
  if (image.startsWith('http')) return image
  const base = (import.meta.env.VITE_API_URL ?? '').replace(/\/api$/, '')
  return `${base}/images/${image}`
}
