/**
 * File: User.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: TypeScript types for user roles and user data decoded from the
 *          Firebase ID token used across the admin application.
 */

// Represents the subset of user data decoded from the Firebase ID token payload.
export type Role = 'user' | 'admin'

// User data with a role claim, decoded from the Firebase ID token and used across the admin application.
export interface User {
  name: string
  email: string
  role: Role
}
