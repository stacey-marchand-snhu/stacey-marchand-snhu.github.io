/**
 * File: Trip.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: TypeScript interfaces for trip documents and form data used across
 *          the admin application.
 */

// Represents a trip document returned from the Firestore-backed API.
export interface Trip {
  id: string // Firestore document ID
  code: string
  name: string
  length: string
  start: string
  resort: string
  perPerson: string
  image: string
  description: string
}

// TripFormData mirrors Trip but without id, which is assigned by Firestore.
export type TripFormData = Omit<Trip, 'id'>
