/**
 * File: authApi.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Client-side login function that authenticates the user via Firebase
 *          email/password sign-in and lets onAuthStateChanged handle session state.
 */

import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from './firebase'

export interface LoginPayload {
  email: string
  password: string
}

// Signs the user in via Firebase. The Firebase SDK's onAuthStateChanged listener
// in AuthContext picks up the new session automatically - no token wrangling needed.
export const login = async (payload: LoginPayload): Promise<void> => {
  await signInWithEmailAndPassword(auth, payload.email, payload.password)
}
