/**
 * File: AuthContext.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: React context that provides Firebase-backed authentication state and helper
 *          functions (isLoggedIn, isAdmin, logout, getCurrentUser) to the entire application.
 */

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import {
  type IdTokenResult,
  onAuthStateChanged,
  signOut,
  type User as FirebaseUser,
} from 'firebase/auth'
import { auth } from './firebase'
import { Role, User } from '../models/User'

interface AuthContextType {
  isLoggedIn: () => boolean
  isAdmin: () => boolean
  logout: () => void
  getCurrentUser: () => User | null
  // True during the brief moment Firebase is resolving the persisted session on
  // startup. Components should not make auth decisions until this is false.
  loading: boolean
}

const AuthContext = createContext<AuthContextType | null>(null)

// Provides authentication state and helpers to all descendant components.
// Internally subscribes to the Firebase auth state, so token refresh and
// session persistence are handled automatically by the SDK.
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null)
  const [claims, setClaims] = useState<Record<string, unknown>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Subscribe to auth state changes. Firebase calls this immediately with the
    // current session state, then again whenever the user signs in or out.
    return onAuthStateChanged(auth, async (user) => {
      if (user) {
        // Fetch custom claims before updating state so that firebaseUser and claims
        // are never out of sync. Setting firebaseUser before the await would cause
        // a render where the user appears logged in but claims are still empty,
        // making isAdmin() return false and getCurrentUser() return the wrong role.
        const tokenResult: IdTokenResult = await user.getIdTokenResult()
        setFirebaseUser(user)
        setClaims(tokenResult.claims as Record<string, unknown>)
      } else {
        setFirebaseUser(null)
        setClaims({})
      }
      setLoading(false)
    })
  }, [])

  const isLoggedIn = useCallback((): boolean => !!firebaseUser, [firebaseUser])

  const isAdmin = useCallback((): boolean => claims['role'] === 'admin', [claims])

  // Calls Firebase signOut and lets onAuthStateChanged handle the state update.
  const logout = useCallback((): void => {
    signOut(auth).catch(console.error)
  }, [])

  const getCurrentUser = useCallback((): User | null => {
    if (!firebaseUser) return null
    return {
      name: firebaseUser.displayName ?? firebaseUser.email ?? 'Unknown',
      email: firebaseUser.email ?? '',
      role: (claims['role'] as Role) ?? 'user',
    }
  }, [firebaseUser, claims])

  // Memoize the context value to prevent unnecessary re-renders in consumers.
  const contextValue = useMemo(
    () => ({ isLoggedIn, isAdmin, logout, getCurrentUser, loading }),
    [isLoggedIn, isAdmin, logout, getCurrentUser, loading]
  )

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
}

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
