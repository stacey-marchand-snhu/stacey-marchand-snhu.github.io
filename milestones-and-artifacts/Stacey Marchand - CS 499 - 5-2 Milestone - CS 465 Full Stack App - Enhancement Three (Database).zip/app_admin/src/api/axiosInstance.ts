/**
 * File: axiosInstance.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Pre-configured Axios instance that automatically attaches a fresh Firebase
 *          ID token to every outgoing request and forces sign-out on 401 responses.
 */

import axios from 'axios'
import { signOut } from 'firebase/auth'
import { auth } from './firebase'

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL ?? '/api' })

// Attach a fresh Firebase ID token to every outgoing request.
// getIdToken() automatically refreshes the token if it is close to expiring,
// so the app never sends a stale token regardless of how long the session has been open.
api.interceptors.request.use(async (config) => {
  const token = await auth.currentUser?.getIdToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Handle invalid or expired sessions globally. On a 401 response, sign out
// via Firebase (which clears the local session) and hard-redirect to the login page.
api.interceptors.response.use(
  (response) => response,
  async (err: unknown) => {
    if (axios.isAxiosError(err) && err.response?.status === 401) {
      await signOut(auth)
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default api
