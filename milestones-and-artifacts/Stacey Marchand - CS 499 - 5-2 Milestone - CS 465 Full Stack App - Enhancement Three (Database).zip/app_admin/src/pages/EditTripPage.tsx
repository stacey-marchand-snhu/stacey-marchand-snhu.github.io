/**
 * File: EditTripPage.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Page that loads a trip by code and renders the TripForm pre-populated
 *          for editing, then redirects to the dashboard on a successful save.
 */

import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { getTrip, updateTrip } from '../api/tripApi'
import { Trip, TripFormData } from '../models/Trip'
import TripForm from '../components/TripForm'

const EditTripPage: React.FC = () => {
  const { code } = useParams<{ code: string }>()
  const navigate = useNavigate()
  const [trip, setTrip] = useState<Trip | null>(null)
  const [loadError, setLoadError] = useState('')

  useEffect(() => {
    if (!code) {
      navigate('/')
      return
    }

    // getTrip returns an array even for a single match; read index [0].
    // The start date is normalized to YYYY-MM-DD so it populates the date input correctly;
    // Firestore stores dates as ISO strings which may include a time component the input rejects.
    getTrip(code)
      .then((data) => {
        if (data && data.length > 0) {
          const t = data[0]
          setTrip({
            ...t,
            start: t.start ? new Date(t.start).toISOString().split('T')[0] : '',
          })
        } else {
          setLoadError('Trip not found.')
        }
      })
      .catch(() => setLoadError('Failed to load trip details.'))
  }, [code, navigate])

  // Persists the edited trip, then returns to the dashboard with a success toast.
  const handleSubmit = async (data: TripFormData) => {
    if (!trip) return
    await updateTrip({ ...data, id: trip.id })
    navigate('/', { state: { toast: 'Trip saved successfully!', toastType: 'success' } })
  }

  // Returns to the dashboard without saving.
  const handleCancel = () => navigate('/')

  // Page wrapper - constrained width and padding matching the rest of the app.
  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page header */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-white">Edit Trip</h1>
        <p className="text-slate-400 text-sm mt-1">Update the details for this trip package.</p>
      </div>

      {/* Error state - shown when the trip could not be fetched (bad code, network error, etc.) */}
      {loadError && (
        <div className="mb-6 px-4 py-3 rounded-lg bg-red-900/20 border border-red-800 text-red-400 text-sm">
          {loadError}
        </div>
      )}

      {/* Loading state - spinner shown while the trip data is being fetched */}
      {!loadError && !trip && (
        <div className="flex flex-col items-center py-20 text-slate-500">
          {/* Spinning ring indicator */}
          <div className="w-10 h-10 rounded-full border-4 border-surface-500 border-t-cyan-500 animate-spin mb-4" />
          <p className="text-sm">Loading trip…</p>
        </div>
      )}

      {/* Edit form - only rendered once trip data has loaded successfully */}
      {trip && (
        <TripForm
          initialValues={trip}
          submitLabel="Save Changes"
          onSubmit={handleSubmit}
          onCancel={handleCancel}
        />
      )}
    </div>
  )
}

export default EditTripPage
