import js from '@eslint/js'
import tsPlugin from '@typescript-eslint/eslint-plugin'
import tsParser from '@typescript-eslint/parser'
import reactHooks from 'eslint-plugin-react-hooks'
import prettierConfig from 'eslint-config-prettier'
import prettierPlugin from 'eslint-plugin-prettier'
import globals from 'globals'

export default [
  // Base JavaScript recommended rules.
  js.configs.recommended,

  {
    // Target all TypeScript and TSX source files.
    files: ['src/**/*.{ts,tsx}'],

    plugins: {
      '@typescript-eslint': tsPlugin,
      'react-hooks': reactHooks,
      prettier: prettierPlugin,
    },

    languageOptions: {
      parser: tsParser,
      parserOptions: {
        ecmaVersion: 'latest',
        sourceType: 'module',
        ecmaFeatures: { jsx: true },
      },
      // Provide the full browser + ES2022 global set so window, document,
      // fetch, setTimeout, etc. are all recognised without manual enumeration.
      globals: {
        ...globals.browser,
        ...globals.es2022,
      },
    },

    rules: {
      // TypeScript ESLint recommended rule set.
      ...tsPlugin.configs['recommended'].rules,

      // TypeScript's compiler already catches undefined variables; disabling
      // no-undef avoids false positives on TypeScript global type namespaces.
      'no-undef': 'off',

      // Allow underscore-prefixed parameters that are intentionally unused.
      '@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],

      // React Hooks rules (rules-of-hooks + exhaustive-deps).
      'react-hooks/rules-of-hooks': 'error',
      'react-hooks/exhaustive-deps': 'warn',

      // Report Prettier formatting issues as warnings so the file still compiles.
      'prettier/prettier': 'warn',
    },
  },

  // Must be the last entry: turns off all ESLint rules that would conflict with Prettier.
  prettierConfig,
]




