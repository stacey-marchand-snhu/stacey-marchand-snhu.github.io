# Travlr Getaways - Admin Portal

A React + TypeScript single-page application that provides authenticated trip management for the Travlr Getaways platform.

Built for SNHU CS-465 and updated for CS-499 by Stacey Marchand.

## Tech Stack

| Layer          | Library / Tool                                     |
|----------------|----------------------------------------------------|
| UI framework   | React 19 + TypeScript                              |
| Build tool     | Vite 6                                             |
| Styling        | Tailwind CSS                                       |
| Routing        | React Router v6                                    |
| HTTP client    | Axios                                              |
| Authentication | JWT stored in a cookie (`js-cookie`, `jwt-decode`) |
| Linting        | ESLint + `eslint-plugin-prettier`                  |
| Formatting     | Prettier                                           |

## Project Structure

```
src/
├── api/
│   ├── axiosInstance.ts   # Configures base URL, auth header, and 401 interceptor
│   ├── authApi.ts         # Login and registration operations
│   └── tripApi.ts         # Trip CRUD operations
├── components/
│   ├── ConfirmDialog.tsx  # Reusable modal for confirming destructive actions (e.g. logout, delete trip)
│   ├── Layout.tsx         # Main layout with Navbar and page transitions
│   ├── Navbar.tsx         # Top navigation bar with links and logout button
│   ├── PageTransition.tsx # Smooth fade-in animation for route changes
│   ├── ProtectedRoute.tsx # Route wrapper that redirects unauthenticated users
│   ├── Toast.tsx          # Simple toast notification component
│   ├── TripCard.tsx       # Displays a trip's details in the dashboard grid
│   └── TripForm.tsx       # Reusable form for creating and editing trips
├── context/
│   └── AuthContext.tsx    # Provides auth state and helper functions
├── models/                # TypeScript interfaces for API data structures (e.g. Trip, User)
├── pages/
│   ├── LoginPage.tsx      # Login form
│   ├── DashboardPage.tsx  # Displays all trips in a grid
│   ├── AddTripPage.tsx    # Wraps TripForm for creating a new trip
│   └── EditTripPage.tsx   # Wraps TripForm for editing an existing trip
├── utils/
│   └── tripHelpers.ts     # Utilities for trip HTML formatting
└── constants.ts           # Shared constants
```

## Getting Started

### Prerequisites

- Node.js 24+
- The Express API server running on port **3000** (see root `README.md`)
- A `.env` file (copy from `app_admin/.env-example`)

### Install & Run

```bash
# from the app_admin/ directory
npm install      # install dependencies
npm start        # start SPA development server
```

## Available Scripts

| Script             | Description                                                       |
|--------------------|-------------------------------------------------------------------|
| `npm start`        | Start the Vite dev server with hot reload @ http://localhost:3001 |
| `npm run build`    | Type-check then produce a production build in `build/`            |
| `npm run lint`     | Check for ESLint errors                                           |
| `npm run lint:fix` | Auto-fix ESLint errors where possible                             |
| `npm run format`   | Format all source files with Prettier                             |

## Authentication Flow

1. The user submits credentials on `/login`.
2. On success, the API returns a JWT which is stored in a cookie via `js-cookie`.
3. Every subsequent API request automatically includes the token as a `Bearer` header (via an Axios request interceptor).
4. If any response returns `401`, the interceptor clears the cookie and hard-redirects to `/login`.
5. `ProtectedRoute` wraps all non-login routes and redirects unauthenticated visitors before they can render.
6. Logging out shows a `ConfirmDialog` before clearing the cookie and navigating to `/login`.

## API Endpoints Consumed

All requests go to `VITE_API_URL` (default: `http://localhost:3000/api`).

| Method   | Path               | Auth required | Description                |
|----------|--------------------|---------------|----------------------------|
| `POST`   | `/login`           | No            | Returns a JWT              |
| `POST`   | `/register`        | No            | Creates a new user account |
| `GET`    | `/trips`           | No            | Returns all trips          |
| `GET`    | `/trips/:tripCode` | No            | Returns a single trip      |
| `POST`   | `/trips`           | Yes           | Creates a new trip         |
| `PUT`    | `/trips/:tripCode` | Yes           | Updates an existing trip   |
| `DELETE` | `/trips/:tripCode` | Yes           | Deletes a trip             |
