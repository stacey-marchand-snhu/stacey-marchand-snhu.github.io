/**
 * File: AddTripPage.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Page that renders the TripForm to create a new trip and redirects
 *          to the dashboard with a success toast on completion.
 */

import React from 'react'
import { useNavigate } from 'react-router-dom'
import { addTrip } from '../api/tripApi'
import { TripFormData } from '../models/Trip'
import TripForm from '../components/TripForm'

const AddTripPage: React.FC = () => {
  const navigate = useNavigate()

  // Submits the new trip to the API, then returns to the dashboard with a success toast.
  const handleSubmit = async (data: TripFormData) => {
    await addTrip(data)
    navigate('/', { state: { toast: 'Trip added successfully!', toastType: 'success' } })
  }

  // Returns to the dashboard without saving.
  const handleCancel = () => navigate('/')

  // Page wrapper - constrained width and padding matching the rest of the app.
  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page header */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-white">Add New Trip</h1>
        <p className="text-slate-400 text-sm mt-1">
          Fill out the details below to add a new trip package.
        </p>
      </div>

      {/* Trip creation form */}
      <TripForm submitLabel="Add Trip" onSubmit={handleSubmit} onCancel={handleCancel} />
    </div>
  )
}

export default AddTripPage
