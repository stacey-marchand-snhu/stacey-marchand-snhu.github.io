/**
 * File: LoginPage.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Login page that authenticates the user via the REST API and stores
 *          the returned JWT in a cookie via AuthContext.
 */

import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { login } from '../api/authApi'
import { Eye, EyeOff } from 'lucide-react'

interface FormState {
  email: string
  password: string
}
type FormErrors = Partial<Record<keyof FormState, string>>

// Defined outside the component to avoid re-allocating the class string on every render.
const inputBaseStyle =
  'w-full px-3 py-2.5 rounded-lg border border-surface-500 bg-surface-600 text-white text-sm ' +
  'focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:bg-surface-700 ' +
  'transition-colors placeholder-slate-600'

// Validates a single login form field and returns a human-readable error message.
const validateField = (name: keyof FormState, value: string): string => {
  if (name === 'email') {
    if (!value.trim()) return 'Email address is required.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Please enter a valid email address.'
  }
  if (name === 'password' && !value) return 'Password is required.'
  return ''
}

const LoginPage: React.FC = () => {
  const navigate = useNavigate()
  const { saveToken, isLoggedIn } = useAuth()

  // Redirect immediately if the user is already authenticated.
  useEffect(() => {
    if (isLoggedIn()) navigate('/')
  }, [isLoggedIn, navigate])

  const [form, setForm] = useState<FormState>({ email: '', password: '' })
  const [errors, setErrors] = useState<FormErrors>({})
  const [serverError, setServerError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  // Updates form state on every keystroke, validates the changed field in real time, and clears any stale server error.
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
    setServerError('')
    const msg = validateField(name as keyof FormState, value)
    setErrors((prev) => ({ ...prev, [name]: msg || undefined }))
  }

  // Validates all fields and populates the errors state.
  // Returns true when the form is fully valid, false otherwise.
  const validate = (): boolean => {
    const e: FormErrors = {}
    const emailMsg = validateField('email', form.email)
    const passwordMsg = validateField('password', form.password)
    if (emailMsg) e.email = emailMsg
    if (passwordMsg) e.password = passwordMsg
    setErrors(e)
    return Object.keys(e).length === 0
  }

  // Validates the form, submits credentials to the API, and navigates to the
  // dashboard on success. A 429 response is given a specific rate-limit message;
  // all other errors fall back to a generic credential failure message.
  const handleSubmit = async (e: React.SubmitEvent<HTMLFormElement>) => {
    e.preventDefault()
    setServerError('')
    if (!validate()) return
    setSubmitting(true)

    try {
      const response = await login(form)
      saveToken(response.token)
      navigate('/', { state: { toast: 'Logged in successfully!', toastType: 'success' } })
    } catch (err: unknown) {
      // Axios types the caught error as unknown, so the response status must be cast out.
      const status = (err as { response?: { status?: number } })?.response?.status

      if (status === 429) {
        setServerError('Too many failed login attempts. Please wait 5 minutes before trying again.')
      } else {
        setServerError('Login failed. Please check your credentials and try again.')
      }
    } finally {
      setSubmitting(false)
    }
  }

  // Full-screen centered layout so the card sits in the middle of the remaining viewport height.
  return (
    <div className="flex-1 flex items-center justify-center bg-surface-900 px-4 py-10">
      {/* Login card */}
      <div className="bg-surface-700 rounded-2xl shadow-2xl border border-surface-500 w-full max-w-md p-8">
        {/* Card header */}
        <div className="text-center mb-8">
          {/* Travlr logo */}
          <img
            src="/logo.png"
            alt="Travlr Getaways"
            className="h-16 w-auto mx-auto mb-3 object-contain"
          />

          {/* Admin Portal label */}
          <p className="text-slate-400 text-sm tracking-wide">Administrator Portal</p>
        </div>

        {/* noValidate disables browser built-in validation, so our custom messages are used instead */}
        <form onSubmit={handleSubmit} noValidate>
          {/* Server-side error banner - shown after a failed submission attempt */}
          {serverError && (
            <div className="mb-5 px-4 py-3 rounded-lg bg-red-900/20 border border-red-800 text-red-400 text-sm">
              {serverError}
            </div>
          )}

          {/* Email field */}
          <div className="mb-4">
            <label
              htmlFor="email"
              className="block text-xs font-medium uppercase tracking-wide text-cyan-400 mb-1.5"
            >
              Email Address
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={form.email}
              onChange={handleChange}
              placeholder="admin@travlr.com"
              className={`${inputBaseStyle} ${errors.email ? 'border-red-500 bg-red-900/20 focus:ring-red-500' : ''}`}
            />

            {/* Inline validation error - only rendered when a message is present */}
            {errors.email && <p className="text-xs text-red-400 mt-1">{errors.email}</p>}
          </div>

          {/* Password field with show/hide toggle */}
          <div className="mb-6">
            <label
              htmlFor="password"
              className="block text-xs font-medium uppercase tracking-wide text-cyan-400 mb-1.5"
            >
              Password
            </label>

            {/* Password text field */}
            <div className="relative">
              <input
                id="password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                value={form.password}
                onChange={handleChange}
                placeholder="••••••••"
                className={`${inputBaseStyle} pr-10 ${errors.password ? 'border-red-500 bg-red-900/20 focus:ring-red-500' : ''}`}
              />

              {/* Show/hide toggle */}
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute inset-y-0 right-0 flex items-center px-3 text-slate-400 hover:text-cyan-400 transition-colors"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            {/* Inline validation error - only rendered when a message is present */}
            {errors.password && <p className="text-xs text-red-400 mt-1">{errors.password}</p>}
          </div>

          {/* Submit button - disabled and dimmed while the request is in flight */}
          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-cyan-600 hover:bg-cyan-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-medium py-2.5 rounded-lg transition-colors"
          >
            {submitting ? 'Signing in…' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default LoginPage
