/**
 * File: DashboardPage.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Main dashboard page that fetches and displays all trips as cards
 *          and shows toast notifications passed via React Router navigation state.
 */

import React, { useEffect, useState, useCallback } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { getTrips } from '../api/tripApi'
import { Trip } from '../models/Trip'
import TripCard from '../components/TripCard'
import Toast from '../components/Toast'

// Describes the navigation state shape used to pass toast messages between pages.
interface LocationState {
  toast?: string
  toastType?: 'success' | 'info' | 'warning'
}

const DashboardPage: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // Local toast triggered by in-page actions (e.g., deletion).
  const [toast, setToast] = useState<{
    message: string
    type: 'success' | 'info' | 'warning'
  } | null>(null)

  // Counter that re-triggers the fetch effect on deletions without calling setState synchronously in the effect body.
  const [refreshCounter, setRefreshCounter] = useState(0)

  const navigate = useNavigate()
  const location = useLocation()

  // Re-run on initial load and after deletions; setState is deferred to async callbacks to avoid React warnings.
  useEffect(() => {
    let cancelled = false
    getTrips()
      .then((data) => {
        if (!cancelled) {
          setTrips(data)
          setError('')
          setLoading(false)
        }
      })
      .catch(() => {
        if (!cancelled) {
          setError('Could not load trips. Please check the API server is running.')
          setLoading(false)
        }
      })
    return () => {
      cancelled = true
    }
  }, [refreshCounter])

  // Derive the nav-state toast during render; navToast is null when there is no pending message.
  const locationState = location.state as LocationState | null
  const navToast = locationState?.toast
    ? {
        message: locationState.toast,
        type: (locationState.toastType ?? 'success') as 'success' | 'info' | 'warning',
      }
    : null

  // Local toast takes priority; fall back to the navigation-state toast.
  const activeToast = toast ?? navToast

  const handleAddTrip = useCallback(() => navigate('/add-trip'), [navigate])

  // After a deletion, silently refresh the list (no loading spinner) and show a toast.
  const handleTripDeleted = useCallback((msg?: string) => {
    setRefreshCounter((c) => c + 1)
    if (msg) setToast({ message: msg, type: 'success' })
  }, [])

  // Clear whichever toast is active. If it was a nav-state toast, also wipe the
  // history entry so it does not reappear on refresh.
  const handleToastDone = useCallback(() => {
    setToast(null)
    if ((location.state as LocationState | null)?.toast) {
      navigate(location.pathname, { replace: true, state: {} })
    }
  }, [navigate, location.pathname, location.state])

  // Produces a count label for the page subtitle.
  const tripCountLabel = trips.length === 1 ? '1 trip' : `${trips.length} trips`

  // Page wrapper - matches the max-width and padding of all other pages.
  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Toast notification - rendered here so it floats above the whole page */}
      {activeToast && (
        <Toast message={activeToast.message} type={activeToast.type} onDone={handleToastDone} />
      )}

      {/* Page header */}
      <div className="flex flex-wrap items-start justify-between gap-4 mb-8">
        <div>
          {/* Page title */}
          <h1 className="text-2xl font-semibold text-white">Trip Management</h1>

          {/* Subtitle - live trip count once loading completes */}
          <p className="text-slate-400 text-sm mt-1">
            {loading ? 'Loading…' : `${tripCountLabel} on record`}
          </p>
        </div>

        {/* Add Trip button */}
        <button
          onClick={handleAddTrip}
          className="bg-cyan-600 hover:bg-cyan-700 text-white font-medium text-sm px-5 py-2.5 rounded-lg shadow-sm transition-colors whitespace-nowrap"
        >
          + Add New Trip
        </button>
      </div>

      {/* Error state - shown when the API request fails */}
      {error && (
        <div className="mb-6 px-4 py-3 rounded-lg bg-red-900/20 border border-red-800 text-red-400 text-sm">
          {error}
        </div>
      )}

      {/* Loading state - spinner shown while trips are being fetched */}
      {loading && (
        <div className="flex flex-col items-center py-20 text-slate-500">
          {/* Spinning ring indicator */}
          <div className="w-10 h-10 rounded-full border-4 border-surface-500 border-t-cyan-500 animate-spin mb-4" />
          <p className="text-sm">Loading trips…</p>
        </div>
      )}

      {/* Empty state - shown once loaded but no trips exist in the database */}
      {!loading && !error && trips.length === 0 && (
        <div className="text-center py-20 text-slate-500">
          <p className="text-base">No trips found.</p>
          <p className="text-sm mt-1">
            Click <strong className="text-white">+ Add New Trip</strong> to get started.
          </p>
        </div>
      )}

      {/* Trip grid - responsive 1/2/3 column layout depending on viewport width */}
      {!loading && trips.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 items-start">
          {trips.map((trip) => (
            <TripCard key={trip._id} trip={trip} onDeleted={handleTripDeleted} />
          ))}
        </div>
      )}
    </div>
  )
}

export default DashboardPage
