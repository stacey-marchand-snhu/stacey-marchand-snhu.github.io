/**
 * File: constants.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Application-wide constants shared across modules.
 */

// Cookie key used to store the JWT auth token.
export const AUTH_COOKIE_KEY = 'travlr-token'
