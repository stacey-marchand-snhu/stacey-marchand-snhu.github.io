/**
 * File: authApi.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Client-side login function that posts credentials to the REST API
 *          and returns the JWT auth token on success.
 */

import api from './axiosInstance'
import { AuthResponse } from '../models/AuthResponse'

export interface LoginPayload {
  email: string
  password: string
}

// Submits login credentials and returns a JWT auth token on success.
export const login = (payload: LoginPayload): Promise<AuthResponse> =>
  api.post<AuthResponse>('/login', payload).then((r) => r.data)
