/**
 * File: axiosInstance.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Pre-configured Axios instance that automatically attaches the stored JWT
 *          to every outgoing request and redirects to /login on 401 responses.
 */

import axios from 'axios'
import Cookies from 'js-cookie'
import { AUTH_COOKIE_KEY } from '../constants'

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL ?? '/api' })

// Attach the auth token to every outgoing request except the auth endpoints themselves.
// Login and register requests must not carry a token - the server would reject them.
api.interceptors.request.use((config) => {
  const url = config.url ?? ''
  const isAuthCall = url === '/login' || url === '/register'
  if (!isAuthCall) {
    const token = Cookies.get(AUTH_COOKIE_KEY)
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
  }
  return config
})

// Handle invalid or expired sessions globally. On a 401 for non-auth endpoints, remove the cookie
// and redirect to /login; 401s from /login or /register are left for the caller to handle.
api.interceptors.response.use(
  (response) => response,
  (err: unknown) => {
    const status = (err as { response?: { status?: number } })?.response?.status
    const url = (err as { config?: { url?: string } })?.config?.url ?? ''
    const isAuthCall = url === '/login' || url === '/register'

    if (status === 401 && !isAuthCall) {
      Cookies.remove(AUTH_COOKIE_KEY)
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default api
