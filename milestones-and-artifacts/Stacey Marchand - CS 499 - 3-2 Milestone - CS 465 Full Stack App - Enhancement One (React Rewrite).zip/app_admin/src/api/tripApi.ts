/**
 * File: tripApi.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Client-side API functions for all CRUD operations on trip documents,
 *          using the shared Axios instance for authenticated requests.
 */

import api from './axiosInstance'
import { Trip, TripFormData } from '../models/Trip'

// Fetches all trip documents from the API.
export const getTrips = (): Promise<Trip[]> => api.get<Trip[]>('/trips').then((r) => r.data)

// Fetches a single trip by code. The API returns an array even for a single match,
// so callers should read index [0] of the result.
export const getTrip = (code: string): Promise<Trip[]> =>
  api.get<Trip[]>(`/trips/${code}`).then((r) => r.data)

// Creates a new trip and returns the saved document including its assigned _id.
export const addTrip = (trip: TripFormData): Promise<Trip> =>
  api.post<Trip>('/trips', trip).then((r) => r.data)

// Updates an existing trip in place using its code as the URL key.
export const updateTrip = (trip: Trip): Promise<Trip> =>
  api.put<Trip>(`/trips/${trip.code}`, trip).then((r) => r.data)

// Permanently deletes a trip by code.
export const deleteTrip = (code: string): Promise<void> =>
  api.delete(`/trips/${code}`).then(() => undefined)
