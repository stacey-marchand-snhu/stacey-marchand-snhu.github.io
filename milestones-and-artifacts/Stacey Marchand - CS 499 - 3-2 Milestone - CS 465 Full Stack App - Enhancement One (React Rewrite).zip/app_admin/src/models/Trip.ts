/**
 * File: Trip.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: TypeScript interfaces for trip documents and form data used across
 *          the admin application.
 */

// Represents a trip document returned from the API, including the MongoDB-assigned _id.
export interface Trip {
  _id: string
  code: string
  name: string
  length: string
  start: string
  resort: string
  perPerson: string
  image: string
  description: string
}

// TripFormData mirrors Trip but without _id, which is not known at creation time.
export type TripFormData = Omit<Trip, '_id'>
