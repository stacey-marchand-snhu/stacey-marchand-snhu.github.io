/**
 * File: AuthResponse.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Type definition for the response body returned by the login endpoint.
 */

// Shape of the successful response returned by the login and register endpoints.
export interface AuthResponse {
  token: string
}
