/**
 * File: User.ts
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: TypeScript types for user data decoded from the JWT payload
 *          used across the admin application.
 */

// Represents the subset of user data decoded from the JWT payload.
export interface User {
  name: string
  email: string
}
