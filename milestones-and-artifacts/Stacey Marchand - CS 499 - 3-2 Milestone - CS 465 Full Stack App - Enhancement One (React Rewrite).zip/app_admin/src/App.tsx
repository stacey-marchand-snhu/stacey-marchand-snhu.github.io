/**
 * File: App.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Defines the React Router configuration and wraps the entire application
 *          in the AuthProvider so the authentication state is available on every page.
 */

import React from 'react'
import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import Layout from './components/Layout'
import ProtectedRoute from './components/ProtectedRoute'
import LoginPage from './pages/LoginPage'
import DashboardPage from './pages/DashboardPage'
import AddTripPage from './pages/AddTripPage'
import EditTripPage from './pages/EditTripPage'

// All routes are nested under Layout, so the Navbar and footer render on every page.
// Protected routes require a valid JWT - unauthenticated users are redirected to /login.
const router = createBrowserRouter(
  [
    {
      element: <Layout />,
      children: [
        { path: '/login', element: <LoginPage /> },
        {
          path: '/',
          element: (
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          ),
        },
        {
          path: '/add-trip',
          element: (
            <ProtectedRoute>
              <AddTripPage />
            </ProtectedRoute>
          ),
        },
        {
          path: '/edit-trip/:code',
          element: (
            <ProtectedRoute>
              <EditTripPage />
            </ProtectedRoute>
          ),
        },
        // Catch-all: redirect any unrecognized path to the dashboard.
        { path: '*', element: <Navigate to="/" replace /> },
      ],
    },
  ],
  // Opt in to the React Router v7 splat-path behavior now to avoid a
  // breaking-change warning when the library upgrades to v7.
  { future: { v7_relativeSplatPath: true } }
)

const App: React.FC = () => (
  <AuthProvider>
    <RouterProvider router={router} />
  </AuthProvider>
)

export default App
