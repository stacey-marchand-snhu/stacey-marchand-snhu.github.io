/**
 * File: AuthContext.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: React context that provides JWT-based authentication state and helper
 *          functions (isLoggedIn, saveToken, logout, getCurrentUser) to the entire application.
 */

import React, { createContext, useContext, useState, useCallback, useMemo } from 'react'
import Cookies from 'js-cookie'
import { jwtDecode } from 'jwt-decode'
import { User } from '../models/User'
import { AUTH_COOKIE_KEY } from '../constants'

interface DecodedToken {
  name: string
  email: string
  exp: number
}

// Decodes a JWT payload. Returns null if the token is malformed or cannot be parsed.
const decodeToken = (token: string): DecodedToken | null => {
  try {
    return jwtDecode<DecodedToken>(token)
  } catch {
    return null
  }
}

interface AuthContextType {
  token: string | null
  isLoggedIn: () => boolean
  saveToken: (token: string) => void
  logout: () => void
  getCurrentUser: () => User | null
}

const AuthContext = createContext<AuthContextType | null>(null)

// Provides authentication state and helpers to all descendant components.
// Token state is initialized from the cookie so sessions survive page refreshes.
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(() => Cookies.get(AUTH_COOKIE_KEY) ?? null)

  // Persists the token to a cookie and syncs it into React state.
  // The Secure flag is only set in production - plain HTTP on localhost would
  // silently discard a Secure cookie, breaking login in the dev server.
  const saveToken = useCallback((newToken: string) => {
    Cookies.set(AUTH_COOKIE_KEY, newToken, {
      secure: import.meta.env.PROD,
      sameSite: 'strict',
    })
    setToken(newToken)
  }, [])

  // Clears the token from both the cookie and React state, effectively us logging out.
  const logout = useCallback(() => {
    Cookies.remove(AUTH_COOKIE_KEY)
    setToken(null)
  }, [])

  // Drive auth checks from token state so React reactivity is the single source of truth.
  // Expiry is validated on every call, so stale sessions are rejected without a server round-trip.
  const isLoggedIn = useCallback((): boolean => {
    if (!token) return false
    const payload = decodeToken(token)
    return !!payload && payload.exp > Date.now() / 1000
  }, [token])

  // Decodes the current token to extract the user's display name and email.
  const getCurrentUser = useCallback((): User | null => {
    if (!token) return null
    const payload = decodeToken(token)
    if (!payload) return null
    return { name: payload.name, email: payload.email }
  }, [token])

  // Memoize the context value to prevent unnecessary re-renders in consumers.
  const contextValue = useMemo(
    () => ({ token, isLoggedIn, saveToken, logout, getCurrentUser }),
    [token, isLoggedIn, saveToken, logout, getCurrentUser]
  )

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
}

// Returns the auth context value.
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
