/**
 * File: TripForm.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Reusable form component for creating and editing trip documents, with
 *          client-side validation and unsaved-changes navigation blocking.
 */

import React, { useEffect, useMemo, useRef, useState } from 'react'
import { useBlocker, useNavigate } from 'react-router-dom'
import ConfirmDialog from './ConfirmDialog'
import { TripFormData } from '../models/Trip'

interface TripFormProps {
  initialValues?: Partial<TripFormData>
  onSubmit: (data: TripFormData) => Promise<void>
  onCancel: () => void
  submitLabel: string
}

type FormErrors = Partial<Record<keyof TripFormData, string>>

const emptyForm: TripFormData = {
  code: '',
  name: '',
  length: '',
  start: '',
  resort: '',
  perPerson: '',
  image: '',
  description: '',
}

// Style constants defined outside the component to avoid re-creating these strings on every render.
const inputBaseStyle =
  'w-full px-3 py-2 rounded-lg border border-surface-500 bg-surface-600 text-white text-sm ' +
  'focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:bg-surface-700 ' +
  'transition-colors placeholder-slate-600'
const inputErrorStyle = 'border-red-500 bg-red-900/20 focus:ring-red-500 focus:border-red-500'
const labelClassStyle = 'block text-xs font-medium uppercase tracking-wide text-cyan-400 mb-1.5'

// Validation patterns.
// Duration format: "7 days", "10 nights", or compound "4 nights / 5 days".
const durationRegEx = /^\d+\s+(day|days|night|nights)(\s*\/\s*\d+\s+(day|days|night|nights))?$/i
// Trip code: uppercase letters, digits, and hyphens, 3–20 characters.
const codeRegEx = /^[A-Z0-9-]{3,20}$/
// Image: either a bare filename with a known image extension or a full http(s) URL.
const imageRegEx = /\.(jpe?g|png|gif|webp|svg|avif)(\?.*)?$/i
const urlRegEx = /^https?:\/\/.+/i

// Returns today's date as a YYYY-MM-DD string for use as the date input's min attribute.
const todayIso = () => new Date().toISOString().split('T')[0]

/**
 * Validates a single form field and returns an error message string,
 * or an empty string if the value is valid.
 *
 * @param key   The field name to validate.
 * @param value The current string value of that field.
 */
const validateField = (key: keyof TripFormData, value: string): string => {
  const v = String(value).trim()
  switch (key) {
    case 'code':
      if (!v) return 'Trip code is required.'
      if (!codeRegEx.test(v)) return 'Code must be 3–20 uppercase letters, digits, or hyphens.'
      return ''
    case 'name':
      if (!v) return 'Trip name is required.'
      if (v.length < 3) return 'Name must be at least 3 characters.'
      if (v.length > 40) return 'Name must be 40 characters or fewer.'
      return ''
    case 'length':
      if (!v) return 'Duration is required.'
      if (v.length > 30) return 'Duration must be 30 characters or fewer.'
      if (!durationRegEx.test(v))
        return 'Enter duration like "7 days", "10 nights", or "4 nights / 5 days".'
      return ''
    case 'start':
      if (!v) return 'Start date is required.'
      if (v < todayIso()) return 'Start date cannot be in the past.'
      return ''
    case 'resort':
      if (!v) return 'Resort name is required.'
      if (v.length < 3) return 'Resort name must be at least 3 characters.'
      if (v.length > 40) return 'Resort name must be 40 characters or fewer.'
      return ''
    case 'perPerson': {
      if (!v) return 'Price per person is required.'
      const n = Number(v)
      if (Number.isNaN(n) || n <= 0) return 'Price must be a positive number.'
      if (n > 1000000) return 'Maximum price is $1,000,000.'
      return ''
    }
    case 'image':
      if (!v) return 'Image filename or URL is required.'
      if (!imageRegEx.test(v) && !urlRegEx.test(v))
        return 'Must be an image filename (e.g. bali.jpg) or a full URL starting with http.'
      return ''
    case 'description':
      if (!v) return 'Description is required.'
      if (v.length < 20) return 'Description must be at least 20 characters.'
      if (v.length > 1000) return 'Description must be 1,000 characters or fewer.'
      return ''
    default:
      return ''
  }
}

// Validates every field and returns a map of field → error message; an empty object means the form is valid.
const validateAll = (form: TripFormData): FormErrors => {
  const e: FormErrors = {}
  ;(Object.keys(form) as (keyof TripFormData)[]).forEach((key) => {
    const msg = validateField(key, form[key])
    if (msg) e[key] = msg
  })
  return e
}

const TripForm: React.FC<TripFormProps> = ({
  initialValues = {},
  onSubmit,
  onCancel,
  submitLabel,
}) => {
  const navigate = useNavigate()

  // Baseline snapshot used to detect unsaved changes; captured once at mount via a lazy initializer.
  const [baseline] = useState<TripFormData>(() => ({ ...emptyForm, ...initialValues }))
  const [form, setForm] = useState<TripFormData>(() => ({ ...emptyForm, ...initialValues }))
  const [errors, setErrors] = useState<FormErrors>({})
  const [serverError, setServerError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  // Flags used to suppress the navigation blocker in legitimate exit scenarios.
  // Set before awaiting onSubmit so the blocker won't fire during the navigation triggered by a successful save.
  const saveSucceeded = useRef(false)

  // Set when the user confirms leaving; allows the blocker's navigate() call to proceed unblocked.
  const discarding = useRef(false)

  // True when any field differs from its baseline value.
  const isDirty = useMemo(
    () => (Object.keys(form) as (keyof TripFormData)[]).some((k) => form[k] !== baseline[k]),
    [form, baseline]
  )

  // Block in-app navigation when there are unsaved changes. The blocker is
  // bypassed after a successful save or when the user explicitly confirms leaving.
  const blocker = useBlocker(({ currentLocation, nextLocation }) => {
    return (
      !saveSucceeded.current &&
      !discarding.current &&
      isDirty &&
      currentLocation.pathname !== nextLocation.pathname
    )
  })

  // Warn the browser's native unload dialog (tab close, refresh, external link)
  // when there are unsaved changes.
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (isDirty) e.preventDefault()
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [isDirty])

  // Pressing Escape anywhere on the page triggers cancel, regardless of which
  // element has focus. If a native <dialog> is open (e.g., the unsaved-changes
  // blocker), that dialog handles its own Escape and this handler steps aside.
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return
      if (document.querySelector('dialog[open]')) return
      onCancel()
    }
    document.addEventListener('keydown', handleEscape)
    return () => document.removeEventListener('keydown', handleEscape)
  }, [onCancel])

  // Prevents Enter key presses from submitting the form mid-edit, except
  // inside textarea elements where Enter is valid for entering new lines.
  const handleKeyDown = (e: React.KeyboardEvent<HTMLFormElement>) => {
    if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
      e.preventDefault()
    }
  }

  // Updates form state on every keystroke and validates the changed field in real time.
  // The code field is auto-uppercased.
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name } = e.target
    const value = name === 'code' ? e.target.value.toUpperCase() : e.target.value
    setForm((prev) => ({ ...prev, [name]: value }))
    const msg = validateField(name as keyof TripFormData, value)
    setErrors((prev) => ({ ...prev, [name]: msg || undefined }))
  }

  // Validates a single field when focus leaves it, ensuring errors appear
  // even if the user tabs through a field without typing anything.
  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    const key = name as keyof TripFormData
    const msg = validateField(key, value)
    setErrors((prev) => ({ ...prev, [key]: msg || undefined }))
  }

  // Runs full validation, then calls onSubmit if all fields are valid.
  // saveSucceeded is set before the await so the blocker won't interrupt
  // the navigation the parent triggers after a successful save.
  const handleSubmit = async (e: React.SubmitEvent<HTMLFormElement>) => {
    e.preventDefault()
    setServerError('')
    const e2 = validateAll(form)
    setErrors(e2)
    if (Object.keys(e2).length > 0) return
    setSubmitting(true)
    try {
      saveSucceeded.current = true
      await onSubmit(form)
    } catch {
      saveSucceeded.current = false
      setServerError('An error occurred while saving. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  /**
   * Renders a labeled input field with inline validation feedback.
   *
   * @param key   The TripFormData key this field is bound to.
   * @param label The human-readable label shown above the input.
   * @param props Optional HTML input attributes (e.g., type, placeholder, maxLength).
   * @param hint  Optional hint text shown below the input when there is no error.
   */
  const field = (
    key: keyof TripFormData,
    label: string,
    props?: React.InputHTMLAttributes<HTMLInputElement>,
    hint?: string
  ) => (
    <div>
      <label htmlFor={key} className={labelClassStyle}>
        {label}
      </label>
      <input
        id={key}
        name={key}
        value={form[key]}
        onChange={handleChange}
        onBlur={handleBlur}
        className={`${inputBaseStyle} ${errors[key] ? inputErrorStyle : ''}`}
        {...props}
      />
      {errors[key] ? (
        <p className="text-xs text-red-400 mt-1">{errors[key]}</p>
      ) : hint ? (
        <p className="text-xs text-slate-500 mt-1">{hint}</p>
      ) : null}
    </div>
  )

  const descLen = form.description.length
  const nameLen = form.name.length
  const resortLen = form.resort.length

  return (
    <>
      {/* Main form card */}
      <form
        onSubmit={handleSubmit}
        onKeyDown={handleKeyDown}
        noValidate
        className="bg-surface-700 rounded-xl shadow-xl border border-surface-500 p-6 max-w-3xl"
      >
        {/* Server-level error banner - shown when the API call fails after passing validation */}
        {serverError && (
          <div className="mb-5 px-4 py-3 rounded-lg bg-red-900/20 border border-red-800 text-red-400 text-sm">
            {serverError}
          </div>
        )}

        {/* Row 1 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
          {/* Trip code */}
          {field(
            'code',
            'Trip Code',
            { placeholder: 'e.g. BALI2026', maxLength: 20 },
            'Uppercase letters, digits, and hyphens only (3–20 chars).'
          )}

          {/* Trip name */}
          <div>
            <label htmlFor="name" className={labelClassStyle}>
              Trip Name
            </label>
            <input
              id="name"
              name="name"
              value={form.name}
              onChange={handleChange}
              onBlur={handleBlur}
              maxLength={40}
              placeholder="e.g. Bali Reef Adventure"
              className={`${inputBaseStyle} ${errors.name ? inputErrorStyle : ''}`}
            />

            {/* Validation error on left, character counter on right */}
            <div className="flex justify-between mt-1">
              {errors.name ? <p className="text-xs text-red-400">{errors.name}</p> : <span />}
              <p
                className={`text-xs ml-auto ${nameLen > 33 ? 'text-amber-400' : 'text-slate-500'}`}
              >
                {nameLen}/40
              </p>
            </div>
          </div>
        </div>

        {/* Row 2 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
          {/* Trip length */}
          {field(
            'length',
            'Duration',
            { placeholder: 'e.g. 7 days', maxLength: 30 },
            'Format: "7 days", "10 nights", or "4 nights / 5 days".'
          )}

          {/* Start date */}
          {field('start', 'Start Date', { type: 'date', min: todayIso() })}
        </div>

        {/* Row 3 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
          {/* Resort name */}
          <div>
            <label htmlFor="resort" className={labelClassStyle}>
              Resort
            </label>
            <input
              id="resort"
              name="resort"
              value={form.resort}
              onChange={handleChange}
              onBlur={handleBlur}
              maxLength={40}
              placeholder="e.g. Kuta Beach Resort"
              className={`${inputBaseStyle} ${errors.resort ? inputErrorStyle : ''}`}
            />

            {/* Validation error on the left, character counter on the right */}
            <div className="flex justify-between mt-1">
              {errors.resort ? <p className="text-xs text-red-400">{errors.resort}</p> : <span />}
              <p
                className={`text-xs ml-auto ${resortLen > 33 ? 'text-amber-400' : 'text-slate-500'}`}
              >
                {resortLen}/40
              </p>
            </div>
          </div>

          {/* Price per person */}
          {field(
            'perPerson',
            'Price Per Person ($)',
            { type: 'number', min: '1', max: '1000000', step: '0.01', placeholder: 'e.g. 1999' },
            'Must be between $1 and $1,000,000.'
          )}
        </div>

        {/* Row 4 - Image filename or URL */}
        <div className="mb-5">
          {field(
            'image',
            'Image (filename or URL)',
            { placeholder: 'e.g. bali.jpg or https://...' },
            'Accepted formats: jpg, png, gif, webp, svg, avif - or a full https:// URL.'
          )}
        </div>

        {/* Row 5 - Description */}
        <div className="mb-6">
          <label htmlFor="description" className={labelClassStyle}>
            Description
          </label>
          <textarea
            id="description"
            name="description"
            rows={4}
            value={form.description}
            onChange={handleChange}
            onBlur={handleBlur}
            maxLength={1000}
            placeholder="Describe the trip experience..."
            className={`${inputBaseStyle} resize-y min-h-[100px] ${errors.description ? inputErrorStyle : ''}`}
          />

          {/* Validation hint on the left, character counter on the right */}
          <div className="flex justify-between mt-1">
            {errors.description ? (
              <p className="text-xs text-red-400">{errors.description}</p>
            ) : (
              <p className="text-xs text-slate-500">At least 20 characters required.</p>
            )}
            <p
              className={`text-xs ml-4 shrink-0 ${descLen > 950 ? 'text-amber-400' : 'text-slate-500'}`}
            >
              {descLen}/1000
            </p>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex justify-end gap-3">
          {/* Cancel */}
          <button
            type="button"
            onClick={onCancel}
            className="text-sm font-medium bg-red-900/20 hover:bg-red-900/40 text-red-400 border border-red-800 px-6 py-2.5 rounded-lg transition-colors"
          >
            Cancel
          </button>

          {/* Submit */}
          <button
            type="submit"
            disabled={submitting}
            className="text-sm font-medium bg-cyan-600 hover:bg-cyan-700 disabled:opacity-40 disabled:cursor-not-allowed text-white px-8 py-2.5 rounded-lg transition-colors"
          >
            {submitting ? 'Saving...' : submitLabel}
          </button>
        </div>
      </form>

      {/* Unsaved-changes dialog */}
      {blocker.state === 'blocked' && (
        <ConfirmDialog
          title="Unsaved Changes"
          message="You have unsaved changes. Are you sure you want to leave? Your changes will be lost."
          confirmLabel="Leave"
          cancelLabel="Stay"
          onConfirm={() => {
            const destination = blocker.location?.pathname ?? '/'
            discarding.current = true
            blocker.reset()
            navigate(destination, { state: { toast: 'Changes discarded.', toastType: 'warning' } })
          }}
          onCancel={() => blocker.reset()}
        />
      )}
    </>
  )
}

export default TripForm
