/**
 * File: Toast.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Animated toast notification component that auto-dismisses after a
 *          configurable duration and fades out before calling onDone.
 */

import React, { useEffect, useRef, useState } from 'react'

interface ToastProps {
  message: string
  type?: 'success' | 'info' | 'warning'
  duration?: number
  onDone: () => void
}

// Tailwind class sets keyed by toast type for border, background, and text color.
const styles = {
  success: 'bg-emerald-900/80 border-emerald-700 text-emerald-300',
  info: 'bg-cyan-900/80 border-cyan-700 text-cyan-300',
  warning: 'bg-amber-900/80 border-amber-700 text-amber-300',
}

// Status icon characters keyed by toast type.
const icons = {
  success: '✓',
  info: 'ℹ',
  warning: '⚠',
}

const Toast: React.FC<ToastProps> = ({ message, type = 'success', duration = 3500, onDone }) => {
  const [visible, setVisible] = useState(false)

  // Stable ref for onDone so the effect doesn't re-run on every parent render.
  const onDoneRef = useRef(onDone)
  useEffect(() => {
    onDoneRef.current = onDone
  })

  useEffect(() => {
    // Defer the slide-in to the next paint so the CSS transition has an initial from-state.
    const show = requestAnimationFrame(() => setVisible(true))

    // Start fade-out 400ms early so the transition completes before onDone() unmounts the component.
    const hide = setTimeout(() => setVisible(false), duration - 400)
    const done = setTimeout(() => onDoneRef.current(), duration)

    return () => {
      cancelAnimationFrame(show)
      clearTimeout(hide)
      clearTimeout(done)
    }
  }, [duration])

  // Floating banner fixed to the top-center of the viewport.
  // Slides in from above on mount and fades out before being removed.
  return (
    <div
      className={`
        fixed top-6 left-1/2 -translate-x-1/2 z-50
        flex items-center gap-3 px-5 py-3 rounded-xl border shadow-2xl
        text-sm font-medium backdrop-blur-sm
        transition-all duration-400
        ${styles[type]}
        ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-3 pointer-events-none'}
      `}
    >
      {/* Status icon */}
      <span className="text-base leading-none">{icons[type]}</span>

      {/* Message text */}
      {message}
    </div>
  )
}

export default Toast
