/**
 * File: PageTransition.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Wraps page content in a fade and slide-up CSS animation that restarts
 *          whenever the route changes.
 */

import React from 'react'

interface PageTransitionProps {
  children: React.ReactNode
  // Changing this key restarts the animation
  locationKey: string
}

// Wraps page content in a fade and slide-up animation whenever the route changes.
const PageTransition: React.FC<PageTransitionProps> = ({ children, locationKey }) => (
  <div key={locationKey} className="page-transition flex-1 flex flex-col">
    {children}
  </div>
)

export default PageTransition
