/**
 * File: ProtectedRoute.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Guards routes so only authenticated users can access them; redirects
 *          unauthenticated users to the login page.
 */

import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

interface ProtectedRouteProps {
  children: React.ReactNode
}

// Redirects unauthenticated users to /login; replace keeps the protected path off the history stack.
const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { isLoggedIn } = useAuth()
  return isLoggedIn() ? <>{children}</> : <Navigate to="/login" replace />
}

export default ProtectedRoute
