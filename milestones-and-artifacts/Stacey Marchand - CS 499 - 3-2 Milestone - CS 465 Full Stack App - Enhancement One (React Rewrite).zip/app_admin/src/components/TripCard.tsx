/**
 * File: TripCard.tsx
 * Author: Stacey Marchand
 * Class: SNHU CS-499 Capstone
 * Purpose: Displays a trip summary card with image, details, and admin-only edit and
 *          delete controls backed by a confirmation dialog.
 */

import React, { useCallback, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Trip } from '../models/Trip'
import { deleteTrip } from '../api/tripApi'
import ConfirmDialog from './ConfirmDialog'
import { resolveImageUrl, sanitizeHtml } from '../utils/tripHelpers'

interface TripCardProps {
  trip: Trip
  onDeleted: (message?: string) => void
}

const fallbackImage = 'https://placehold.co/400x220/1a2a4a/c8d8f0?text=No+Image'

const TripCard: React.FC<TripCardProps> = ({ trip, onDeleted }) => {
  const navigate = useNavigate()
  const [showConfirm, setShowConfirm] = useState(false)
  const [deleteError, setDeleteError] = useState('')
  const [expanded, setExpanded] = useState(false)
  const [isTruncated, setIsTruncated] = useState(false)
  const clampRef = useRef<HTMLDivElement>(null)

  // Navigation handlers - wrapped in useCallback to avoid recreating on every render.
  const handleEdit = useCallback(() => navigate(`/edit-trip/${trip.code}`), [navigate, trip.code])
  const handleDeleteRequest = useCallback(() => setShowConfirm(true), [])
  const handleDeleteCancel = useCallback(() => setShowConfirm(false), [])

  // Sends the delete request and notifies the parent on success,
  // or shows an error banner that the user can dismiss.
  const handleDeleteConfirm = async () => {
    setShowConfirm(false)
    try {
      await deleteTrip(trip.code)
      onDeleted('Trip deleted')
    } catch {
      setDeleteError('Failed to delete trip. Please try again.')
    }
  }

  // Replaces a broken image src with a neutral placeholder so the card layout is preserved.
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    e.currentTarget.src = fallbackImage
  }

  const imageUrl = resolveImageUrl(trip.image)

  // Memoize sanitization - DOMPurify + DOMParser are expensive and trip.description is stable.
  const sanitizedDescription = useMemo(() => sanitizeHtml(trip.description), [trip.description])

  // useLayoutEffect reads scrollHeight before the browser paints, preventing a "View more" flash on first render.
  useLayoutEffect(() => {
    if (clampRef.current) {
      setIsTruncated(clampRef.current.scrollHeight > clampRef.current.clientHeight)
    }
  }, [trip.description])

  // Memoized so Date construction and locale formatting do not run on re-render.
  const formattedDate = useMemo(
    () =>
      trip.start
        ? new Date(trip.start).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })
        : 'Date TBD',
    [trip.start]
  )

  return (
    <>
      {/* ConfirmDialog is rendered outside the card so its backdrop covers the full screen */}
      {showConfirm && (
        <ConfirmDialog
          message={`Are you sure you want to delete "${trip.name}"? This action cannot be undone.`}
          onConfirm={handleDeleteConfirm}
          onCancel={handleDeleteCancel}
        />
      )}

      {/* Card container - scales up and glows cyan on hover */}
      <div className="bg-surface-700 rounded-xl shadow-xl border border-surface-500 overflow-hidden flex flex-col hover:scale-[1.02] hover:border-cyan-500/40 hover:shadow-[0_0_30px_rgba(6,182,212,0.2),0_20px_40px_rgba(0,0,0,0.4)] transition-all duration-300 origin-top">
        {/* Trip image at top of card */}
        <div className="relative h-48 bg-surface-600 overflow-hidden">
          {/* Cover image - falls back to a placeholder if the URL fails to load */}
          <img
            src={imageUrl}
            alt={trip.name}
            loading="lazy"
            onError={handleImageError}
            className="w-full h-full object-cover"
          />

          {/* Trip length badge overlaid on the top-right of the image */}
          <span className="absolute top-3 right-3 bg-cyan-600 text-white text-xs font-medium px-2.5 py-1 rounded-full uppercase tracking-wide shadow-[0_2px_12px_rgba(0,0,0,0.6),0_0_8px_rgba(6,182,212,0.4)]">
            {trip.length}
          </span>
        </div>

        {/* Card body - all text content and actions */}
        <div className="p-4 flex flex-col flex-1">
          {/* Trip name */}
          <h3 className="font-semibold text-white text-lg mb-1 leading-snug">{trip.name}</h3>

          {/* Resort location */}
          <p className="flex items-center gap-1.5 text-sm text-slate-400 mb-0.5">
            <span>📍</span>
            <span>{trip.resort}</span>
          </p>

          {/* Departure date */}
          <p className="flex items-center gap-2.5 text-sm text-slate-400 mb-3">
            <span>🗓</span>
            <span>Departs: {formattedDate}</span>
          </p>

          {/* Collapsible description */}
          <div
            ref={clampRef}
            className={`relative mb-1 overflow-hidden transition-[max-height] duration-300 ease-in-out ${expanded ? 'max-h-[500px]' : 'max-h-[6rem]'}`}
          >
            {/* dangerouslySetInnerHTML is safe here - content is run through DOMPurify before being stored */}
            <div
              className="text-sm text-slate-400 prose prose-sm prose-invert max-w-none
                [&>p]:mb-2 [&>ul]:list-disc [&>ul]:pl-4 [&>ol]:list-decimal [&>ol]:pl-4
                [&>li]:mb-0.5 [&>h3]:text-white [&>h3]:font-semibold [&>h4]:text-slate-300
                [&>a]:text-cyan-400 [&>a]:underline"
              dangerouslySetInnerHTML={{ __html: sanitizedDescription }}
            />

            {/* Gradient fade-out overlay masks the cut-off text when collapsed */}
            {isTruncated && (
              <div
                className={`absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-surface-700 to-transparent pointer-events-none transition-opacity duration-300 ${expanded ? 'opacity-0' : 'opacity-100'}`}
              />
            )}
          </div>

          {/* Expand / collapse toggle - only shown when the description is long enough to be truncated */}
          {isTruncated && (
            <button
              onClick={() => setExpanded((prev) => !prev)}
              className="self-start text-xs font-medium text-cyan-500 hover:text-cyan-400 mb-3 transition-colors"
            >
              {expanded ? '▲ View less' : '▼ View more'}
            </button>
          )}

          {/* Spacer to maintain consistent spacing when the toggle button is absent */}
          {!isTruncated && <div className="mb-3" />}

          {/* Delete error banner */}
          {deleteError && (
            <p className="text-xs text-red-400 bg-red-900/20 border border-red-800 rounded-lg px-3 py-2 mb-3 flex items-center justify-between gap-2">
              <span>{deleteError}</span>
              <button
                onClick={() => setDeleteError('')}
                className="ml-2 underline text-xs shrink-0"
              >
                Dismiss
              </button>
            </p>
          )}

          {/* Card footer */}
          <div className="flex items-center justify-between pt-3 border-t border-surface-500">
            {/* Price per person */}
            <span className="text-lg font-semibold text-white">
              ${trip.perPerson}
              <span className="text-xs font-normal text-slate-500 ml-0.5">/person</span>
            </span>

            {/* Buttons */}
            <div className="flex gap-2">
              {/* Delete */}
              <button
                onClick={handleDeleteRequest}
                className="text-sm font-medium bg-red-900/20 hover:bg-red-900/40 text-red-400 border border-red-800 px-3 py-1.5 rounded-lg transition-colors"
              >
                Delete
              </button>

              {/* Edit */}
              <button
                onClick={handleEdit}
                className="text-sm font-medium bg-cyan-600 hover:bg-cyan-700 text-white px-3 py-1.5 rounded-lg transition-colors"
              >
                Edit
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default TripCard
