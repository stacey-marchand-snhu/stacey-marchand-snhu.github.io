import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],

  // Proxy API requests to the Express server during development so that the
  // React dev server doesn't need to know the full API origin.
  server: {
    port: 3001,
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      },
    },
  },

  // Place build output in the existing build/ directory to match CRA conventions.
  build: {
    outDir: 'build',
    emptyOutDir: true,
    target: 'es2024',
  },
})

