# Travlr Getaways - Full-Stack Web Application

A travel booking platform consisting of two independently runnable apps sharing a single Express/Node.js backend and MongoDB database.

Originally built for SNHU CS-465. Updated for CS-499 by Stacey Marchand.

| App                | Technology                      | Port | Purpose                              |
|--------------------|---------------------------------|------|--------------------------------------|
| **Express server** | Node.js + Express + Handlebars  | 3000 | Public-facing website + REST API     |
| **Admin SPA**      | React 19 + TypeScript + Vite    | 3001 | Authenticated trip management portal |

## Architecture

```
CS465-fullstack/
├── app.js                     # Express application entry point
├── bin/www                    # HTTP server bootstrap (port 3000)
├── package.json               # Root Node.js dependencies & scripts
│
├── app_server/                # Handlebars public website (MVC)
│   ├── controllers/           # Controller functions for rendering pages with data from the API
│   ├── routes/                # Express routes for the public site (home, trip details)
│   └── views/                 # Handlebars templates for the public site (layouts, partials, pages)
│
├── app_api/                   # Express REST API (JSON) with JWT authentication
│   ├── config/passport.js     # Passport.js local strategy for email/password authentication
│   ├── controllers/
│   │   ├── authentication.js  # Registration and login logic, including JWT generation
│   │   └── trips.js           # CRUD operations for trip documents
│   ├── models/
│   │   ├── db.js              # Mongoose connection + graceful shutdown
│   │   ├── travlr.js          # Trip schema with pre-save validation and formatting
│   │   ├── user.js            # User schema with PBKDF2 password hashing and validation methods
│   │   └── seed.js            # Database seeding script to populate trips from `data/trips.json`
│   └── routes/index.js        # Express routes for the API endpoints (authentication and trips)
│
├── app_admin/                 # React admin SPA (see app_admin/README.md)
├── data/trips.json            # Seed data for trips collection (used by `app_api/models/seed.js`)
└── public/                    # Static assets (images, CSS, client-side JS for the public site)
```

## Backend Tech Stack

| Concern            | Library                                                         |
|--------------------|-----------------------------------------------------------------|
| Web framework      | Express 4                                                       |
| Templating         | Handlebars (`hbs`)                                              |
| Database           | MongoDB via Mongoose 9                                          |
| Authentication     | Passport.js (passport-local) + JSON Web Tokens (`jsonwebtoken`) |
| Password hashing   | Node.js built-in `crypto` (PBKDF2 / SHA-512)                    |
| Rate limiting      | `express-rate-limit`                                            |
| Environment config | `dotenv`                                                        |

For the admin SPA tech stack, see [app_admin/README.md](./app_admin/README.md).

## Prerequisites

- **Node.js 24+**
- **MongoDB** running locally on the default port (`27017`) — database name is `travlr`

## Environment Variables

Copy the `.env.example` file to `.env` and update the values as needed. See contents of `.env.example` for details.

Note, the admin SPA requires its own `.env` file — see [app_admin/README.md](./app_admin/README.md) for details.

## Getting Started

> ⚠️ The Express API server must be running before the admin SPA is started. The SPA has no backend of its own — all data and authentication calls go to the Express server.

```bash
# 1. Install root dependencies
npm install

# 2. Seed the database (first run only)
npm run seed-db

# 3. Start the Express server
npm start
```

Then, in a separate terminal, follow the setup steps in [app_admin/README.md](./app_admin/README.md) to install and start the admin SPA.

## Available Scripts

| Script            | Description                                        |
|-------------------|----------------------------------------------------|
| `npm start`       | Start the Express server on port 3000              |
| `npm run seed-db` | Seed MongoDB with trip data from `data/trips.json` |

For admin SPA scripts, see [app_admin/README.md](./app_admin/README.md).

## REST API

All endpoints are prefixed with `/api` and served on port **3000**.

### Authentication

| Method | Path            | Auth Required | Description                                       |
|--------|-----------------|---------------|---------------------------------------------------|
| `POST` | `/api/register` | No            | Register a new user account; returns a JWT        |
| `POST` | `/api/login`    | No            | Authenticate with email + password; returns a JWT |

Login attempts are rate-limited to **10 requests per 5 minutes per IP** (failed attempts only). Exceeding the limit returns `429 Too Many Requests`.

### Trips

| Method   | Path                   | Auth Required | Description                  |
|----------|------------------------|---------------|------------------------------|
| `GET`    | `/api/trips`           | No            | Return all trips             |
| `GET`    | `/api/trips/:tripCode` | No            | Return a single trip by code |
| `POST`   | `/api/trips`           | **Yes**       | Create a new trip            |
| `PUT`    | `/api/trips/:tripCode` | **Yes**       | Update an existing trip      |
| `DELETE` | `/api/trips/:tripCode` | **Yes**       | Delete a trip                |

Protected routes require a valid JWT as a `Bearer` token in the `Authorization` header.

## Authentication Flow

1. A user POSTs credentials to `/api/login`.
2. Passport.js validates the email/password against the stored PBKDF2 hash.
3. On success, the server returns a signed JWT (expires in **1 hour**) as `{ token }`.
4. The admin SPA stores and transmits the token automatically — see [app_admin/README.md](./app_admin/README.md) for the client-side flow.

## CORS

The Express server allows cross-origin requests from `http://localhost:3001` on all `/api` routes, supporting `GET`, `POST`, `PUT`, and `DELETE` with an `Authorization` header. Configured in `app.js`.

## Database

- **Name:** `travlr`
- **Connection:** Managed by Mongoose in `app_api/models/db.js`.
- **Models:**
  - `trips` — Trip documents (`code`, `name`, `length`, `start`, `resort`, `perPerson`, `image`, `description`)
  - `users` — User documents (`email`, `name`, `salt`, `hash`)
