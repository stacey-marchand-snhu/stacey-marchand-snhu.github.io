// Bring in the DB connection and the Trip schema
const Mongoose = require('./db');
const Trip = require('./travlr');

// Read seed data from JSON file.
const fs = require("fs");
const trips = JSON.parse(fs.readFileSync("./data/trips.json", "utf8"));

// Delete any existing records, then insert seed data.
const seedDB = async () => {
    await Trip.deleteMany({});
    await Trip.insertMany(trips);
};

// Close the MongoDB connection and exit.
seedDB()
  .then(async () => {
    await Mongoose.connection.close();
    console.log('Database seeded successfully.');
    process.exit(0);
  })
  .catch(async (err) => {
    console.error('Seed failed:', err.message);
    await Mongoose.connection.close();
    process.exit(1);
  });
