const jwt = require('jsonwebtoken'); // Enable JSON Web Tokens
const express = require("express");
const router = express.Router();
const rateLimit = require("express-rate-limit");

// Bring in the controller module
const tripsController = require("../controllers/trips");
const authController = require("../controllers/authentication");

// Rate limiter: max 10 login attempts per 5 minutes per IP
const loginLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 10,
  standardHeaders: true,  // Return rate-limit info in RateLimit-* headers
  legacyHeaders: false,
  message: { message: "Too many login attempts. Please try again in 5 minutes." },
  skipSuccessfulRequests: true, // Only count failed attempts against the limit
});

// Method to authenticate our JWT
const authenticateJWT = (req, res, next) => {
  // console.log('In Middleware');
  const authHeader = req.headers['authorization'];

  // console.log('Auth Header: ' + authHeader);
  if (authHeader == null) {
    console.log('Auth Header Required but NOT PRESENT!');
    return res.sendStatus(401);
  }

  let headers = authHeader.split(' ');
  if (headers.length < 1) {
    console.log('Not enough tokens in Auth Header: ' + headers.length);
    return res.sendStatus(501);
  }

  const token = authHeader.split(' ')[1];
  if (token == null) {
    console.log('Null Bearer Token');
    return res.sendStatus(401);
  }

  // next() must be called inside the callback so the request only proceeds
  // once verification has actually completed successfully.
  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if (err) {
      return res.sendStatus(401);
    }
    req.auth = verified; // Set the auth param to the decoded object
    next();
  });
}

// Define routes and route handlers
router
    .route("/login").post(loginLimiter, authController.login);
router
    .route("/register").post(authController.register);
router
    .route("/trips")
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);
router
    .route("/trips/:tripCode")
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip)
    .delete(authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;