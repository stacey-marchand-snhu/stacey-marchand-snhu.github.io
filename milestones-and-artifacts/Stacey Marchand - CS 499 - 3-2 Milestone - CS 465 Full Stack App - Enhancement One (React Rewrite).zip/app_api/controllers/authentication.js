const User = require('../models/user');
const passport = require('passport');


const register = async (req, res) => {
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required' });
  }

  try {
    const user = new User({
      name: req.body.name,
      email: req.body.email,
    });

    user.setPassword(req.body.password);
    const saved = await user.save();
    const token = saved.generateJWT();

    // 201 Created - a new user resource was created
    return res.status(201).json({ token });
  } catch (err) {
    // MongoDB duplicate key error (e.g., email already registered).
    if (err.code === 11000) {
      return res.status(409).json({ message: 'An account with that email already exists.' });
    }
    return res.status(500).json({ message: err.message });
  }
};

const login = (req, res) => {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required' });
  }

  // Delegate authentication to Passport's local strategy.
  passport.authenticate('local', (err, user, info) => {
    if (err) {
      // 500 Internal Server Error - something failed inside the auth process.
      return res.status(500).json({ message: err.message });
    }
    if (user) {
      // 200 OK - credentials accepted, return a signed JWT
      const token = user.generateJWT();
      return res.status(200).json({ token });
    }
    // 401 Unauthorized - credentials were correct in form but rejected by passport.
    return res.status(401).json(info);
  })(req, res);
};

module.exports = { login, register };
